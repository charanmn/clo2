#include "ProductSearch.h"
#include "ProductResultTable.h"
#include "GeneratedFiles/ui_ProductSearch.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QLabel>
#include <QMessageBox>
#include <QCheckBox>
#include <any>
#include <optional>
#include "qlistview.h"
#include "CLO_PLUGIN/INFOR/Libraries/curl/include/curl/curl.h"
#include "CLO_PLUGIN/INFOR/Libraries/json.h"
#include "CLO_PLUGIN/INFOR/Libraries/jsonQt.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
#include "CLO_PLUGIN/INFOR/DesignSuite/DesignSuite.h"
#include "CLO_PLUGIN/INFOR/Utilities/ComboBoxItem.h"
#include "ProductResultTable.h"
#include "classes/APIDefine.h"

using json = nlohmann::json;
using namespace std;
using QtJson::JsonObject;
using QtJson::JsonArray;


namespace CLOPlugin
{
	ProductSearch* ProductSearch::_instance = NULL;

	string ProductSearch::m_bearerToken = " ";

	ProductSearch* ProductSearch::GetInstance()
	{
		Utility::Logger("ProductSearch -> GetInstance() -> Start");

		if (_instance == NULL)
		{
			_instance = new ProductSearch();
		}

		Utility::Logger("ProductSearch -> GetInstance() -> End");
		return _instance;
	}
     /**
	 * \brief brief  destructortor of Product search class
	 *  deletes the object of this class. 
	 */
	void ProductSearch::Destroy()
	{
		Utility::Logger("ProductSearch -> Destroy() -> Start");

		if (_instance)
		{
			delete _instance;
			_instance = NULL;
		}

		Utility::Logger("ProductSearch -> Destroy() -> End");
	}
	 /**
	 * \brief Creates Product Search Dialog
	 * \param  parent
	 */
	ProductSearch::ProductSearch(QWidget* parent) : QDialog(parent)
	{
		Utility::Logger("ProductSearch -> Constructor() -> Start");
		
		setupUi(this);
		QFont fontStyle("Times new roman", 16, QFont::Bold);
		this->setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint | Qt::CustomizeWindowHint);
		QSize size(425, 500);

		ProductSearchTree->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		ProductSearchTree->setStyleSheet("QTreeWidget::item { border-bottom: 1px solid #232323;""padding : 10px;""height: 25px;""}");

		ProductSearchTree->setFixedSize(size);
		ProductSearchTree->setColumnWidth(1, 210);
		ProductSearchTree->setColumnWidth(0, 195);
		
		QTreeWidgetItem *dataItem= new QTreeWidgetItem;
		Qt::ItemFlags flags;
		flags = dataItem->flags();
		flags |= Qt::ItemIsSelectable | Qt::ItemIsEditable | Qt::ItemIsEnabled;
		dataItem->setFlags(flags);
		ProductSearchTree->setFocusPolicy(Qt::FocusPolicy::StrongFocus);	
		ProductSearchTree->setSelectionBehavior(QAbstractItemView::SelectRows);
		ProductSearchTree->setSelectionBehavior(QAbstractItemView::SelectItems);
		ProductSearchTree->setTabKeyNavigation(true);
		label_ps->setFont(fontStyle);
		layout()->setSizeConstraint(QLayout::SetFixedSize);
		this->adjustSize();

		back->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_back_over.svg"));
		back->setIconSize(QSize(iconHieght, iconWidth));

		search->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_search_over.svg"));
		search->setIconSize(QSize(iconHieght, iconWidth));

		QObject::connect(search, SIGNAL(clicked()), this, SLOT(SearchClicked()));
		QObject::connect(back, SIGNAL(clicked()), this, SLOT(backclicked()));
		QObject::connect(closeWindow, SIGNAL(clicked()), this, SLOT(Cancle_clicked()));
		m_isUserInputEmpty = true;
		ReadPLMJson();
		ReadJsonAndDrawDialog();
		m_currentBrandIndex = 0;
		m_currentDivisionIndex = 0;
		m_currentCategoryIndex = 0;
		m_signalOrigin = 0;
		string dependencies = GetDependencies(m_currentBrandIndex, m_currentDivisionIndex, m_currentCategoryIndex);
		SetDependenciesToWidgets(dependencies);
		
		Utility::Logger("ProductSearch -> Constructor() -> End");
	}
	/**
	 * \brief sets bearer token to global variable
	 * \param  bearerToken
	 */
	void ProductSearch::SetBearerToken(const string& bearerToken)
	{
		Utility::Logger("ProductSearch -> SetBearerToken() -> Start");

		m_bearerToken = bearerToken;

		Utility::Logger("ProductSearch -> SetBearerToken() -> End");
	}
	/**
	 * \brief Add labels in product search page from Json
	 */
	void ProductSearch::ReadJsonAndDrawDialog()
	{
		Utility::Logger("ProductSearch -> ReadJsonAndDrawDialog() -> Start");
		
		json jsonString;
		Utility::Fields tempField;
		ifstream filename;
		filename.open("C:\\MiddlewareFiles\\productSearchFiltered.json");
		filename >> jsonString;
		filename.close();
		string completeJsonString, uiTypeJSONObject, presetListJSONObject, fieldValues;
		completeJsonString = jsonString.dump();
		json completeJson = json::parse(completeJsonString);
		uiTypeJSONObject = completeJson["uiTypeList"].dump();
		json componentsJson = json::parse(uiTypeJSONObject);
		presetListJSONObject = completeJson["presetList"].dump();
		json presetListJSON = json::parse(presetListJSONObject);
		fieldValues = completeJson["fieldList"].dump();
		json fieldValuesJson = json::parse(fieldValues);

		for (int i = 0; i < fieldValuesJson.size(); i++)
		{
			string fieldValuesString = fieldValuesJson[i].dump();
			fieldValuesString = fieldValuesString.erase(0, 1);
			fieldValuesString = fieldValuesString.erase(fieldValuesString.size() - 1);
			tempField.labelValue = QString::fromStdString(fieldValuesString);
			string uiTypes = componentsJson[fieldValuesString].dump();
			uiTypes = uiTypes.erase(0, 1);
			uiTypes = uiTypes.erase(uiTypes.size() - 1);
			tempField.fieldUItype = QString::fromStdString(uiTypes);
			if (tempField.fieldUItype == "dropdown")
			{
				string presetList = presetListJSON[fieldValuesString].dump();
				presetList = presetList.erase(0, 1);
				presetList = presetList.erase(presetList.size() - 1);
				presetList.erase(std::remove(presetList.begin(), presetList.end(), '\"'), presetList.end());
				QStringList listQt;
				listQt = QString::fromStdString(presetList).split(",");
				tempField.presetValues = listQt;
			}
			m_searchFieldsVector.push_back(tempField);
		}
		DrawWidget(m_searchFieldsVector);
		
		Utility::Logger("ProductSearch -> ReadJsonAndDrawDialog() -> End");
	}
	/**
	 * \brief Sets type of widgets for labels
	 * \param  fieldsVector
	 */
	void ProductSearch::DrawWidget(std::vector<Utility::Fields>& fieldsVector)
	{		
		Utility::Logger("ProductSearch -> DrawWidget() -> Start");

		for each (auto field in fieldsVector)
		{
			if (field.fieldUItype == "text")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();  
				QLineEdit* LineEdit = new QLineEdit();						
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				LineEdit->setStyleSheet(inputStyle);
				ProductSearchTree->addTopLevelItem(topLevel);						
				ProductSearchTree->setItemWidget(topLevel, 0, label);				
				ProductSearchTree->setItemWidget(topLevel, 1, LineEdit);
				LineEdit->setText(field.userInputValues);
				
			}

			if (field.fieldUItype == "dropdown")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				ComboBoxItem* comboBox = new ComboBoxItem(topLevel, 1);
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string temLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < temLabel.length(); capsCount++)
				{
					if (isupper(temLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							temLabel = temLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(temLabel));
				comboBox->setStyleSheet(inputStyle);
				ProductSearchTree->addTopLevelItem(topLevel);
				ProductSearchTree->setItemWidget(topLevel, 0, label);
				ProductSearchTree->setItemWidget(topLevel, 1, comboBox);
				if (field.labelValue == "Brand")
				{
					QObject::connect(comboBox, SIGNAL(currentIndexChanged(const QString&)), this,
						SLOT(brandValueChanged(const QString&)));
				}
				if (field.labelValue == "Division")
				{
					QObject::connect(comboBox, SIGNAL(currentIndexChanged(const QString&)), this,
						SLOT(divisionValueChanged(const QString&)));
				}
				if (field.labelValue == "Category")
				{
					QObject::connect(comboBox, SIGNAL(currentIndexChanged(const QString&)), this,
						SLOT(categoryValueChanged(const QString&)));
				}
				comboBox->setStyleSheet("combobox-popup: 0; font: 75 8pt \"Tahoma\"; ");
				comboBox->addItems(field.presetValues);
				int indexOfEmptyString = comboBox->findText("");
				comboBox->setCurrentIndex(indexOfEmptyString);
			}

			if (field.fieldUItype == "textarea")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();  
				QTextEdit* TextEdit = new QTextEdit();						
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string temLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < temLabel.length(); capsCount++)
				{
					if (isupper(temLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							temLabel = temLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(temLabel));
				ProductSearchTree->addTopLevelItem(topLevel);						
				ProductSearchTree->setItemWidget(topLevel, 0, label);				
				ProductSearchTree->setItemWidget(topLevel, 1, TextEdit);
				TextEdit->setText(field.userInputValues);
				TextEdit->setStyleSheet("border: 1px solid black;""background-color: #222222;""font: 75 8pt \"Tahoma\";"
				);
				TextEdit->setMaximumSize(190, 80);
			}

			if (field.fieldUItype == "DateEdit")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QDateEdit* DateTimeEdit = new QDateEdit();
				bool enable = true;
				DateTimeEdit->setCalendarPopup(enable);			
				QString dateRecovery("");
				QDate date = QDate::fromString(dateRecovery, "");
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				ProductSearchTree->addTopLevelItem(topLevel);
				ProductSearchTree->setItemWidget(topLevel, 0, label);
				ProductSearchTree->setItemWidget(topLevel, 1, DateTimeEdit);	
			}
		}

		Utility::Logger("ProductSearch -> DrawWidget() -> End");
	}
	/**
	* \brief Getting Dependency List to Pop-up values in drop down list
	* \param brand 
	* \param division 
	* \param category 
	* \return string 
	*/
	string ProductSearch::GetDependencies(int brand, int division, int category)
	{
		json dependencyMap, styleInfoMap;

		styleInfoMap["BrandId"] = brand;
		styleInfoMap["DivisionId"] = division;
		styleInfoMap["SeasonId"] = nullptr;
		styleInfoMap["CollectionId"] = nullptr;
		styleInfoMap["GenderId"] = nullptr;
		styleInfoMap["CategoryId"] = category;
		styleInfoMap["SubCategoryId"] = nullptr;
		styleInfoMap["SubSubCategoryId"] = nullptr;
		styleInfoMap["DesignerId"] = nullptr;
		styleInfoMap["StatusId"] = 1;

		dependencyMap["userId"] = 71;
		dependencyMap["schema"] = "FSH5";
		dependencyMap["style"] = styleInfoMap;

		string parameter = to_string(dependencyMap);
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", DesignSuite::GetInstance()->GetBearerToken()));
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/adobe/api/adobeext/adobestyle/getfielddep", &parameter, headerNameAndValueList, "HTTP Post");

		return response;
	}
	/**
	* \brief Populate dependent values of Brand
	* \param  item
	*/
	void ProductSearch::brandValueChanged(const QString& item)
	{
		if (item != "")
		{
			m_signalOrigin = 1;

			map<string, string> attNameIdMap;
			attNameIdMap.clear();
			attNameIdMap.insert(m_attsDropdownListMap["Brand"].begin(), m_attsDropdownListMap["Brand"].end());
			for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
			{
				if (it->first == item.toStdString())
				{
					m_currentBrandIndex = stoi(it->second);
					break;
				}
			}
			string dependencies = GetDependencies(m_currentBrandIndex, 0, 0);
			SetDependenciesToWidgets(dependencies);
		}
	}
	/**
	* \brief Populate dependent values of division
	* \param  item
	*/
	void ProductSearch::divisionValueChanged(const QString& item)
	{
		if (item != "")
		{
			m_signalOrigin = 2;
			map<string, string> attNameIdMap;
			attNameIdMap.clear();
			attNameIdMap.insert(m_attsDropdownListMap["Division"].begin(), m_attsDropdownListMap["Division"].end());
			for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
			{
				if (it->first == item.toStdString())
				{
					m_currentDivisionIndex = stoi(it->second);
					break;
				}
			}
			string dependencies = GetDependencies(m_currentBrandIndex, m_currentDivisionIndex, 0);
			SetDependenciesToWidgets(dependencies);
		}
	}
	/**
	* \brief Populate dependent values of category
	* \param  item
	*/
	void ProductSearch::categoryValueChanged(const QString& item)
	{
		if (item != "")
		{
			m_signalOrigin = 3;
			map<string, string> attNameIdMap;
			attNameIdMap.clear();
			attNameIdMap.insert(m_attsDropdownListMap["Category"].begin(), m_attsDropdownListMap["Category"].end());
			for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
			{
				if (it->first == item.toStdString())
				{
					m_currentCategoryIndex = stoi(it->second);
					break;
				}
			}
			string dependencies = GetDependencies(m_currentBrandIndex, m_currentDivisionIndex, m_currentCategoryIndex);
			SetDependenciesToWidgets(dependencies);
		}
	}
	/**
	* \brief Setting Dependent values to widgets
	* \param  dependencies
	*/
	void ProductSearch::SetDependenciesToWidgets(string dependencies)
	{
		string errorResponse = Utility::CheckErrorDescription(dependencies);

		string completeDependencies;
		json dependencyJson;
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			size_t found = dependencies.find("200");
			if (found != string::npos)
			{
				int indexforcontent = dependencies.find("{");
				completeDependencies = dependencies.substr(indexforcontent);
				std::replace(completeDependencies.begin(), completeDependencies.end(), '�', ' ');

				try
				{
					dependencyJson = json::parse(completeDependencies);
					SetPresetValues(dependencyJson);
				}
				catch (json::exception & err)
				{
					//	// output exception information
					Utility::Logger("message: " + QString(err.what()).toStdString() + '\n'
						+ "exception id: " + to_string(err.id));
				}

			}
		}
		else
		{
			UTILITY_API->DisplayMessageBox(errorResponse);
		}
	}
	/**
	* \brief Setting Independent Values to widgets 
	* \param  dependencyJson
	*/
	void ProductSearch::SetPresetValues(json dependencyJson)
	{
		for (int i = 0; i < ProductSearchTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = ProductSearchTree->topLevelItem(i);
			QWidget* qWidgetColumn0 = ProductSearchTree->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = ProductSearchTree->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string label = qlabel->text().toStdString();

			ComboBoxItem* qComboBox = qobject_cast<ComboBoxItem*>(qWidgetColumn1);
			if (qComboBox)
			{
				switch (m_signalOrigin)
				{
				case 0:
				{
					if ((label == "Division") || (label == "Category") || (label == "Sub Category") || (label == "Sub Sub Category"))
					{
						qComboBox->clear();
					}
				}
				break;
				case 1:
				{

					if ((label == "Division") || (label == "Category") || (label == "Sub Category") || (label == "Sub Sub Category"))
					{
						label = Utility::RemoveSpaces(label);
						string indexString = label + "List";
						string tempString = dependencyJson[indexString].dump();
						json tempJson = json::parse(tempString);
						if (tempJson.size() > 0)
						{
							qComboBox->clear();
							for (int i = 0; i < tempJson.size(); i++)
							{
								string item = tempJson[i]["Name"].dump();
								item = item.erase(0, 1);
								item = item.erase(item.size() - 1);
								qComboBox->addItem(QString::fromStdString(item));
							}

						}
					}
				}
				break;
				case 2:
				{
					if ((label == "Category") || (label == "Sub Category") || (label == "Sub Sub Category"))
					{
						label = Utility::RemoveSpaces(label);
						string indexString = label + "List";
						string tempString = dependencyJson[indexString].dump();
						json tempJson = json::parse(tempString);
						if (tempJson.size() > 0)
						{
							qComboBox->clear();
							for (int i = 0; i < tempJson.size(); i++)
							{

								string item = tempJson[i]["Name"].dump();
								item = item.erase(0, 1);
								item = item.erase(item.size() - 1);
								qComboBox->addItem(QString::fromStdString(item));
							}

						}
					}
				}
				break;
				case 3:
				{
					if ((label == "Sub Category") || (label == "Sub Sub Category"))
					{
						label = Utility::RemoveSpaces(label);
						string indexString = label + "List";
						string tempString = dependencyJson[indexString].dump();
						json tempJson = json::parse(tempString);
						if (tempJson.size() > 0)
						{
							qComboBox->clear();
							for (int i = 0; i < tempJson.size(); i++)
							{

								string item = tempJson[i]["Name"].dump();
								item = item.erase(0, 1);
								item = item.erase(item.size() - 1);
								qComboBox->addItem(QString::fromStdString(item));
							}

						}
					}
				}
				break;
				}

			}

		}
		
	}
	ProductSearch::~ProductSearch()
	{

	}
	/**
	* \brief  Mapping Dropdown Values with Id
	* \param  lookUpsJson
	* \param  attributeValue
	* \param  attribMap
	*/
	void ProductSearch::GetDropDownMap(json& lookUpsJson, string attributeValue, map<string, string>& attribMap)
	{
		Utility::Logger("ProductSearch -> GetDropDownMap() -> Start");

		map<string, string> tempMap;
		for (int i = 0; i < lookUpsJson.size(); i++) 
		{
			string lookupNameAndId = lookUpsJson[i].dump();
			json lookupNameAndIdJson = json::parse(lookupNameAndId);
			string colName = lookupNameAndIdJson["name"].dump();
			colName = colName.erase(0, 1);
			colName = colName.erase(colName.size() - 1);

			if (attributeValue.compare(colName) == 0)
			{
				string id, name;
				string columnStg = lookupNameAndIdJson["column"].dump();
				json colNameAndIDJSON = json::parse(columnStg);
				id = colNameAndIDJSON["Id"].dump();

				name = colNameAndIDJSON["Name"].dump();
				name = name.erase(0, 1);
				name = name.erase(name.size() - 1);

				tempMap.insert(std::make_pair(name, id));

			}
		}
		attribMap = tempMap;
		Utility::Logger("ProductSearch -> GetDropDownMap() -> End");
	}
	/**
	* \brief Method gets the response of Product Details from PLM
	*/
	void ProductSearch::GetFilteredProductJson()
	{
		Utility::Logger("ProductSearch -> GetFilteredProductJson() -> Start");

		//////////////to get 18000 lines
		ofstream styelDetailsFile;
		styelDetailsFile.open("C:\\MiddlewareFiles\\styleDetails.json");
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", DesignSuite::GetInstance()->GetBearerToken()));
		string parameter = "{\"roleId\":1,\"userId\":72,\"entity\":\"Style\",\"pageType\":\"details\",\"dataFilter\":{\"conditions\":[{\"fieldname\":\"StyleId\",\"operator\":\"=\",\"value\":\"\"}]},\"pageInfo\":{},\"Schema\":\"FSH5\"}";
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/adobe/api/view/layout/data/get", &parameter, headerNameAndValueList, "HTTP Post");
		string errorResponse = Utility::CheckErrorDescription(response);
		string completeDocLibs;
		json docLibjson;
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			size_t found = response.find("200");
			if (found != string::npos && response.find("OK"))
			{
				int indexforFlowerBrace = response.find("{");
				completeDocLibs = response.substr(indexforFlowerBrace);
				std::replace(completeDocLibs.begin(), completeDocLibs.end(), '�', ' ');

				try
				{
					docLibjson = json::parse(completeDocLibs);
				}
				catch (json::exception & err)
				{
				
				}

			}
		}
		styelDetailsFile << docLibjson;
		styelDetailsFile.close();
		
		Utility::Logger("ProductSearch -> GetFilteredProductJson() -> End");
	}
	/**
	* \brief Filter out Product Details Json
	*/
	void  ProductSearch::ReadPLMJson() 
	{
		Utility::Logger("ProductSearch -> ReadPLMJson() -> Start");

		GetFilteredProductJson();
		json completeStyleJson;
		m_attsDropdownListMap.clear();
		m_attributeMap.clear();
		ifstream styleDetailsFile;
		styleDetailsFile.open("C:\\MiddlewareFiles\\styleDetails.json");

		styleDetailsFile >> completeStyleJson;
		styleDetailsFile.close();

		ofstream styleSearchFile;
		styleSearchFile.open("C:\\MiddlewareFiles\\productSearchFiltered.json");
		json finalJsontoSave;
		auto jsonFieldList = json::array();
		auto jsonUiTypeList = json::object();
		auto presetArray = json::array();
		json newPresetListObject = json::array();
		auto presetList = json::object();
		auto jsonMandatoryFieldsList = json::array();
		auto jsonDataFieldList = json::object();
		int uiPresetCount = 0;
		string completeStyleJsonString, componentsString, compObjString;
		completeStyleJsonString = completeStyleJson.dump();
		json completeJson = json::parse(completeStyleJsonString);
		componentsString = completeJson["layout"]["components"].dump();
		json componentsJson = json::parse(componentsString);
		for (int i = 0; i < componentsJson.size(); i++) 
		{
			compObjString = componentsJson[i].dump();
			json compObjJson = json::parse(compObjString);
			string propsString = compObjJson["props"].dump();
			json  propsJson = json::parse(propsString);
			string visible = propsJson["isVisibleAi"].dump();
			Utility::Logger("passed data::/n" + visible);

			if (visible == "true")
			{
				string requi = propsJson["isRequired"].dump();

				string fieldType = compObjJson["fieldType"].dump();
				fieldType = fieldType.erase(0, 1);
				fieldType = fieldType.erase(fieldType.size() - 1);

				string lookupRef = compObjJson["lookupRef"].dump();
				lookupRef = lookupRef.erase(0, 1);
				lookupRef = lookupRef.erase(lookupRef.size() - 1);

				string dataField = compObjJson["dataField"].dump();
				dataField = dataField.erase(0, 1);
				dataField = dataField.erase(dataField.size() - 1);

				if (lookupRef == "ul")
				{
					m_attributeMap.insert(std::make_pair(dataField, dataField));
					jsonUiTypeList[dataField] = fieldType;
					jsonFieldList.push_back(dataField);
					jsonDataFieldList[dataField] = dataField;
					if (requi == "true")
					{
						jsonMandatoryFieldsList.push_back(dataField);
					}
				}
				else
				{
					m_attributeMap.insert(std::make_pair(lookupRef, dataField));
					jsonUiTypeList[lookupRef] = fieldType;
					jsonFieldList.push_back(lookupRef);
					jsonDataFieldList[lookupRef] = dataField;
					if (requi == "true")
					{
						jsonMandatoryFieldsList.push_back(lookupRef);
					}
				}

				if (fieldType == "dropdown")

				{
					string lookups = completeJson["lookups"].dump();
					json lookupsJSON = json::parse(lookups);
					map<string, string> tempAttribMap;
					GetDropDownMap(lookupsJSON, lookupRef, tempAttribMap);
					presetArray.clear();
					presetArray.push_back("");
					for (auto it = tempAttribMap.begin(); it != tempAttribMap.end(); it++)
					{
						presetArray.push_back(it->first);
					}
					presetList[lookupRef] = presetArray;
					m_attsDropdownListMap.insert(std::make_pair(lookupRef, tempAttribMap));
				}
			}
		}
		auto newjsonFieldList = json::array();
		newjsonFieldList.push_back("StyleCode");
		newjsonFieldList.push_back("Name");
		newjsonFieldList.push_back("Brand");
		newjsonFieldList.push_back("Division");
		newjsonFieldList.push_back("User");
		newjsonFieldList.push_back("Season");
		newjsonFieldList.push_back("Collection");
		newjsonFieldList.push_back("Status");
		newjsonFieldList.push_back("Category");
		newjsonFieldList.push_back("SubCategory");
		newjsonFieldList.push_back("SubSubCategory");
		newjsonFieldList.push_back("Gender");
		newjsonFieldList.push_back("Description");

		finalJsontoSave["fieldList"] = newjsonFieldList;// jsonFieldList;
		finalJsontoSave["uiTypeList"] = jsonUiTypeList;
		finalJsontoSave["presetList"] = presetList;
		finalJsontoSave["mandatory_fieldList"] = jsonMandatoryFieldsList;
		finalJsontoSave["dataFieldList"] = jsonDataFieldList;
		styleSearchFile << finalJsontoSave;
		styleSearchFile.close();

		Utility::Logger("ProductSearch -> ReadPLMJson() -> End");
	}
	/**
	* \brief Reads User input values from Product Search UI
	* \return bool
	*/
	bool ProductSearch::ExtractAllUIValues()
	{
		Utility::Logger("ProductSearch -> ExtractAllUIValues() -> Start");

		bool text;
		bool textArea;
		bool dropdown;

		for (int i = 0; i < ProductSearchTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = ProductSearchTree->topLevelItem(i);
			QWidget* qWidgetColumn0 = ProductSearchTree->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = ProductSearchTree->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string lable = qlabel->text().toStdString();
			QLineEdit* qlineedit = qobject_cast<QLineEdit*>(qWidgetColumn1);

			if (qlineedit)
			{
				m_searchFieldsVector[i].userInputValues = qlineedit->text();
				if (!qlineedit->text().isEmpty())
				{
					m_isUserInputEmpty = false;
				}
			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
				if (qComboBox)
				{
					m_searchFieldsVector[i].userInputValues = qComboBox->currentText();
					if (!qComboBox->currentText().isEmpty())
					{
						m_isUserInputEmpty = false;
					}
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
					if (qtextEdit)
					{
						m_searchFieldsVector[i].userInputValues = qtextEdit->toPlainText();
						if (!qtextEdit->toPlainText().isEmpty())
						{
							m_isUserInputEmpty = false;
						}
					}
				}
			}
		}
		if (m_isUserInputEmpty)
		{
			UTILITY_API->DisplayMessageBox("Please enter atleast one field to search Products.");
			return false;
		}

		Utility::Logger("ProductSearch -> ExtractAllUIValues() -> End");
		return true;
	}
	/**
	* \brief Clear all fields from widgets 
	*/
	void ProductSearch::ClearAllFields()
	{
		Utility::Logger("ProductSearch -> ClearAllFields() -> Start");
		m_signalOrigin = 0;
		for (int i = 0; i < ProductSearchTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = ProductSearchTree->topLevelItem(i);
			QWidget* qWidgetColumn0 = ProductSearchTree->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = ProductSearchTree->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string label = qlabel->text().toStdString();
			QLineEdit* qlineedit = qobject_cast<QLineEdit*>(qWidgetColumn1);

			if (qlineedit)
			{
				qlineedit->setText("");
			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
				if (qComboBox)
				{
					int indexOfEmptyString = qComboBox->findText("");
					qComboBox->setCurrentIndex(indexOfEmptyString);
					if (label == "Division" || label == "Category" || label == "Sub Category" || label == "Sub Sub Category")
					{
						qComboBox->clear();
					}
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
					if (qtextEdit)
					{
						qtextEdit->setText("");
					}
				}
			}
		}

		Utility::Logger("ProductSearch -> ClearAllFields() -> End");
	}
	/**
	* \brief Creating Map for Searching Product 
	*/
	void ProductSearch::CreateProductSearchMap()
	{
		Utility::Logger("ProductSearch -> createProductSearchMap() -> Start");

		json filterMap;
		json pageInfoMap;
		json conditions = json::object();
		json mapArray;
		m_productSearchMap.clear();

		m_productSearchMap["roleId"] = 1;
		m_productSearchMap["userId"] = 71;
		m_productSearchMap["schema"] = "FSH5";
		m_productSearchMap["entity"] = "Style";
		m_productSearchMap["pageType"] = "list";
		m_productSearchMap["personalizationId"] = 0;
		pageInfoMap["page"] = 1;
		pageInfoMap["pageSize"] = 40;
		m_productSearchMap["pageInfo"] = pageInfoMap;
		m_productSearchMap["sortInfo"] = nullptr;
		int count = 0;

		for (auto array_element : m_searchFieldsVector)
		{
			string attLabel = array_element.labelValue.toStdString(); 
			string userSelected = array_element.userInputValues.toStdString();
			if (userSelected != "")
			{
				if (array_element.fieldUItype == "dropdown")
				{
					for (auto it = m_attributeMap.begin(); it != m_attributeMap.end(); it++)
					{
						if (it->first == attLabel)
						{
							mapArray["fieldName"] = it->second;
							map<string, string> attNameIdMap;
							attNameIdMap.clear();
							attNameIdMap.insert(m_attsDropdownListMap[attLabel].begin(), m_attsDropdownListMap[attLabel].end());
							for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
							{
								if (it->first == userSelected)
								{
									mapArray["operator"] = "=";
									mapArray["value"] = stoi(it->second);
									break;
								}
							}
							break;
						}
					}
					conditions["Conditions"][count++] = mapArray;
				}
				else if (array_element.fieldUItype == "text")
				{
					if (attLabel == "StyleCode")
					{
						filterMap.clear();
						filterMap["fieldName"] = attLabel;
						filterMap["operator"] = "like";
						filterMap["value"] = userSelected;
						conditions["Conditions"][count++] = filterMap;
					}
					else
					{
						filterMap.clear();
						filterMap["fieldName"] = attLabel;
						filterMap["operator"] = "=";
						filterMap["value"] = userSelected;
						conditions["Conditions"][count++] = filterMap;
					}
				}
			}
		}
		filterMap.clear();
		filterMap["fieldname"] = "IsDeleted";
		filterMap["operator"] = "=";
		filterMap["value"] = 0;
		conditions["Conditions"][count++] = filterMap;
		conditions["Search"] = nullptr;

		m_productSearchMap["dataFilter"] = conditions;
		Utility::Logger("ProductSearch -> createProductSearchMap() -> End");
	}
	/**
	* \brief Clicked on Search Button,  Calling Search Method  
	*/
	void ProductSearch::SearchClicked()
	{
		Utility::Logger("ProductSearch -> SearchClicked() -> Start");
		
		if (ExtractAllUIValues())
		{
			this->hide();
			PLMSearch();
			m_isUserInputEmpty = true;
		}

		Utility::Logger("ProductSearch -> SearchClicked() -> End");
	}
	/**
	* \brief Making Rest Call for Search Product
	*/
	void ProductSearch::PLMSearch()
	{
		Utility::Logger("ProductSearch -> PLMSearch() -> Start");

		CreateProductSearchMap();
		string parameter, bearerKey;
		json map;
		json emptyArray;

		parameter = to_string(m_productSearchMap);
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", m_bearerToken));
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/view/api/view/layout/data/get", &parameter, headerNameAndValueList, "HTTP Post");
		json responseJson;
		string errorResponse = Utility::CheckErrorDescription(response);
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			
			int indexForContent = response.find("Content-Type:");
			string strForCheck = response.substr(indexForContent);
			int indexForJSON = strForCheck.find("{");
			string strForJSON = strForCheck.substr(indexForJSON);
			responseJson = json::parse(strForJSON);
			CreateResultTable(responseJson);
		}
		else
		{

			UTILITY_API->DisplayMessageBox("ERROR::" + errorResponse);
		}

		Utility::Logger("ProductSearch -> PLMSearch() -> End");
	}
	/**
	* \brief Creating Result Table based on response
	* \param responseJson
	*/
	void ProductSearch::CreateResultTable(json responseJson) 
	{
		Utility::Logger("ProductSearch -> createResultTable() -> Start");

		const char* newDirPath = PRODUCTS_TEMP_DIRECTORY.c_str();
		mkdir(newDirPath);
		json completeStylesJson;
		string responseJsonStrStyle = responseJson["entities"].dump();
		completeStylesJson = json::parse(responseJsonStrStyle);
		string responseJsonsize = to_string(completeStylesJson.size());
		string responseString = "";

		ProductResultTable pResultTable;
		pResultTable.SetBearerToken(m_bearerToken);
		
		if (completeStylesJson.size() != 0)
		{
			for (int i = 0; i < completeStylesJson.size(); i++)
			{
				string entityJson = completeStylesJson[i].dump();
				json styles = json::parse(entityJson);

				string name = styles["name"].dump();
				name = name.erase(0, 1);
				name = name.erase(name.size() - 1);
				string column, styleId, styleName, styleCode, thumbnail, brandId, 
					brandValue, imageFileName, attachmentsFileName, imageAttaFileListId;
				string statusValue, statusId, divisionValue, divisionId, genderId, genderValue,
					categoryId, categoryValue, subCategoryId, subCategoryValue, subSubCategoryId, subSubCategoryValue,
					collectionId, collectionValue, seasonId, seasonValue, description, userId, userValue;
				if (name == "Style")
				{
					column = styles["column"].dump();
					json columns = json::parse(column);
					styleId = columns["StyleId"].dump();
					

					styleName = columns["Name"].dump();
					if (styleName != "null")
					{
						styleName = styleName.erase(0, 1);
						styleName = styleName.erase(styleName.size() - 1);
					}
					else
					{
						styleName = "";
					}

					styleCode = columns["StyleCode"].dump();
					styleCode = styleCode.erase(0, 1);
					styleCode = styleCode.erase(styleCode.size() - 1);

					thumbnail = columns["Image"].dump(); //url of image thumbnail
					thumbnail = thumbnail.erase(0, 1);
					thumbnail = thumbnail.erase(thumbnail.size() - 1);

					imageFileName = columns["DefaultAttachment"]["CFilename"].dump();
					QPixmap pixmap;
					if (imageFileName != "null")
					{
						imageFileName = imageFileName.erase(0, 1);
						imageFileName = imageFileName.erase(imageFileName.size() - 1);

						Utility::DownloadImageFromURL(thumbnail, PRODUCTS_TEMP_DIRECTORY + imageFileName);

						QImage img;
						QImage styleIcon;

						styleIcon.load(QString::fromStdString(PRODUCTS_TEMP_DIRECTORY + imageFileName));
						pixmap = QPixmap::fromImage(styleIcon);

						imageAttaFileListId = columns["DefaultAttachment"]["AttaFileListId"].dump(); //needed for unlinking
					}
					else
					{
						imageFileName = "";
					}

					description = columns["Description"].dump();
					if (description != "null")
					{
						description = description.erase(0, 1);
						description = description.erase(description.size() - 1);
					}
					else
					{
						description = "";
					}

					brandValue = columns["BrandId"].dump();
					if (brandValue != "null")
					{
						brandId = columns["BrandId_Lookup"]["Name"].dump();
						brandId = brandId.erase(0, 1);
						brandId = brandId.erase(brandId.size() - 1);
					}
					

					statusValue = columns["Status"].dump();
					if (statusValue != "null")
					{
						statusId = columns["Status_Lookup"]["Name"].dump();
						statusId = statusId.erase(0, 1);
						statusId = statusId.erase(statusId.size() - 1);
					}
					

					divisionValue = columns["DivisionId"].dump();
					if (divisionValue != "null")
					{
						divisionId = columns["DivisionId_Lookup"]["Name"].dump();
						divisionId = divisionId.erase(0, 1);
						divisionId = divisionId.erase(divisionId.size() - 1);
					}
					
					genderValue = columns["GenderId"].dump();
					if (genderValue != "null")
					{
						genderId = columns["GenderId_Lookup"]["Name"].dump();
						genderId = genderId.erase(0, 1);
						genderId = genderId.erase(genderId.size() - 1);
					}
					categoryValue = columns["CategoryId"].dump();
					if (categoryValue != "null")
					{
						categoryId = columns["CategoryId_Lookup"]["Name"].dump();
						categoryId = categoryId.erase(0, 1);
						categoryId = categoryId.erase(categoryId.size() - 1);
					}
					subSubCategoryValue = columns["ProductSubSubCategoryId"].dump();
					if (subCategoryValue != "null")
					{
						subSubCategoryId = columns["ProductSubSubCategoryId_Lookup"]["Name"].dump();
						subSubCategoryId = subSubCategoryId.erase(0, 1);
						subSubCategoryId = subSubCategoryId.erase(subSubCategoryId.size() - 1);
					}
					subCategoryValue = columns["SubCategoryId"].dump();
					if (subCategoryValue != "null")
					{
						subCategoryId = columns["SubCategoryId_Lookup"]["Name"].dump();
						subCategoryId = subCategoryId.erase(0, 1);
						subCategoryId = subCategoryId.erase(subCategoryId.size() - 1);
					}

					collectionValue = columns["CollectionId"].dump();
					if (collectionValue != "null" )
					{
						collectionId = columns["CollectionId_Lookup"]["Name"].dump();
						collectionId = collectionId.erase(0, 1);
						collectionId = collectionId.erase(collectionId.size() - 1);
					}
					seasonValue = columns["SeasonId"].dump();
					if (seasonValue != "null")
					{
						seasonId = columns["SeasonId_Lookup"]["Name"].dump();
						seasonId = seasonId.erase(0, 1);
						seasonId = seasonId.erase(seasonId.size() - 1);
					}
					
					userId = columns["ModifyId"].dump();
					if (userId != "null")
					{
						userValue = columns["ModifyId_Lookup"]["Name"].dump();
						userValue = userValue.erase(0, 1);
						userValue = userValue.erase(userValue.size() - 1);
					}
					Utility::ProductResults tempProductResults;
					tempProductResults.styleCode = QString::fromStdString(styleCode);
					tempProductResults.styleId = QString::fromStdString(styleId);
					tempProductResults.styleName = QString::fromStdString(styleName);
					tempProductResults.brandName = QString::fromStdString(brandId);
					tempProductResults.brandValue = QString::fromStdString(brandValue);
					tempProductResults.imageFileName = QString::fromStdString(imageFileName);
					tempProductResults.imageAttaFileListId = QString::fromStdString(imageAttaFileListId);
					tempProductResults.statusId = QString::fromStdString(statusId);
					tempProductResults.divisionId = QString::fromStdString(divisionId);
					tempProductResults.genderId = QString::fromStdString(genderId);
					tempProductResults.categoryId = QString::fromStdString(categoryId);
					tempProductResults.subCategoryId = QString::fromStdString(subCategoryId);
					tempProductResults.subSubCategoryId = QString::fromStdString(subSubCategoryId);
					tempProductResults.description = QString::fromStdString(description);
					tempProductResults.userId = QString::fromStdString(userValue);
					tempProductResults.seasonId = QString::fromStdString(seasonId);
					tempProductResults.collectionId = QString::fromStdString(collectionId);
					pResultTable.AddRowData(tempProductResults, pixmap);
				}
			}
			pResultTable.setModal(true);
			pResultTable.exec();
		}
		else 
		{
			UTILITY_API->DisplayMessageBox("No Result Found ");
			this->show();
		}

		Utility::Logger("ProductSearch -> CreateResultTable() -> End");
	}
	/**
	* \brief On Cancel Clicked, closing Product Search UI
	*/
	void ProductSearch::Cancle_clicked()
	{
		Utility::Logger("ProductSearch -> CancelClicked() -> Start");
		m_signalOrigin = 0;
		for each(auto field in m_searchFieldsVector)
		{
			field.userInputValues.clear();
		}
		this->close();

		Utility::Logger("ProductSearch -> CancelClicked() -> End");
	}
	/**
	* \brief On back Clicked, coming back to Design suite
	*/
	void ProductSearch::backclicked()
	{
		Utility::Logger("ProductSearch -> BackClicked() -> Start");
		m_signalOrigin = 0;
		this->hide();
		DesignSuite::GetInstance()->setModal(true);
		DesignSuite::GetInstance()->show();
		Utility::Logger("ProductSearch -> BackClicked() -> End");
	}
}