#pragma once

#include <string>
#include <iostream>
#include <fstream>
#include <QDialog>
#include <QtCore>
#include <QtGui>
#include <QTreeWidgetItem>
#include "GeneratedFiles/ui_ProductResultTable.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
#include "CLO_PLUGIN/INFOR/Libraries/json.h"

using nlohmann::json;
using namespace std;

namespace CLOPlugin
{
	class ProductResultTable : public QDialog, public Ui::ProductResultTable
	{
		Q_OBJECT
			std::vector<Utility::ProductResults> m_productResults;
		static string m_bearerToken;
		static ProductResultTable* _instance;
		QTreeWidgetItem* m_headerItem;
		json m_downloadAttachmentsMap;
		string m_attachmentsFileName;
		string m_attachmentsAttaFileListId;

	public:
		ProductResultTable(QWidget* parent = 0, Qt::WindowFlags flags = Qt::Dialog | Qt::FramelessWindowHint);
		~ProductResultTable();
		static ProductResultTable* GetInstance();
		static void	Destroy();
		void AddRowData(Utility::ProductResults& productResults, QIcon styleIcon);
		void AddColoums(QTableWidgetItem* parent, Utility::ProductResults& productResults, QIcon styleIcon);
		void SetBearerToken(const string& bearerToken);
		void CreateDownloadAttachmentsMap(int styleID);
		void GetStyleAttachments(json response);
		void DownloadStyleAttachments();

	private slots:

		void productResultTableBack_clicked();
		void productResultTableCancel_clicked();
		void productResultTableDownload_clicked();
		void callRadioSelected();
	};
}
