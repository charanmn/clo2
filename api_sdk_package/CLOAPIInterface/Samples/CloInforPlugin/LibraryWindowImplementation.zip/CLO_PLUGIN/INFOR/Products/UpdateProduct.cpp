#include "UpdateProduct.h"
#include "ui_UpdateProduct.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QLabel>
#include <QMessageBox>
#include <QCheckBox>
#include <any>
#include <optional>
#include "qlistview.h"
#include "CLO_PLUGIN/INFOR/Libraries/jsonQt.h"
#include "CLO_PLUGIN/INFOR/Libraries/json.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
#include "CLO_PLUGIN/INFOR/DesignSuite/DesignSuite.h"
#include "CLO_PLUGIN/INFOR/Utilities/ComboBoxItem.h"
#include "CLO_PLUGIN/INFOR/Utilities/Configuration.h"
#include "ProductResultTable.h"
#include "classes/APIDefine.h"

using json = nlohmann::json;

using namespace std;
using QtJson::JsonObject;
using QtJson::JsonArray;

namespace CLOPlugin
{
	string UpdateProduct::m_bearerToken = " ";
	UpdateProduct* UpdateProduct::_instance = NULL;

	UpdateProduct* UpdateProduct::GetInstance()
	{
		Utility::Logger("UpdateProduct -> GetInstance() -> Start");

		if (_instance == NULL)
		{
			_instance = new UpdateProduct();
		}

		Utility::Logger("UpdateProduct -> GetInstance() -> End");
		return _instance;
	}
	/**
	* \brief destructor of update product class
	*  deletes the object of this class. 
	*/
	void UpdateProduct::Destroy()
	{
		Utility::Logger("UpdateProduct -> Destroy() -> Start");

		if (_instance)
		{
			delete _instance;
			_instance = NULL;
		}

		Utility::Logger("UpdateProduct -> Destroy() -> End");
	}
	UpdateProduct::UpdateProduct(QWidget* parent) : QDialog(parent)
	{
		Utility::Logger("UpdateProduct -> Constructor() -> Start");

		setupUi(this);
		QFont fontStyle("Times new roman", 16, QFont::Bold);
		this->setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint | Qt::CustomizeWindowHint);
		QSize size(425, 500);

		updateProductTree->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		updateProductTree->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		updateProductTree->setStyleSheet("QTreeWidget::item { border-bottom: 1px solid #232323;""padding : 10px;""height: 25px;""}");
		updateProductTree->setFixedSize(size);
		updateProductTree->setColumnWidth(1, 210);
		updateProductTree->setColumnWidth(0, 195);
		label_up->setFont(fontStyle);
		layout()->setSizeConstraint(QLayout::SetFixedSize);
		this->adjustSize();

		back->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_back_over.svg"));
		back->setIconSize(QSize(iconHieght, iconWidth));

		updateInPlm->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_update_over.svg"));
		updateInPlm->setIconSize(QSize(iconHieght, iconWidth));

		saveAndClose->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_save_over.svg"));
		saveAndClose->setIconSize(QSize(iconHieght, iconWidth));

		QObject::connect(updateInPlm, SIGNAL(clicked()), this, SLOT(updateInPlm_clicked()));
		QObject::connect(saveAndClose, SIGNAL(clicked()), this, SLOT(saveAndClose_clicked()));
		QObject::connect(back, SIGNAL(clicked()), this, SLOT(back_clicked()));
		QObject::connect(close_Window, SIGNAL(clicked()), this, SLOT(closeWindow_clicked()));
		m_isSaveClicked = false;
		ReadPLMJson();
		ReadJsonAndDrawDialog();
		m_currentBrandIndex = 0;
		m_currentDivisionIndex = 0;
		m_currentCategoryIndex = 0;
		m_signalOrigin = 0;

		QTreeWidgetItem *dataItem1 = new QTreeWidgetItem;
		Qt::ItemFlags flags;
		flags = dataItem1->flags();
		flags |= Qt::ItemIsSelectable | Qt::ItemIsEditable | Qt::ItemIsEnabled;
		dataItem1->setFlags(flags);
		updateProductTree->setFocusPolicy(Qt::FocusPolicy::StrongFocus);	////
		updateProductTree->setSelectionBehavior(QAbstractItemView::SelectRows);
		updateProductTree->setSelectionBehavior(QAbstractItemView::SelectItems);
		updateProductTree->setTabKeyNavigation(true);

		string dependencies = GetDependencies(m_currentBrandIndex, m_currentDivisionIndex, m_currentCategoryIndex);
		SetDependenciesToWidgets(dependencies);
		
		Utility::Logger("UpdateProduct -> Constructor() -> End");
	}
	/**
	 * \brief Add labels in Update Product page from Json
	 */
	void UpdateProduct::ReadJsonAndDrawDialog()
	{
		Utility::Logger("UpdateProduct -> ReadJsonAndDrawDialog() -> Start");
		json jsonString;
		Utility::Fields tempField;
		ifstream styleSearchFile;
		styleSearchFile.open("C:\\MiddlewareFiles\\productSearchFiltered.json");
		styleSearchFile >> jsonString;
		styleSearchFile.close();
		string completeJsonString, uiTypeJSONObject, presetListJSONObject, fieldValues, mandatoryFields;
		completeJsonString = jsonString.dump();
		json completeJson = json::parse(completeJsonString);
		uiTypeJSONObject = completeJson["uiTypeList"].dump();
		json componentsJson = json::parse(uiTypeJSONObject);
		presetListJSONObject = completeJson["presetList"].dump();
		json presetListJSON = json::parse(presetListJSONObject);
		fieldValues = completeJson["fieldList"].dump();
		json fieldValuesJson = json::parse(fieldValues);

		mandatoryFields = completeJson["mandatory_fieldList"].dump();
		json mandatoryFieldsJson = json::parse(mandatoryFields);
		QStringList mandatoryFieldsList;

		for (int i = 0; i < mandatoryFieldsJson.size(); i++)
		{
			string mandatory = fieldValuesJson[i].dump();
			mandatory = mandatory.erase(0, 1);
			mandatory = mandatory.erase(mandatory.size() - 1);
			mandatoryFieldsList << QString::fromStdString(mandatory);
		}

		for (int i = 0; i < fieldValuesJson.size(); i++)
		{
			string fieldValuesString = fieldValuesJson[i].dump();
			fieldValuesString = fieldValuesString.erase(0, 1);
			fieldValuesString = fieldValuesString.erase(fieldValuesString.size() - 1);
			tempField.labelValue = QString::fromStdString(fieldValuesString);
			string uiTypes = componentsJson[fieldValuesString].dump();
			uiTypes = uiTypes.erase(0, 1);
			uiTypes = uiTypes.erase(uiTypes.size() - 1);
			tempField.fieldUItype = QString::fromStdString(uiTypes);
			if (tempField.fieldUItype == "dropdown")
			{
				string presetList = presetListJSON[fieldValuesString].dump();
				presetList = presetList.erase(0, 1);
				presetList = presetList.erase(presetList.size() - 1);
				presetList.erase(std::remove(presetList.begin(), presetList.end(), '\"'), presetList.end());
				QStringList listQt;
				listQt = QString::fromStdString(presetList).split(",");
				tempField.presetValues = listQt;
			}
			tempField.isMandatory = mandatoryFieldsList.contains(QString::fromStdString(fieldValuesString));
			m_updateFieldsVector.push_back(tempField);
		}
		DrawWidget(m_updateFieldsVector);
		
		Utility::Logger("UpdateProduct -> ReadJsonAndDrawDialog() -> End");
	}
	/**
	 * \brief Validates Mandatory Fields for Update Product
	 * \return bool
	 */
	bool UpdateProduct::MandatoryFieldsValidation()
	{
		Utility::Logger("UpdateProduct -> MandatoryFieldsValidation() -> Start");

		QLineEdit* qlineedit;
		string userValue;
		QString label;
		for (int i = 0; i < updateProductTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = updateProductTree->topLevelItem(i);
			QWidget* qWidgetColumn0 = updateProductTree->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = updateProductTree->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			label = qlabel->text();

			qlineedit = qobject_cast<QLineEdit*>(qWidgetColumn1);
			if (qlineedit) {
				m_updateFieldsVector[i].userInputValues = qlineedit->text();
			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
				if (qComboBox)
				{
					m_updateFieldsVector[i].userInputValues = qComboBox->currentText();
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
					if (qtextEdit)
					{
						m_updateFieldsVector[i].userInputValues = qtextEdit->toPlainText();
					}
				}
			}

			if (m_updateFieldsVector[i].isMandatory && m_updateFieldsVector[i].userInputValues.isEmpty())
			{
				UTILITY_API->DisplayMessageBox("Please fill all the mandatory fields...");
				return false;
			}
		}

		Utility::Logger("UpdateProduct -> MandatoryFieldsValidation() -> End");
		return true;
	}
	/**
	 * \brief Setting feild types for attributes for update Product
	 * \return bool
	 */
	void UpdateProduct::SetAllFields()
	{
		Utility::Logger("UpdateProduct -> SetAllFields() -> Start");

		if (IsSaveClicked())
		{
			for (int i = 0; i < updateProductTree->topLevelItemCount(); ++i)
			{
				QTreeWidgetItem* topItem = updateProductTree->topLevelItem(i);
				QWidget* qWidgetColumn0 = updateProductTree->itemWidget(topItem, 0);
				QWidget* qWidgetColumn1 = updateProductTree->itemWidget(topItem, 1);
				QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
				string label = qlabel->text().toStdString();
				QLineEdit* qlineedit = qobject_cast<QLineEdit*>(qWidgetColumn1);

				if (qlineedit)
				{
					qlineedit->setText(m_updateFieldsVector[i].userInputValues);
				 

				}
				else
				{
					QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
					if (qComboBox)
					{
						int index = qComboBox->findText(m_updateFieldsVector[i].userInputValues);
						qComboBox->setCurrentIndex(index);
					}
					else
					{
						QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
						if (qtextEdit)
						{
							qtextEdit->setText(m_updateFieldsVector[i].userInputValues);
						}
					}
				}
			}
		}
		else
		{
			for (int i = 0; i < updateProductTree->topLevelItemCount(); ++i)
			{
				QTreeWidgetItem* topItem = updateProductTree->topLevelItem(i);
				QWidget* qWidget = updateProductTree->itemWidget(topItem, 0);
				QWidget* qWidget1 = updateProductTree->itemWidget(topItem, 1);
				QLabel* qlabel = qobject_cast<QLabel*>(qWidget);
				QString label = qlabel->text();
				QLineEdit* qlineedit = qobject_cast<QLineEdit*>(qWidget1);
				int comboBoxIndex = 0;
				if (qlineedit)
				{
					//UTILITY_API->DisplayMessageBox("lable in setAllFields is ::" + lable);
					if (label.contains("Style Code"))
					{
						qlineedit->setText(m_ProductResults.styleCode);
						qlineedit->setDisabled(true);
					}
					if (label == "Name")
					{
						qlineedit->setText(m_ProductResults.styleName);
					}
				}
				else
				{
					QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidget1);
					if (qComboBox)
					{
					
						if (label.contains("Brand"))
						{
							comboBoxIndex = qComboBox->findText(m_ProductResults.brandName);
						}
						if (label == "Category")
						{
							comboBoxIndex = qComboBox->findText(m_ProductResults.categoryId);
						}
						if (label == "Collection")
						{
							comboBoxIndex = qComboBox->findText(m_ProductResults.collectionId);
						}
						if (label.contains("Division"))
						{
							comboBoxIndex = qComboBox->findText(m_ProductResults.divisionId);
						}
						if (label == "Season")
						{
							comboBoxIndex = qComboBox->findText(m_ProductResults.seasonId);
						}
						if (label == "SubCategory")
						{
							comboBoxIndex = qComboBox->findText(m_ProductResults.subCategoryId);
						}
						if (label == "SubSubCategory")
						{
							comboBoxIndex = qComboBox->findText(m_ProductResults.subSubCategoryId);
						}
						if (label == "User")
						{
							comboBoxIndex = qComboBox->findText(m_ProductResults.userId);
						}
						if (label == "Gender")
						{
							comboBoxIndex = qComboBox->findText(m_ProductResults.genderId);
						}
						if (label == "Status")
						{
							comboBoxIndex = qComboBox->findText(m_ProductResults.statusId);
						}
						qComboBox->setCurrentIndex(comboBoxIndex);
					}
					else
					{
						QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidget1);
						if (qtextEdit)
						{
							if (label == "Description")
							{
								qtextEdit->setText(m_ProductResults.description);
							}
							if (qtextEdit->toPlainText() == "ul")
							{
								qtextEdit->setText("");
							}
						}
					}
				}
			}
		}

		Utility::Logger("UpdateProduct -> SetAllFields() -> End");
	}
	/**
	* \brief Filter out Product Details Json
	*/
	void UpdateProduct::ReadPLMJson() 
	{
		Utility::Logger("UpdateProduct -> ReadPLMJson() -> Start");

		GetFilteredProductJson();
		json completeStyleJson;
		m_attsDropdownListMap.clear();
		m_attributeMap.clear();
		ifstream styleDetailsFile;
		styleDetailsFile.open("C:\\MiddlewareFiles\\styleDetails.json");

		styleDetailsFile >> completeStyleJson;
		styleDetailsFile.close();

		ofstream productSearchFile;
		productSearchFile.open("C:\\MiddlewareFiles\\productSearchFiltered.json");
		json finalJsontoSave;
		auto jsonFieldList = json::array();
		auto jsonUiTypeList = json::object();
		auto presetArray = json::array();
		auto presetList = json::object();
		auto jsonMandatoryFieldsList = json::array();
		int uiPresetCount = 0;
		string completeStyleJsonString, componentsString, compObjString;
		completeStyleJsonString = completeStyleJson.dump();
		json completeJson = json::parse(completeStyleJsonString);
		componentsString = completeJson["layout"]["components"].dump();
		json componentsJson = json::parse(componentsString);
		for (int i = 0; i < componentsJson.size(); i++) {
			compObjString = componentsJson[i].dump();
			json compObjJson = json::parse(compObjString);
			string propsString = compObjJson["props"].dump();
			json  propsJson = json::parse(propsString);
			string visible = propsJson["isVisibleAi"].dump();
			Utility::Logger("passed data::/n" + visible);

			if (visible == "true")
			{
				string isRequired = propsJson["isRequired"].dump();
				string fieldType = compObjJson["fieldType"].dump();
				string lookupRef = compObjJson["lookupRef"].dump();
				fieldType = fieldType.erase(0, 1);
				fieldType = fieldType.erase(fieldType.size() - 1);
				lookupRef = lookupRef.erase(0, 1);
				lookupRef = lookupRef.erase(lookupRef.size() - 1);

				string dataField = compObjJson["dataField"].dump();
				dataField = dataField.erase(0, 1);
				dataField = dataField.erase(dataField.size() - 1);

				if (lookupRef == "ul")
				{
					m_attributeMap.insert(std::make_pair(dataField, dataField));
					jsonUiTypeList[dataField] = fieldType;
					jsonFieldList.push_back(dataField);
					if (isRequired == "true")
					{
						jsonMandatoryFieldsList.push_back(dataField);
					}
				}
				else
				{
					m_attributeMap.insert(std::make_pair(lookupRef, dataField));
					jsonUiTypeList[lookupRef] = fieldType;
					jsonFieldList.push_back(lookupRef);
					if (isRequired == "true")
					{
						jsonMandatoryFieldsList.push_back(lookupRef);
					}
				}

				if (fieldType == "dropdown")

				{
					string lookups = completeJson["lookups"].dump();
					json lookupsJSON = json::parse(lookups);
					map<string, string> tempAttribMap;
					GetDropDownMap(lookupsJSON, lookupRef, tempAttribMap);
					presetArray.clear();
					presetArray.push_back("");
					for (auto it = tempAttribMap.begin(); it != tempAttribMap.end(); it++)
					{
						presetArray.push_back(it->first);
					}
					presetList[lookupRef] = presetArray;
					m_attsDropdownListMap.insert(std::make_pair(lookupRef, tempAttribMap));

				}	
			}
		}
		auto newjsonFieldList = json::array();
		newjsonFieldList.push_back("StyleCode");
		newjsonFieldList.push_back("Name");
		newjsonFieldList.push_back("Brand");
		newjsonFieldList.push_back("Division");
		newjsonFieldList.push_back("User");
		newjsonFieldList.push_back("Season");
		newjsonFieldList.push_back("Collection");
		newjsonFieldList.push_back("Status");
		newjsonFieldList.push_back("Category");
		newjsonFieldList.push_back("SubCategory");
		newjsonFieldList.push_back("SubSubCategory");
		newjsonFieldList.push_back("Gender");
		newjsonFieldList.push_back("Description");

		finalJsontoSave["fieldList"] = newjsonFieldList; // jsonFieldList;

		finalJsontoSave["uiTypeList"] = jsonUiTypeList;
		finalJsontoSave["presetList"] = presetList;
		finalJsontoSave["mandatory_fieldList"] = jsonMandatoryFieldsList;
		productSearchFile << finalJsontoSave;
		productSearchFile.close();

		Utility::Logger("UpdateProduct -> ReadPLMJson() -> End");
	}
	/**
	* \brief  Mapping Dropdown Values with Id
	* \param  lookUpsJson
	* \param  attributeValue
	* \param  attribMap
	*/
	void UpdateProduct::GetDropDownMap(json& lookUpsJson, string attributeValue, map<string, string>& attribMap)
	{
		Utility::Logger("UpdateProduct -> GetDropDownMap() -> Start");

		map<string, string> tempMap;
		for (int i = 0; i < lookUpsJson.size(); i++) {
			string lookupNameAndId = lookUpsJson[i].dump();
			json lookupNameAndIdJson = json::parse(lookupNameAndId);
			string colName = lookupNameAndIdJson["name"].dump();
			colName = colName.erase(0, 1);
			colName = colName.erase(colName.size() - 1);

			if (attributeValue.compare(colName) == 0)
			{
				string id, name;
				string columnStg = lookupNameAndIdJson["column"].dump();
				json colNameAndIdJson = json::parse(columnStg);
				id = colNameAndIdJson["Id"].dump();

				name = colNameAndIdJson["Name"].dump();
				name = name.erase(0, 1);
				name = name.erase(name.size() - 1);
			
				tempMap.insert(std::make_pair(name, id));
			}
		}
		attribMap = tempMap;
		
		Utility::Logger("UpdateProduct -> GetDropDownMap() -> End");
	}
	/**
	* \brief Clear all fields from widgets 
	*/
	void UpdateProduct::ClearAllFields()
	{
		Utility::Logger("UpdateProduct -> ClearAllFields() -> Start");
		m_signalOrigin = 0;
		for (int i = 0; i < updateProductTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = updateProductTree->topLevelItem(i);
			QWidget* qWidgetColumn0 = updateProductTree->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = updateProductTree->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string label = qlabel->text().toStdString();
			QLineEdit* qlineedit = qobject_cast<QLineEdit*>(qWidgetColumn1);

			if (qlineedit)
			{
				qlineedit->setText("");
			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
				if (qComboBox)
				{
					int indexOfEmptyString = qComboBox->findText("");
					qComboBox->setCurrentIndex(indexOfEmptyString);
					if (label == "Division" || label == "Category" || label == "SubCategory" || label == "SubSubCategory")
					{
						qComboBox->clear();
					}
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
					if (qtextEdit)
					{
						qtextEdit->setText("");
					}
				}
			}
		}
		
		Utility::Logger("UpdateProduct -> ClearAllFields() -> End");
	}
	/**
	* \brief Clears Downloaded Project Data
	*/
	void UpdateProduct::ClearDownloadedProjectData()
	{
		Utility::Logger("UpdateProduct -> ClearDownloadedProjectData() -> Start");

		m_ProductResults.styleId = "";
		m_ProductResults.styleCode = "";
		m_ProductResults.styleName = "";
		m_ProductResults.brandName = "";
		m_ProductResults.brandValue = "";
		m_ProductResults.imageFileName = "";
		m_ProductResults.imageAttaFileListId = "";
		m_ProductResults.attachmentFileName = "";
		m_ProductResults.attachmentAttaFileListId = "";
		m_ProductResults.statusId = "";
		m_ProductResults.divisionId = "";
		m_ProductResults.genderId = "";
		m_ProductResults.categoryId = "";
		m_ProductResults.subCategoryId = "";
		m_ProductResults.subSubCategoryId = "";
		m_ProductResults.collectionId = "";
		m_ProductResults.seasonId = "";
		m_ProductResults.description = "";
		m_ProductResults.userId = "";

		Utility::Logger("UpdateProduct -> ClearDownloadedProjectData() -> End");
	}
	/**
	* \brief Read User input values from Update product UI
	*/
	void UpdateProduct::ExtractAllUIValues()
	{
		Utility::Logger("UpdateProduct -> ExtractAllUIValues() -> Start");

		for (int i = 0; i < updateProductTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = updateProductTree->topLevelItem(i);
			QWidget* qWidgetColumn0 = updateProductTree->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = updateProductTree->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string label = qlabel->text().toStdString();
			QLineEdit* qlineedit = qobject_cast<QLineEdit*>(qWidgetColumn1);

			if (qlineedit)
			{
				m_updateFieldsVector[i].userInputValues = qlineedit->text();

			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
				if (qComboBox)
				{
					m_updateFieldsVector[i].userInputValues = qComboBox->currentText();
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
					if (qtextEdit)
					{
						m_updateFieldsVector[i].userInputValues = qtextEdit->toPlainText();
					}
				}
			}
		}

		Utility::Logger("UpdateProduct -> ExtractAllUIValues() -> End");
	}
	/**
	* \brief Sets type of widgets for labels
	* \param  fieldsVector
	*/
	void UpdateProduct::DrawWidget(std::vector<Utility::Fields>& fieldsVector)
	{
		Utility::Logger("UpdateProduct -> DrawWidget() -> Start");

		for each (auto field in fieldsVector)
		{
			if (field.fieldUItype == "text")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QLineEdit* lineEdit = new QLineEdit();
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				lineEdit->setStyleSheet(inputStyle);
				updateProductTree->addTopLevelItem(topLevel);
				updateProductTree->setItemWidget(topLevel, 0, label);
				updateProductTree->setItemWidget(topLevel, 1, lineEdit);
				
				if (field.labelValue == "StyleCode")
				{
					lineEdit->setDisabled(true);
				//	lineEdit->setStyleSheet("color: rgba(202, 255, 248, 210);"+ inputStyle);
				//	label->setStyleSheet("color: rgba(202, 255, 248, 210);"+ inputStyle);
					lineEdit->setText(m_ProductResults.styleCode);
				}
				if (field.isMandatory)
				{
					label->setText(QString::fromStdString(tempLabel) + "<font color='red'>*</font>");
				}
			}

			if (field.fieldUItype == "dropdown")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				ComboBoxItem* ComboBox = new ComboBoxItem(topLevel,1);
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				ComboBox->setStyleSheet(inputStyle);
				updateProductTree->addTopLevelItem(topLevel);
				updateProductTree->setItemWidget(topLevel, 0, label);
				updateProductTree->setItemWidget(topLevel, 1, ComboBox);
				if (field.labelValue == "Brand")
				{
					QObject::connect(ComboBox, SIGNAL(currentIndexChanged(const QString&)), this,
						SLOT(brandValueChanged(const QString&)));
				}
				if (field.labelValue == "Division")
				{
					QObject::connect(ComboBox, SIGNAL(currentIndexChanged(const QString&)), this,
						SLOT(divisionValueChanged(const QString&)));
				}
				if (field.labelValue == "Category")
				{
					QObject::connect(ComboBox, SIGNAL(currentIndexChanged(const QString&)), this,
						SLOT(categoryValueChanged(const QString&)));
				}
				ComboBox->setStyleSheet("combobox-popup: 0; font: 75 8pt \"Tahoma\"; ");
				int indexOfEmptyString = ComboBox->findText("");
				ComboBox->setCurrentIndex(indexOfEmptyString);
				ComboBox->addItems(field.presetValues);
				ComboBox->setEditText(field.userInputValues);
				if (field.isMandatory)
				{
					label->setText(QString::fromStdString(tempLabel) + "<font color='red'>*</font>");
				}
			}

			if (field.fieldUItype == "textarea")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QTextEdit* TextEdit = new QTextEdit();
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				updateProductTree->addTopLevelItem(topLevel);
				updateProductTree->setItemWidget(topLevel, 0, label);
				updateProductTree->setItemWidget(topLevel, 1, TextEdit);
				TextEdit->setText(field.userInputValues);
				TextEdit->setStyleSheet("border: 1px solid black;"
					"background-color: #222222;"
					"font: 75 8pt \"Tahoma\";"
				);
				TextEdit->setMaximumSize(190, 80);
				if (field.isMandatory)
				{
					label->setText(QString::fromStdString(tempLabel) + "<font color='red'>*</font>");
				}
			}

			if (field.fieldUItype == "DateEdit")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QDateEdit* dateTimeEdit = new QDateEdit();
				bool enable = true;
				dateTimeEdit->setCalendarPopup(enable);
				QString datericovero("");
				QDate date = QDate::fromString(datericovero, "");
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				updateProductTree->addTopLevelItem(topLevel);
				updateProductTree->setItemWidget(topLevel, 0, label);
				updateProductTree->setItemWidget(topLevel, 1, dateTimeEdit);

			}
		}	
		
		Utility::Logger("UpdateProduct -> DrawWidget() -> End");
	}
	/**
	* \brief Getting Dependency List to Pop-up values in drop down list
	* \param brand 
	* \param division 
	* \param category 
	* \return string 
	*/
	string UpdateProduct::GetDependencies(int brand, int division, int category)
	{
		json dependencyMap, styleInfoMap;

		styleInfoMap["BrandId"] = brand;
		styleInfoMap["DivisionId"] = division;
		styleInfoMap["SeasonId"] = nullptr;
		styleInfoMap["CollectionId"] = nullptr;
		styleInfoMap["GenderId"] = nullptr;
		styleInfoMap["CategoryId"] = category;
		styleInfoMap["SubCategoryId"] = nullptr;
		styleInfoMap["SubSubCategoryId"] = nullptr;
		styleInfoMap["DesignerId"] = nullptr;
		styleInfoMap["StatusId"] = 1;

		dependencyMap["userId"] = 71;
		dependencyMap["schema"] = "FSH5";
		dependencyMap["style"] = styleInfoMap;

		string parameter = to_string(dependencyMap);
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", DesignSuite::GetInstance()->GetBearerToken()));
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/adobe/api/adobeext/adobestyle/getfielddep", &parameter, headerNameAndValueList, "HTTP Post");

		return response;
	}
	/**
	* \brief Populate dependent values of Brand
	* \param  item
	*/
	void UpdateProduct::brandValueChanged(const QString& item)
	{
		if (item != "")
		{
			m_signalOrigin = 1;

			map<string, string> attNameIdMap;
			attNameIdMap.clear();
			attNameIdMap.insert(m_attsDropdownListMap["Brand"].begin(), m_attsDropdownListMap["Brand"].end());
			for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
			{
				if (it->first == item.toStdString())
				{
					m_currentBrandIndex = stoi(it->second);
					break;
				}
			}

			string dependencies = GetDependencies(m_currentBrandIndex, 0, 0);
			SetDependenciesToWidgets(dependencies);
		}
	}
	/**
	* \brief Populate dependent values of Division
	* \param  item
	*/
	void UpdateProduct::divisionValueChanged(const QString& item)
	{
		if (item != "")
		{
			m_signalOrigin = 2;
			map<string, string> attNameIdMap;
			attNameIdMap.clear();
			attNameIdMap.insert(m_attsDropdownListMap["Division"].begin(), m_attsDropdownListMap["Division"].end());
			for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
			{
				if (it->first == item.toStdString())
				{
					m_currentDivisionIndex = stoi(it->second);
					break;
				}
			}
			
			string dependencies = GetDependencies(m_currentBrandIndex, m_currentDivisionIndex, 0);
			SetDependenciesToWidgets(dependencies);
		}
	}
	/**
	* \brief Populate dependent values of category
	* \param  item
	*/
	void UpdateProduct::categoryValueChanged(const QString& item)
	{
		if (item != "")
		{
			m_signalOrigin = 3;
			map<string, string> attNameIdMap;
			attNameIdMap.clear();
			attNameIdMap.insert(m_attsDropdownListMap["Category"].begin(), m_attsDropdownListMap["Category"].end());
			for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
			{
				if (it->first == item.toStdString())
				{
					m_currentCategoryIndex = stoi(it->second);
					break;
				}
			}

			string dependencies = GetDependencies(m_currentBrandIndex, m_currentDivisionIndex, m_currentCategoryIndex);
			SetDependenciesToWidgets(dependencies);
		}
	}
	/**
	* \brief Setting Dependent values to widgets
	* \param  dependencies
	*/
	void UpdateProduct::SetDependenciesToWidgets(string dependencies)
	{
		string errorResponse = Utility::CheckErrorDescription(dependencies);

		string completeDependencies;
		json dependencyJson;
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			size_t found = dependencies.find("200");
			if (found != string::npos)
			{
				int indexforFlowerBrace = dependencies.find("{");
				completeDependencies = dependencies.substr(indexforFlowerBrace);
				std::replace(completeDependencies.begin(), completeDependencies.end(), '�', ' ');

				try
				{
					dependencyJson = json::parse(completeDependencies);
					SetPresetValues(dependencyJson);
				}
				catch (json::exception & err)
				{
					// output exception information
					Utility::Logger("message: " + QString(err.what()).toStdString() + '\n' + "exception id: " + to_string(err.id));
				}
			}
		}
		else
		{
			UTILITY_API->DisplayMessageBox(errorResponse);
		}
	}
	/**
	* \brief Setting Independent Values to widgets 
	* \param  dependencyJson
	*/
	void UpdateProduct::SetPresetValues(json dependencyJson)
	{
		for (int i = 0; i < updateProductTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = updateProductTree->topLevelItem(i);
			QWidget* qWidgetColumn0 = updateProductTree->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = updateProductTree->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string label = qlabel->text().toStdString();

			ComboBoxItem* qComboBox = qobject_cast<ComboBoxItem*>(qWidgetColumn1);
			if (qComboBox)
			{
				switch (m_signalOrigin)
				{
				case 0:
				{
					if ((label == "Division") || (label == "Category") || (label == "Sub Category") || (label == "Sub Sub Category"))
					{
						qComboBox->clear();
					}

				}
				break;
				case 1:
				{

					if ((label == "Division") || (label == "Category") || (label == "Sub Category") || (label == "Sub Sub Category"))
					{
						label = Utility::RemoveSpaces(label);
						string indexString = label + "List";
						string tempString = dependencyJson[indexString].dump();
						json tempJson = json::parse(tempString);
						if (tempJson.size() > 0)
						{
							qComboBox->clear();
							for (int i = 0; i < tempJson.size(); i++)
							{

								string item = tempJson[i]["Name"].dump();
								item = item.erase(0, 1);
								item = item.erase(item.size() - 1);
								qComboBox->addItem(QString::fromStdString(item));
							}

						}
					}
				}
				break;
				case 2:
				{
					if ((label == "Category") || (label == "Sub Category") || (label == "Sub Sub Category"))
					{
						label = Utility::RemoveSpaces(label);
						string indexString = label + "List";
						string tempString = dependencyJson[indexString].dump();
						json tempJson = json::parse(tempString);
						if (tempJson.size() > 0)
						{
							qComboBox->clear();
							for (int i = 0; i < tempJson.size(); i++)
							{
								string item = tempJson[i]["Name"].dump();
								item = item.erase(0, 1);
								item = item.erase(item.size() - 1);
								qComboBox->addItem(QString::fromStdString(item));
							}
						}
					}
				}
				break;
				case 3:
				{
					if ((label == "Sub Category") || (label == "Sub Sub Category"))
					{
						label = Utility::RemoveSpaces(label);
						string indexString = label + "List";
						string tempString = dependencyJson[indexString].dump();
						json tempJson = json::parse(tempString);
						if (tempJson.size() > 0)
						{
							qComboBox->clear();
							for (int i = 0; i < tempJson.size(); i++)
							{

								string item = tempJson[i]["Name"].dump();
								item = item.erase(0, 1);
								item = item.erase(item.size() - 1);
								qComboBox->addItem(QString::fromStdString(item));
							}
						}
					}
				}
				break;
				}
			}
		}
	}
	UpdateProduct::~UpdateProduct()
	{

	}
	/**
	* \brief Making Rest call to Update Product metadata and uploads latest document
	*/
	void UpdateProduct::UpdateProductMetaData()
	{
		Utility::Logger("UpdateProduct -> UpdateProductMetaData() -> Start");

		string parameter, bearerKey;
		json updateMap;
		json updateArray;
		json mapArray;

		string styleCodeForFilename = m_ProductResults.styleCode.toStdString();
		string dirPath;
		int count = 0;
		
		for (auto array_element : m_updateFieldsVector)
		{
			string attLabel = array_element.labelValue.toStdString();
			string userSelected = array_element.userInputValues.toStdString();
			if (userSelected != "")
			{
				if (array_element.fieldUItype == "dropdown")
				{
					for (auto it = m_attributeMap.begin(); it != m_attributeMap.end(); it++)
					{
						if (it->first == attLabel)
						{
							mapArray["fieldName"] = it->second;
							map<string, string> attNameIdMap;
							attNameIdMap.clear();
							attNameIdMap.insert(m_attsDropdownListMap[attLabel].begin(), m_attsDropdownListMap[attLabel].end());
							for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
							{
								if (it->first == userSelected)
								{
									mapArray["operator"] = "=";
									mapArray["value"] = stoi(it->second);
									break;
								}
							}
							break;
						}
					}
					updateMap["fieldValues"][count++] = mapArray;
					Utility::Logger("adding fieldvalues::" + to_string(mapArray));
				}
				else
				{
					if (attLabel != "StyleCode")
					{
						mapArray.clear();
						mapArray["fieldName"] = attLabel;
						mapArray["operator"] = "=";
						mapArray["value"] = userSelected;
						updateMap["fieldValues"][count++] = mapArray;
					}
				}
			}
		}
		updateMap["idGenContextVal"] = nullptr;
		updateMap["idGenVal"] = updateArray.array();
		updateMap["key"] = m_ProductResults.styleId.toStdString();

		updateMap["locale"] = "en-US";
		updateMap["modifyId"] = 71;
		updateMap["notificationMessageKey"] = "UPDATED_STYLE_OVERVIEW";
		updateMap["schema"] = "FSH5";
		updateMap["subEntities"] = updateArray.array();
		updateMap["userId"] = 71;

		string completeZprjProjectPath;
		
		if (m_ProductResults.attachmentFileName.isEmpty())
		{
			completeZprjProjectPath = UTILITY_API->GetProjectFilePath();
		}
		else
		{
			completeZprjProjectPath = STYLE_ATTACHMENTS_DIRECTORY + m_ProductResults.attachmentFileName.toStdString();
			
		}
		int fileSize = Utility::GetFileSize(completeZprjProjectPath);

		if (fileSize > UPLOAD_FILE_SIZE)
		{
			EXPORT_API->ExportZPrj(completeZprjProjectPath, true);
			parameter = to_string(updateMap);
			vector<pair<string, string>> headerNameAndValueList;
			headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
			headerNameAndValueList.push_back(make_pair("authorization", m_bearerToken));
			string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/adobe/api/pdm/style/save", &parameter, headerNameAndValueList, "HTTP Post");
			string errorResponse = Utility::CheckErrorDescription(response);
			if (errorResponse.empty() && (errorResponse.length() == 0))
			{
				this->close();
				size_t found = response.find("200");
				if (found != string::npos && response.find("ok"))
				{
					int indexForContentType = response.find("Content-Type:");
					string contentTypeString = response.substr(indexForContentType);
					int indexForJSON = contentTypeString.find("{");
					string strForJSON = contentTypeString.substr(indexForJSON);
					json keyJson = json::parse(strForJSON);
					string key = keyJson["key"].dump();
					
					string filepathImg;
					filepathImg = STYLE_ATTACHMENTS_DIRECTORY + m_ProductResults.imageFileName.toStdString();

					if (m_ProductResults.imageFileName.isEmpty())
					{
						string pathOfZprj = UTILITY_API->GetProjectFilePath();
						Utility::EraseSubString(pathOfZprj, UTILITY_API->GetProjectName());
						filepathImg = pathOfZprj + UTILITY_API->GetProjectName() + ".png";
					}
					else
					{
						filepathImg = STYLE_ATTACHMENTS_DIRECTORY + m_ProductResults.imageFileName.toStdString();
						//assuming that the image name is also same as the downloaded zprj , 
						//just the extension is .png instead of .zprj
					}
					
					string responseImg = Utility::UploadFile(filepathImg, m_bearerToken);
					
					if (responseImg != "Null")
					{
						string paramImg = CreateImageParam(responseImg, key);
						Utility::LinkAttachemntToStyle(paramImg, m_bearerToken);

						string responseZip = Utility::UploadFile(completeZprjProjectPath, m_bearerToken);
						if (responseZip != "Null")
						{
							string paramZip = CreateZipParam(responseZip, key);
							Utility::LinkAttachemntToStyle(paramZip, m_bearerToken);
							UTILITY_API->DisplayMessageBox("Product updated successfully in PLM");
							Utility::Logger("UpdateProduct -> Constructor() -> Product updated successfully");
						}
					}
				}
			}
			else 
			{
				UTILITY_API->DisplayMessageBox("ERROR::" + errorResponse);
				Utility::Logger("UpdateProduct -> updateProductMetaData() ->" + errorResponse);
			}
		}
		else
		{
			UTILITY_API->DisplayMessageBox("User doesn't have a design to Send to PLM");
			Utility::Logger("UpdateProduct -> updateProductMetaData() -> User not having design to PushToPLM");
		}

		Utility::Logger("UpdateProduct -> updateProductMetaData() -> End");
	}
	/**
	* \brief Creates Request to make Rest Call for Upload attachment
	* \param response 
	* \param key 
	* \return string
	*/
	string UpdateProduct::CreateZipParam(string response, string key)
	{
		Utility::Logger("UpdateProduct -> CreateZipParam() -> Start");

		int indexForContentType = response.find("Content-Type:");
		string contentTypeString = response.substr(indexForContentType);
		int indexForJSON = contentTypeString.find("{");
		string strForJSON = contentTypeString.substr(indexForJSON);
		json imgJson = json::parse(strForJSON);
		string objectKey = imgJson["addedFiles"][0]["objectKey"].dump();
		objectKey = objectKey.erase(0, 1);
		objectKey = objectKey.erase(objectKey.size() - 1);
		string oldFileName = imgJson["addedFiles"][0]["oldFileName"].dump();
		oldFileName = oldFileName.erase(0, 1);
		oldFileName = oldFileName.erase(oldFileName.size() - 1);
		json mainMap;
		json attaFileListDto;
		json attaFileListDtoMap;
		attaFileListDtoMap["referenceId"] = key;
		attaFileListDtoMap["code"] = "E0013";
		attaFileListDtoMap["objectKey"] = objectKey;
		attaFileListDtoMap["oldFileName"] = oldFileName;
		attaFileListDto[0] = attaFileListDtoMap;
		mainMap["modifyId"] = 71;
		mainMap["Schema"] = "FSH5";
		mainMap["AttaFileListDto"] = attaFileListDto;

		Utility::Logger("UpdateProduct -> CreateZipParam() -> End");
		return to_string(mainMap);
	}
	/**
	* \brief Creates Request to make Rest Call for Upload Image
	* \param response 
	* \param key 
	* \return string
	*/
	string UpdateProduct::CreateImageParam(string response, string key)
	{
		Utility::Logger("UpdateProduct -> createImageParam() -> Start");

		int indexForSuccess = response.find("200");
		string successString = response.substr(indexForSuccess);
		int indexForJSON = successString.find("{");
		string strForJSON = successString.substr(indexForJSON);
		json imgJson = json::parse(strForJSON);
		string objectKey = imgJson["addedFiles"][0]["objectKey"].dump();
		objectKey = objectKey.erase(0, 1);
		objectKey = objectKey.erase(objectKey.size() - 1);
		string oldFileName = imgJson["addedFiles"][0]["oldFileName"].dump();
		oldFileName = oldFileName.erase(0, 1);
		oldFileName = oldFileName.erase(oldFileName.size() - 1);
		json mainMap;
		json attaFileListDto;
		json detailsMap;
		json details;
		json attaFileListDtoMap;
		mainMap["modifyId"] = 71;
		mainMap["Schema"] = "FSH5";
		details["dlType"] = 11;
		detailsMap = details;
		attaFileListDtoMap["code"] = "E0012";
		attaFileListDtoMap["type"] = "Image";
		attaFileListDtoMap["objectKey"] = objectKey;
		attaFileListDtoMap["oldFileName"] = oldFileName;
		attaFileListDtoMap["referenceId"] = key;
		attaFileListDtoMap["details"] = detailsMap;
		attaFileListDto[0] = attaFileListDtoMap;
		mainMap["AttaFileListDto"] = attaFileListDto;

		Utility::Logger("UpdateProduct -> createImageParam() -> End");
		
		return to_string(mainMap);
	}
	/**
	* \brief On Click of UpdateInPLM,  Deleting old documents from Library, 
	* Unlinking Documents from product and updating metadeta and uplaoding latest document
	*/
	void UpdateProduct::updateInPlm_clicked()
	{
		Utility::Logger("UpdateProduct -> UpdateInPLMClicked() -> Start");

		m_isSaveClicked = false;
		if (MandatoryFieldsValidation())
		{
			this->hide();
			ExtractAllUIValues();
			int imageDocID = GetDocumentIdForFile(m_ProductResults.imageFileName.toStdString());
			int attachmentDocID = GetDocumentIdForFile(m_ProductResults.attachmentFileName.toStdString());
			DeleteDocuments(imageDocID, attachmentDocID);

			UnlinkDocuments(m_ProductResults.imageAttaFileListId.toStdString(), m_ProductResults.attachmentAttaFileListId.toStdString());
			UpdateProductMetaData();
			ClearDownloadedProjectData();
		}
		
		Utility::Logger("UpdateProduct -> UpdateInPLMClicked() -> End");
	}
	/**
	* \brief Makes Rest call to Unlink documents from product
	* \param imageAttaFileListId 
	* \param attachmentAttaFileListId 
	*/
	void UpdateProduct::UnlinkDocuments(string& imageAttaFileListId, string& attachmentAttaFileListId)
	{
		Utility::Logger("UpdateProduct -> UnlinkDocuments() -> Start");

		int imageId, attachmentsId;
		std::stringstream ss1(imageAttaFileListId);
		ss1 >> imageId;
		std::stringstream ss2(attachmentAttaFileListId);
		ss2 >> attachmentsId;

		json mainMap;
		mainMap["AttaFileListIds"][0] = imageId;
		mainMap["AttaFileListIds"][1] = attachmentsId;
		mainMap["Schema"] = "FSH5";
		string parameter = to_string(mainMap);
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", m_bearerToken));
		string responseUnLink = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/documents/api/document/DeleteObjectsMetadata", &parameter, headerNameAndValueList, "HTTP Post");

		Utility::Logger("UpdateProduct -> UnlinkDocuments() -> End");
	}
	/**
	* \brief Makes Rest call to delete documents from product
	* \param imageDocLibId 
	* \param attachmentDocLibId 
	*/
	void UpdateProduct::DeleteDocuments(int imageDocLibId, int attachmentDocLibId)
	{
		Utility::Logger("UpdateProduct -> DeleteDocuments() -> Start");

		json mainMap;
		mainMap["ids"][0] = imageDocLibId;
		mainMap["ids"][1] = attachmentDocLibId;
		mainMap["Schema"] = "FSH5";
		string parameter = to_string(mainMap);
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", m_bearerToken));
		string responseDelete = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/documents/api/document/doclib/delete", &parameter, headerNameAndValueList, "HTTP Post");

		Utility::Logger("UpdateProduct -> DeleteDocuments() -> End");
	}
	/**
	* \brief Method gets the response of Product Details from PLM
	* \param imageDocLibId 
	* \param attachmentDocLibId 
	*/
	void UpdateProduct::GetFilteredProductJson()
	{
		Utility::Logger("UpdateProduct -> GetFilteredProductJson() -> Start");

		//////////////to get 18000 lines
		ofstream styleDetailsFile;
		styleDetailsFile.open("C:\\MiddlewareFiles\\styleDetails.json");
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", DesignSuite::GetInstance()->GetBearerToken()));
		string parameter = "{\"roleId\":1,\"userId\":72,\"entity\":\"Style\",\"pageType\":\"details\",\"dataFilter\":{\"conditions\":[{\"fieldname\":\"StyleId\",\"operator\":\"=\",\"value\":\"\"}]},\"pageInfo\":{},\"Schema\":\"FSH5\"}";
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/adobe/api/view/layout/data/get", &parameter, headerNameAndValueList, "HTTP Post");
		string errorResponse = Utility::CheckErrorDescription(response);
		string completeDocLibs;
		json docLibjson;
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			size_t found = response.find("200");
			if (found != string::npos && response.find("OK"))
			{

				int indexforcontent = response.find("{");

				completeDocLibs = response.substr(indexforcontent);
				std::replace(completeDocLibs.begin(), completeDocLibs.end(), '�', ' ');

				try
				{
					docLibjson = json::parse(completeDocLibs);
				}
				catch (json::exception & err)
				{
					
				}

			
			}
		}
		styleDetailsFile << docLibjson;
		styleDetailsFile.close();

		Utility::Logger("UpdateProduct -> GetFilteredProductJson() -> End");
	}
	/**
	* \brief Makes rest call to get Document Id, which is used to delelte documents
	* \param filename 
	* \return int 
	*/
	int UpdateProduct::GetDocumentIdForFile(string& filename)
	{
		Utility::Logger("UpdateProduct -> GetDocumentIdForFile() -> Start");

		string column, docLibId;
		json mainMap;
		json conditionsFilter;
		json conditionMap;
		json pageInfoMap;
		mainMap.clear();
		mainMap["roleId"] = 1;
		mainMap["userId"] = 71;
		mainMap["entity"] = "DocLib";
		mainMap["personalizationId"] = 0;
		mainMap["pageType"] = "list";
		conditionsFilter["FieldName"] = "Filename";
		conditionsFilter["Operator"] = "=";
		conditionsFilter["Value"] = filename;
		conditionMap["Conditions"][0] = conditionsFilter;
		mainMap["dataFilter"] = conditionMap;
		pageInfoMap["page"] = 1;
		pageInfoMap["pageSize"] = 20;
		mainMap["pageInfo"] = pageInfoMap;
		mainMap["Schema"] = "FSH5";

		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", m_bearerToken));
		string parameter = to_string(mainMap);
		//Using this FileName we will Search for StyleAttachments By Below Rest Call.
		string responseStyleList = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/view/api/view/layout/data/get", &parameter, headerNameAndValueList, "HTTP Post");
		//From this response we will get DocObjId
		string errorResponse = Utility::CheckErrorDescription(responseStyleList);
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			size_t found = responseStyleList.find("200");
			if (found != string::npos && responseStyleList.find("ok"))
			{
				int indexForContentType = responseStyleList.find("Content-Type:");
				string contentTypeString = responseStyleList.substr(indexForContentType);
				int indexForFlowerBrace = contentTypeString.find("{");
				string strForJSON = contentTypeString.substr(indexForFlowerBrace);
				json docLibjson = json::parse(strForJSON);
				json completeDocLibsJson;
				string responseJsonStrStyle = docLibjson["entities"].dump();
				completeDocLibsJson = json::parse(responseJsonStrStyle);
				
				if (completeDocLibsJson.size() != 0)
				{
					for (int i = 0; i < completeDocLibsJson.size(); i++)
					{
						string entityJson = completeDocLibsJson[i].dump();
						json entities = json::parse(entityJson);
						string name = entities["name"].dump();
						name = name.erase(0, 1);
						name = name.erase(name.size() - 1);

						if (name == "DocLib")
						{
							column = entities["column"].dump();
							json columns = json::parse(column);

							docLibId = columns["DocLibId"].dump();
						}
					}
				}
			}
		}
		int docLibID;
		std::stringstream ss(docLibId);
		ss >> docLibID;

		Utility::Logger("UpdateProduct -> GetDocumentIdForFile() -> End");
		return docLibID;
	}
	/**
	* \brief sets bearer token to global variable 
	* \param  bearerToken
	*/
	void UpdateProduct::SetBearerToken(const string& bearerToken)
	{
		Utility::Logger("UpdateProduct -> SetBearerToken() -> Start");

		m_bearerToken = bearerToken;
		
		Utility::Logger("UpdateProduct -> SetBearerToken() -> End");
	}

	/**
	* \brief Saves the user entered values and closes the UI
	*/
	void UpdateProduct::saveAndClose_clicked()
	{
		Utility::Logger("UpdateProduct -> SaveAndCloseClicked() -> Start");

		m_isSaveClicked = true;
		if (MandatoryFieldsValidation())
		{
			ExtractAllUIValues();
		}
		Utility::Logger("UpdateProduct -> SaveAndCloseClicked() -> End");
	}
	/**
	* \brief On Back Clicked, It returns back to Design Suite
	*/
	void UpdateProduct::back_clicked()
	{
		Utility::Logger("UpdateProduct -> BackClicked() -> Start");

		this->hide();
		if (IsSaveClicked() == false)
		{
			m_signalOrigin = 0;
			ClearAllFields();
		}
		DesignSuite::GetInstance()->setModal(true);
		DesignSuite::GetInstance()->show();

		Utility::Logger("UpdateProduct -> BackClicked() -> End");
	}
	/**
	* \brief Stores User entered values for Update product
	* \param  data
	*/
	void UpdateProduct::FillUpdateProductData(Utility::ProductResults& data)
	{
		Utility::Logger("UpdateProduct -> FillUpdateProductData() -> Start");
		m_ProductResults = data;
		Utility::Logger("UpdateProduct -> FillUpdateProductData() -> End");
	}
	/**
	* \brief Closes the update product window
	*/
	void UpdateProduct::closeWindow_clicked()
	{
		Utility::Logger("UpdateProduct -> CloseWindowClicked() -> Start");

		this->close();
		if (IsSaveClicked() == false)
		{
			ClearAllFields();
		}

		Utility::Logger("UpdateProduct -> CloseWindowClicked() -> End");
	}
	/**
	* \brief Checks user save the entered data or not
	*/
	bool UpdateProduct::IsSaveClicked()
	{
		Utility::Logger("UpdateProduct -> IsSaveClicked() -> Start");

		if (m_isSaveClicked)
			return true;
		else
			return false;
	}
}