#pragma once

#include "createproduct.h"
#include "GeneratedFiles/ui_createproduct.h"
#include <QStringList>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QLabel>
#include <QMessageBox>
#include <QCheckBox>
#include "qlistview.h"
#include "classes/APIDefine.h"
#include "CLO_PLUGIN/INFOR/Libraries/json.h"
#include "CLO_PLUGIN/INFOR/Libraries/jsonQt.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
#include "CLO_PLUGIN/INFOR/DesignSuite/DesignSuite.h"
#include "CLO_PLUGIN/INFOR/Utilities/ComboBoxItem.h"


using namespace CLOPlugin;
using json = nlohmann::json;

using namespace std;
using QtJson::JsonObject;
using QtJson::JsonArray;

/**
 * \Handling complete logic for creating Product 
 */
namespace CLOPlugin
{
	createProduct* createProduct::_instance = NULL;
	string createProduct::m_bearerToken = " ";
	
	/**
	 * \brief Creating instance for createProduct class
	 * \return _instance 
	 */
	createProduct* createProduct::GetInstance()
	{
		Utility::Logger("createProduct -> GetInstance() -> Start");
		if (_instance == NULL) {
			_instance = new createProduct();
		}
		Utility::Logger("createProduct -> GetInstance() -> End");
		return _instance;
	}
	/**
	 * \brief Deletes created instance
	 */
	void createProduct::Destroy()
	{
		Utility::Logger("createProduct -> Destroy() -> Start");
		if (_instance) {
			delete _instance;
			_instance = NULL;
		}
		Utility::Logger("createProduct -> Destroy() -> Start");
	}
	
	/**
	 * \brief - Method will Initialize Create Product Dialog
	 * \param QWidget* parent 
	 */
	createProduct::createProduct(QWidget* parent) : QDialog(parent)
	{
		Utility::Logger("createProduct -> Constructor() -> Start");
		setupUi(this);
		QFont fontStyle("Times new roman", 16, QFont::Bold);
		this->setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint | Qt::CustomizeWindowHint);
		QSize size(425, 500);
		treeWidget_2->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		treeWidget_2->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		treeWidget_2->setStyleSheet("QTreeWidget::item { border-bottom: 1px solid #232323;""padding : 10px;""height: 25px;""}");
		treeWidget_2->setFixedSize(size);
		treeWidget_2->setColumnWidth(1, 210);
		treeWidget_2->setColumnWidth(0, 195);
		setHearderName->setFont(fontStyle);
		layout()->setSizeConstraint(QLayout::SetFixedSize);
		this->adjustSize();

		Back->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_back_over.svg"));
		Back->setIconSize(QSize(iconHieght, iconWidth));

		sendToPlm->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_goto_over.svg")); 
		sendToPlm->setIconSize(QSize(iconHieght, iconWidth));

		Save->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_save_over.svg"));
		Save->setIconSize(QSize(iconHieght, iconWidth));
		QObject::connect(Save, SIGNAL(clicked()), this, SLOT(Save_clicked()));
		QObject::connect(sendToPlm, SIGNAL(clicked()), this, SLOT(sendToPLM_clicked()));
		QObject::connect(closeWindow, SIGNAL(clicked()), this, SLOT(Cancle_clicked()));
		m_isSaveClicked = false;
		ReadPLMJson();
		ReadJsonAndDrawDialog();
		m_currentBrandIndex = 0;
		m_currentDivisionIndex = 0;
		m_currentCategoryIndex = 0;
		m_signalOrigin = 0;
		QTreeWidgetItem *dataItem = new QTreeWidgetItem;
		Qt::ItemFlags flags;
		flags = dataItem->flags();
		flags |= Qt::ItemIsSelectable | Qt::ItemIsEditable | Qt::ItemIsEnabled;
		dataItem->setFlags(flags);
		treeWidget_2->setFocusPolicy(Qt::FocusPolicy::StrongFocus);	
		treeWidget_2->setSelectionBehavior(QAbstractItemView::SelectRows);
		treeWidget_2->setSelectionBehavior(QAbstractItemView::SelectItems);
		treeWidget_2->setTabKeyNavigation(true);
		string dependencies = GetDependencies(m_currentBrandIndex, m_currentDivisionIndex, m_currentCategoryIndex);
		SetDependenciesToWidgets(dependencies);
		Utility::Logger("createProduct -> Constructor() -> end");
	}
	/**
	 * \brief Method sets BearerToken for Global Variable
	 * \param bearerToken 
	 */
	void createProduct::SetBearerToken( string& bearerToken)
	{
		Utility::Logger("createProduct -> SetBearerToken() -> Start");
		m_bearerToken = bearerToken;
		Utility::Logger("createProduct -> SetBearerToken() -> Start");
	}
	/**
	 * \brief Method returns true after Save button click on CreteProduct UI 
	 * \param  
	 * \return boolean 
	 */
	bool createProduct::IsSaveClicked()
	{
		Utility::Logger("createProduct -> IsSaveClicked() -> Start");
		if (m_isSaveClicked)
			return true;
		else
			return false;
	}
	/**
	 * \brief Read JSON to populate Search field for Product and Draw Dialog 
	 */
	void createProduct::ReadJsonAndDrawDialog()
	{
		Utility::Logger("createProduct -> ReadJsonAndDrawDialog() -> Start");
		json jsonString;
		Utility::Fields tempField;
		ifstream productSearchFile;
		productSearchFile.open("C:\\MiddlewareFiles\\productSearchFiltered.json");
		productSearchFile >> jsonString;
		productSearchFile.close();
		string completeJsonString, uiTypeJSONObject, presetListJSONObject, fieldValues, mandatoryFields;
		completeJsonString = jsonString.dump();
		json completeJson = json::parse(completeJsonString);
		uiTypeJSONObject = completeJson["uiTypeList"].dump();
		json componentsJson = json::parse(uiTypeJSONObject);
		presetListJSONObject = completeJson["presetList"].dump();
		json presetListJSON = json::parse(presetListJSONObject);
		fieldValues = completeJson["fieldList"].dump();
		json fieldValuesJson = json::parse(fieldValues);

		mandatoryFields = completeJson["mandatory_fieldList"].dump();
		json mandatoryFieldsJson = json::parse(mandatoryFields);
		QStringList mandatoryFieldsList;

		for (int i = 0; i < mandatoryFieldsJson.size(); i++)
		{
			string mandatory = fieldValuesJson[i].dump();
			mandatory = mandatory.erase(0, 1);
			mandatory = mandatory.erase(mandatory.size() - 1);
			mandatoryFieldsList << QString::fromStdString(mandatory);
		}

		for (int i = 0; i < fieldValuesJson.size(); i++)
		{
			string fieldValuesString = fieldValuesJson[i].dump();
			fieldValuesString = fieldValuesString.erase(0, 1);
			fieldValuesString = fieldValuesString.erase(fieldValuesString.size() - 1);
			tempField.labelValue = QString::fromStdString(fieldValuesString);
			string uiTypes = componentsJson[fieldValuesString].dump();
			uiTypes = uiTypes.erase(0, 1);
			uiTypes = uiTypes.erase(uiTypes.size() - 1);
			tempField.fieldUItype = QString::fromStdString(uiTypes);
			if (tempField.fieldUItype == "dropdown")
			{
				string presetList = presetListJSON[fieldValuesString].dump();
				presetList = presetList.erase(0, 1);
				presetList = presetList.erase(presetList.size() - 1);
				presetList.erase(std::remove(presetList.begin(), presetList.end(), '\"'), presetList.end());
				QStringList listQt;
				listQt = QString::fromStdString(presetList).split(",");
				tempField.presetValues = listQt;
			}
			tempField.isMandatory = mandatoryFieldsList.contains(QString::fromStdString(fieldValuesString));
			
			m_createFieldsVector.push_back(tempField);
		}
		DrawWidget(m_createFieldsVector);
		
		Utility::Logger("createProduct -> ReadJsonAndDrawDialog() -> end");
	}
	
	/**
	 * \brief Method creates widgets for the fields read from JSON
	 * \param vector
	 */
	void createProduct::DrawWidget(std::vector<Utility::Fields>& fieldsVector)
	{
		Utility::Logger("createProduct -> DrawWidget() -> Start");

		for each (auto field in fieldsVector)
		{
			if (field.fieldUItype == "text")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();  
				QLineEdit* LineEdit = new QLineEdit();						
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				LineEdit->setStyleSheet(inputStyle);
				treeWidget_2->addTopLevelItem(topLevel);						
				treeWidget_2->setItemWidget(topLevel, 0, label);				
				treeWidget_2->setItemWidget(topLevel, 1, LineEdit);
				LineEdit->setText(field.userInputValues);
				if (field.isMandatory)
				{
					label->setText(QString::fromStdString(tempLabel) + "<font color='red'>*</font>");
				}
			}

			if (field.fieldUItype == "dropdown")
			{	
				QTreeWidgetItem* topLevel = new QTreeWidgetItem;
				ComboBoxItem* comboBoxItem = new ComboBoxItem(topLevel, 1);
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);	
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				comboBoxItem->setStyleSheet(inputStyle);
				treeWidget_2->addTopLevelItem(topLevel);
				treeWidget_2->setItemWidget(topLevel, 0, label);
				treeWidget_2->setItemWidget(topLevel, 1, comboBoxItem);
				if (field.labelValue == "Brand")
				{
					QObject::connect(comboBoxItem, SIGNAL(currentIndexChanged(const QString&)), this,
						SLOT(brandValueChanged(const QString&)));
				}
				if (field.labelValue == "Division")
				{
					QObject::connect(comboBoxItem, SIGNAL(currentIndexChanged(const QString&)), this,
						SLOT(divisionValueChanged(const QString&)));
				}
				if (field.labelValue == "Category")
				{
					QObject::connect(comboBoxItem, SIGNAL(currentIndexChanged(const QString&)), this,
						SLOT(categoryValueChanged(const QString&)));
				}
				comboBoxItem->setStyleSheet("combobox-popup: 0; font: 75 8pt \"Tahoma\"; ");
				comboBoxItem->addItems(field.presetValues);
				int indexOfEmptyString = comboBoxItem->findText("");
				comboBoxItem->setCurrentIndex(indexOfEmptyString);
				if (field.isMandatory)
				{
					label->setText(QString::fromStdString(tempLabel) + "<font color='red'>*</font>");
				}
			}

			if (field.fieldUItype == "textarea")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();  
				QTextEdit* TextEdit = new QTextEdit();						
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				treeWidget_2->addTopLevelItem(topLevel);						
				treeWidget_2->setItemWidget(topLevel, 0, label);				
				treeWidget_2->setItemWidget(topLevel, 1, TextEdit);
				TextEdit->setText(field.userInputValues);
				TextEdit->setStyleSheet("border: 1px solid black;"
					"background-color: #222222;"
					"font: 75 8pt \"Tahoma\";"
				);
				TextEdit->setMaximumSize(190, 80);
				if (field.isMandatory)
				{
					label->setText(QString::fromStdString(tempLabel) + "<font color='red'>*</font>");
				}
			}
			if (field.fieldUItype == "DateEdit")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QDateEdit* DateTimeEdit = new QDateEdit();
				bool enable = true;
				DateTimeEdit->setCalendarPopup(enable);			
				QString dataRecovery("");
				QDate date = QDate::fromString(dataRecovery, "");
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				treeWidget_2->addTopLevelItem(topLevel);
				treeWidget_2->setItemWidget(topLevel, 0, label);
				treeWidget_2->setItemWidget(topLevel, 1, DateTimeEdit);
				if (field.isMandatory)
				{
					label->setText(QString::fromStdString(tempLabel) + "<font color='red'>*</font>");
				}
			}
		}
		
		Utility::Logger("createProduct -> DrawWidget() -> end");
	}
	/**
	 * \brief Method returns dependencies list from RestCall of Infor 
	 * \param int brand,division,category
	 * \return response 
	 */
	string createProduct::GetDependencies(int brand, int division, int category)
	{
		json dependencyMap, styleInfoMap;
		styleInfoMap["BrandId"] = brand;
		styleInfoMap["DivisionId"] = division;
		styleInfoMap["SeasonId"] = nullptr;
		styleInfoMap["CollectionId"] = nullptr;
		styleInfoMap["GenderId"] = nullptr;
		styleInfoMap["CategoryId"] = category;
		styleInfoMap["SubCategoryId"] = nullptr;
		styleInfoMap["SubSubCategoryId"] = nullptr;
		styleInfoMap["DesignerId"] = nullptr;
		styleInfoMap["StatusId"] = 1;
		dependencyMap["userId"] = 71;
		dependencyMap["schema"] = "FSH5";
		dependencyMap["style"] = styleInfoMap;
		string parameter = to_string(dependencyMap);
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", DesignSuite::GetInstance()->GetBearerToken()));
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/adobe/api/adobeext/adobestyle/getfielddep", &parameter, headerNameAndValueList, "HTTP Post");

		return response;
	}
	/**
	 * \brief Method Populates dependent values of Brand
	 * \param QString  
	 */
	void createProduct::brandValueChanged(const QString& item)
	{
		if (item != "")
		{
			m_signalOrigin = 1;
			map<string, string> attNameIdMap;
			attNameIdMap.clear();
			attNameIdMap.insert(m_attsDropdownListMap["Brand"].begin(), m_attsDropdownListMap["Brand"].end());
			for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
			{
				if (it->first == item.toStdString())
				{
					m_currentBrandIndex = stoi(it->second);
					break;
				}
			}
			string dependencies = GetDependencies(m_currentBrandIndex, 0, 0);
			SetDependenciesToWidgets(dependencies);
		}
	}
	/**
	 * \brief Method Populates dependent values of Division
	 * \param QString  
	 */
	void createProduct::divisionValueChanged(const QString& item)
	{
		if (item != "")
		{
			m_signalOrigin = 2;
			map<string, string> attNameIdMap;
			attNameIdMap.clear();
			attNameIdMap.insert(m_attsDropdownListMap["Division"].begin(), m_attsDropdownListMap["Division"].end());
			for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
			{
				if (it->first == item.toStdString())
				{
					m_currentDivisionIndex = stoi(it->second);
					break;
				}
			}
			string dependencies = GetDependencies(m_currentBrandIndex, m_currentDivisionIndex, 0);
			SetDependenciesToWidgets(dependencies);
		}
	}
	/**
	 * \brief Method Populates dependent values of Category
	 * \param QString  
	 */
	void createProduct::categoryValueChanged(const QString& item)
	{
		if (item != "")
		{
			m_signalOrigin = 3;
			map<string, string> attNameIdMap;
			attNameIdMap.clear();
			attNameIdMap.insert(m_attsDropdownListMap["Category"].begin(), m_attsDropdownListMap["Category"].end());
			for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
			{
				if (it->first == item.toStdString())
				{
					m_currentCategoryIndex = stoi(it->second);
					break;
				}
			}
			string dependencies = GetDependencies(m_currentBrandIndex, m_currentDivisionIndex, m_currentCategoryIndex);
			SetDependenciesToWidgets(dependencies);
		}
	}
	/**
	 * \brief Method sets Dependencies Values to Widgets
	 * \param string dependencies
	 */
	void createProduct::SetDependenciesToWidgets(string dependencies)
	{
		string errorResponse = Utility::CheckErrorDescription(dependencies);
		string completeDependencies;
		json dependencyJson;
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			size_t found = dependencies.find("200");
			if (found != string::npos )
			{
				int indexforcontent = dependencies.find("{");
				completeDependencies = dependencies.substr(indexforcontent);
				std::replace(completeDependencies.begin(), completeDependencies.end(), '�', ' ');
				try
				{
					dependencyJson = json::parse(completeDependencies);
					SetPresetValues(dependencyJson);
				}
				catch (json::exception & err)
				{
					Utility::Logger("message: " + QString(err.what()).toStdString() + '\n'
						+ "exception id: " + to_string(err.id));
				}
			}
		}
		else
		{
			UTILITY_API->DisplayMessageBox(errorResponse);
		}
	}
	/**
	 * \brief Method sets pre defined values for Widgets 
	 * \param json dependencyJson 
	 */
	void createProduct::SetPresetValues(json dependencyJson)
	{
		for (int i = 0; i < treeWidget_2->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = treeWidget_2->topLevelItem(i);
			QWidget* qWidgetColumn0 = treeWidget_2->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = treeWidget_2->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string label = qlabel->text().toStdString();
			ComboBoxItem* qComboBox = qobject_cast<ComboBoxItem*>(qWidgetColumn1);
			if (qComboBox)
			{
				switch (m_signalOrigin)
				{
					case 0:
					{
						if ((label == "Division") || (label == "Category") || (label == "Sub Category") || (label == "Sub Sub Category"))
						{
							qComboBox->clear();
						}
							
					}
					break;
					case 1:
					{

						if ((label == "Division") || (label == "Category") || (label == "Sub Category") || (label == "Sub Sub Category"))
						{
							label = Utility::RemoveSpaces(label);
							string indexString = label + "List";
							string tempString = dependencyJson[indexString].dump();
							json tempJson = json::parse(tempString);
							if (tempJson.size() > 0)
							{
								qComboBox->clear();
								for (int i = 0; i < tempJson.size(); i++)
								{

									string item = tempJson[i]["Name"].dump();
									item = item.erase(0, 1);
									item = item.erase(item.size() - 1);
									qComboBox->addItem(QString::fromStdString(item));
								}

							}
						}
					}
					break;
					case 2:
					{
						if ((label == "Category") || (label == "Sub Category") || (label == "SubSub Category"))
						{
							label = Utility::RemoveSpaces(label);
							string indexString = label + "List";
							string tempString = dependencyJson[indexString].dump();
							json tempJson = json::parse(tempString);
							if (tempJson.size() > 0)
							{
								qComboBox->clear();
								for (int i = 0; i < tempJson.size(); i++)
								{
									string item = tempJson[i]["Name"].dump();
									item = item.erase(0, 1);
									item = item.erase(item.size() - 1);
									qComboBox->addItem(QString::fromStdString(item));
								}

							}
						}
					}
					break;
					case 3:
					{
						if ((label == "Sub Category") || (label == "Sub Sub Category"))
						{
							label = Utility::RemoveSpaces(label);
							string indexString = label + "List";
							string tempString = dependencyJson[indexString].dump();
							json tempJson = json::parse(tempString);
							if (tempJson.size() > 0)
							{
								qComboBox->clear();
								for (int i = 0; i < tempJson.size(); i++)
								{
									string item = tempJson[i]["Name"].dump();
									item = item.erase(0, 1);
									item = item.erase(item.size() - 1);
									qComboBox->addItem(QString::fromStdString(item));
								}

							}
						}
					}
					break;
				}				
			}
		}
	}
	/**
	 * \brief Destructor
	 */
	createProduct::~createProduct()
	{
		
	}
	/**
	 * \brief Method clears all the values of the fields
	 */
	void createProduct::ClearAllFields()
	{
		Utility::Logger("createProduct -> ClearAllFields() -> Start");
		m_signalOrigin = 0;
		for (int i = 0; i < treeWidget_2->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = treeWidget_2->topLevelItem(i);
			QWidget* qWidgetColumn0 = treeWidget_2->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = treeWidget_2->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string label = qlabel->text().toStdString();
			QLineEdit* qlineedit = qobject_cast<QLineEdit*>(qWidgetColumn1);
			if (qlineedit)
			{
				qlineedit->setText("");
			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
				if (qComboBox)
				{
					if (label == "Status")
					{
						int indexOfConcept = qComboBox->findText("In Concept");
						qComboBox->setCurrentIndex(indexOfConcept);
					}
					else
					{
						int indexOfEmptyString = qComboBox->findText("");
						qComboBox->setCurrentIndex(indexOfEmptyString);
						if (label == "Division" || label == "Category" || label == "Sub Category" || label == "Sub Sub Category")
						{
							qComboBox->clear();
						}
					}
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
					if (qtextEdit)
					{
						qtextEdit->setText("");
					}
				}
			}
		}
		
		Utility::Logger("createProduct -> ClearAllFields() -> End");
	}
	/**
	 * \brief Method Validates whether mandatory fields are filled or not
	 * \return boolean 
	 */
	bool createProduct::MandatoryFieldsValidation()
	{
		Utility::Logger("createProduct -> MandatoryFieldsValidation() -> Start");
		QLineEdit* qlineedit;
		string userValue;
		QString label1;
		for (int i = 0; i < treeWidget_2->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = treeWidget_2->topLevelItem(i);
			QWidget* qWidgetColumn0 = treeWidget_2->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = treeWidget_2->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			label1 = qlabel->text();
			qlineedit = qobject_cast<QLineEdit*>(qWidgetColumn1);
			if (qlineedit) {
				m_createFieldsVector[i].userInputValues = qlineedit->text();
			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
				if (qComboBox)
				{
					m_createFieldsVector[i].userInputValues = qComboBox->currentText();
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
					if (qtextEdit)
					{
						m_createFieldsVector[i].userInputValues = qtextEdit->toPlainText();
					}
				}
			}
			if (m_createFieldsVector[i].isMandatory && m_createFieldsVector[i].userInputValues.isEmpty())
			{
				UTILITY_API->DisplayMessageBox("Please fill all the mandatory fields...");
				return false;
			}
		}
		
		Utility::Logger("createProduct -> MandatoryFieldsValidation() -> End");
		return true;
	}
	/**
	 * \brief Method reads dropdown values from JSON
	 * \param json& lookUpsJson, string attributeValue, map<string, string>& attribMap 
	 */
	void createProduct::GetDropDownMap(json& lookUpsJson, string attributeValue, map<string, string>& attribMap)
	{	
		Utility::Logger("createProduct -> GetDropDownMap() -> Start");
		map<string, string> tempMap;
		for (int i = 0; i < lookUpsJson.size(); i++) {
			string lookupNameAndId = lookUpsJson[i].dump();
			json lookupNameAndIdJson = json::parse(lookupNameAndId);
			string colName = lookupNameAndIdJson["name"].dump();
			colName = colName.erase(0, 1);
			colName = colName.erase(colName.size() - 1);
			if (attributeValue.compare(colName) == 0)
			{
				string id, name;
				string columnStg = lookupNameAndIdJson["column"].dump();
				json colNameAndIDJSON = json::parse(columnStg);
				id = colNameAndIDJSON["Id"].dump();
				name = colNameAndIDJSON["Name"].dump();
				name = name.erase(0, 1);
				name = name.erase(name.size() - 1);
				tempMap.insert(std::make_pair(name, id));				
			}
		}
		attribMap = tempMap;
		
		Utility::Logger("createProduct -> GetDropDownMap() -> End");
	}
	/**
	 * \brief Method reads JSON which generated after making RestCall to PLM
	 */
	void  createProduct::ReadPLMJson() 
	{
		Utility::Logger("createProduct -> ReadPLMJson() -> Start");
		GetFilteredProductJson();
		json completeStyleJson;
		m_attsDropdownListMap.clear();
		m_attributeMap.clear();
		ifstream styleDetailsFile;
		styleDetailsFile.open("C:\\MiddlewareFiles\\styleDetails.json");
		styleDetailsFile >> completeStyleJson;
		styleDetailsFile.close();
		ofstream styleSearchFile;
		styleSearchFile.open("C:\\MiddlewareFiles\\productSearchFiltered.json");
		json finalJsontoSave;
		auto jsonFieldList = json::array();
		auto jsonUiTypeList = json::object();
		auto jsonDataFieldList = json::object();
		auto presetArray = json::array();
		auto presetList = json::object();
		auto jsonMandatoryFieldsList = json::array();
		int uiPresetCount = 0;
		string completeStyleJsonString, componentsString, compObjString;
		completeStyleJsonString = completeStyleJson.dump();
		json completeJson = json::parse(completeStyleJsonString);
		componentsString = completeJson["layout"]["components"].dump();
		json componentsJson = json::parse(componentsString);
		for (int i = 0; i < componentsJson.size(); i++) {
			compObjString = componentsJson[i].dump();
			json compObjJson = json::parse(compObjString);
			string propsString = compObjJson["props"].dump();
			json  propsJson = json::parse(propsString);
			string visible = propsJson["isVisibleAi"].dump();
			Utility::Logger("passed data::/n" + visible);
			if (visible == "true") 
			{
				string isRequired = propsJson["isRequired"].dump();
				string fieldType = compObjJson["fieldType"].dump();
				fieldType = fieldType.erase(0, 1);
				fieldType = fieldType.erase(fieldType.size() - 1);
				string lookupRef = compObjJson["lookupRef"].dump();
				lookupRef = lookupRef.erase(0, 1);
				lookupRef = lookupRef.erase(lookupRef.size() - 1);
				string dataField = compObjJson["dataField"].dump();
				dataField = dataField.erase(0, 1);
				dataField = dataField.erase(dataField.size() - 1);
				if (lookupRef == "ul")
				{
					m_attributeMap.insert(std::make_pair(dataField, dataField));
					jsonUiTypeList[dataField] = fieldType;
					jsonDataFieldList[dataField] = dataField;
					jsonFieldList.push_back(dataField);
					if (isRequired == "true")
					{
						jsonMandatoryFieldsList.push_back(dataField);
					}
				}
				else
				{
					m_attributeMap.insert(std::make_pair(lookupRef, dataField));
					jsonUiTypeList[lookupRef] = fieldType;
					jsonDataFieldList[lookupRef] = dataField;
					jsonFieldList.push_back(lookupRef);
					if (isRequired == "true")
					{
						jsonMandatoryFieldsList.push_back(lookupRef);
					}
				}
				if (fieldType == "dropdown")
				{
					string lookups = completeJson["lookups"].dump();
					json lookupsJSON = json::parse(lookups);
					map<string, string> tempAttribMap;
					GetDropDownMap(lookupsJSON, lookupRef, tempAttribMap);
					presetArray.clear();
					presetArray.push_back("");
					for (auto it = tempAttribMap.begin(); it != tempAttribMap.end(); it++)
					{
						presetArray.push_back(it->first);
					}
					presetList[lookupRef] = presetArray;
					m_attsDropdownListMap.insert(std::make_pair(lookupRef, tempAttribMap));
				}
			}
		}
		auto newjsonFieldList = json::array();
		newjsonFieldList.push_back("StyleCode");
		newjsonFieldList.push_back("Name");
		newjsonFieldList.push_back("Brand");
		newjsonFieldList.push_back("Division");
		newjsonFieldList.push_back("User");
		newjsonFieldList.push_back("Season");
		newjsonFieldList.push_back("Collection");
		newjsonFieldList.push_back("Status");
		newjsonFieldList.push_back("Category");
		newjsonFieldList.push_back("SubCategory");
		newjsonFieldList.push_back("SubSubCategory");
		newjsonFieldList.push_back("Gender");
		newjsonFieldList.push_back("Description");

		finalJsontoSave["fieldList"] = newjsonFieldList;//jsonFieldList;
		finalJsontoSave["uiTypeList"] = jsonUiTypeList;
		finalJsontoSave["presetList"] = presetList;
		finalJsontoSave["mandatory_fieldList"] = jsonMandatoryFieldsList;
		finalJsontoSave["dataFieldList"] = jsonDataFieldList;
		styleSearchFile << finalJsontoSave;
		styleSearchFile.close();
		Utility::Logger("createProduct -> readPLMJson() -> End");
	}
	/**
	 * \brief Method gets the response of Product Details from PLM
	 */
	void createProduct::GetFilteredProductJson()
	{
		Utility::Logger("createProduct -> GetFilteredProductJson() -> Start");
		//to get 18000 lines from Infor
		ofstream styleDetailsFile;
		styleDetailsFile.open("C:\\MiddlewareFiles\\styleDetails.json");
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", DesignSuite::GetInstance()->GetBearerToken()));
		string parameter = "{\"roleId\":1,\"userId\":72,\"entity\":\"Style\",\"pageType\":\"details\",\"dataFilter\":{\"conditions\":[{\"fieldname\":\"StyleId\",\"operator\":\"=\",\"value\":\"\"}]},\"pageInfo\":{},\"Schema\":\"FSH5\"}";
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/adobe/api/view/layout/data/get", &parameter, headerNameAndValueList, "HTTP Post");
		string errorResponse = Utility::CheckErrorDescription(response);
		string completeDocLibs;
		json docLibjson;
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			size_t found = response.find("200");
			if (found != string::npos && response.find("OK"))
			{
				int indexforcontent = response.find("{");
				completeDocLibs = response.substr(indexforcontent);
				std::replace(completeDocLibs.begin(), completeDocLibs.end(), '�', ' ');
				try
				{
					docLibjson = json::parse(completeDocLibs);
				}
				catch (json::exception & err)
				{
					Utility::Logger( "message: " + QString(err.what()).toStdString() + '\n'
							+ "exception id: " + to_string(err.id) );
				}

			}
		
		}
		styleDetailsFile << docLibjson;
		styleDetailsFile.close();
		Utility::Logger("createProduct -> GetFilteredProductJson() -> End");
	}
	/**
	 * \brief Method Creates map of Key and Fields Values to Send to PLM
	 */
	void createProduct::CreateProductCreateMap()
	{
		Utility::Logger("createProduct -> CreateProductCreateMap() -> Start");
		this->hide();
		string parameter, bearerKey;
		json updateMap;
		json emptyArray;
		json mapArray;
		string dirPath;
		int count = 0;
		for (auto arrayElement : m_createFieldsVector)
		{
			string attLabel = arrayElement.labelValue.toStdString(); // Brand
			string userSelected = arrayElement.userInputValues.toStdString();
			if (userSelected != "")
			{
				if (arrayElement.fieldUItype == "dropdown")
				{
					for (auto it = m_attributeMap.begin(); it != m_attributeMap.end(); it++)
					{
						if (it->first == attLabel)
						{
							mapArray["fieldName"] = it->second;
							map<string, string> attNameIdMap;
							attNameIdMap.clear();
							attNameIdMap.insert(m_attsDropdownListMap[attLabel].begin(), m_attsDropdownListMap[attLabel].end());
							for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
							{
								if (it->first == userSelected)
								{
									mapArray["operator"] = "=";
									mapArray["value"] = stoi(it->second);
									break;
								}
							}
							break;
						}
					}
					m_createProductMap["fieldValues"][count++] = mapArray;
					Utility::Logger("adding fieldvalues::" + to_string(mapArray));
				}
				else
				{
					mapArray.clear();
					mapArray["fieldName"] = attLabel;
					mapArray["operator"] = "=";
					mapArray["value"] = userSelected;
					m_createProductMap["fieldValues"][count++] = mapArray;
				}
			}
		}

		m_createProductMap["subEntities"] = emptyArray.array();
		m_createProductMap["modifyId"] = 71;
		m_createProductMap["idGenContextVal"] = nullptr;
		m_createProductMap["idGenVal"] = emptyArray.array();
		m_createProductMap["locale"] = "en-US";
		m_createProductMap["schema"] = "FSH5";
		
		Utility::Logger("createProduct -> CreateProductCreateMap() -> End");
	}
	/**
	 * \brief Method saves filled values of user from UI
	 */
	void createProduct::Save_clicked()
	{
		Utility::Logger("createProduct -> SaveClicked() -> Start");
		m_isSaveClicked = true;
		if (MandatoryFieldsValidation())
		{
			CreateProductCreateMap();
			UTILITY_API->DisplayMessageBox("Newly created product metadata has been saved successfully locally");
		}
		Utility::Logger("createProduct -> SaveClicked() -> End");
	}
	/**
	 * \brief - Goes to previous UI tab
	 */
	void createProduct::on_Back_clicked()
	{
		Utility::Logger("createProduct -> OnBackClicked() -> Start");
		this->hide();
		if (IsSaveClicked() == false)
		{
			ClearAllFields();
		}
		DesignSuite::GetInstance()->setModal(true);
		DesignSuite::GetInstance()->show();
		Utility::Logger("createProduct -> OnBackClicked() -> End");
	}
	
	/**
	 * \brief Closes the current UI tab
	 */
	void createProduct::Cancle_clicked()
	{
		Utility::Logger("createProduct -> CancelClicked() -> Start");
		this->close();
		if (IsSaveClicked() == false)
		{
			ClearAllFields();
		}
		Utility::Logger("createProduct -> CancelClicked() -> End");
	}

	/**
	 * \brief When User clicks on Send to PLM, Method will collect all the information and sends to PLM
	 */
	void createProduct::sendToPLM_clicked()
	{
		Utility::Logger("createProduct -> SendToPLMClicked() -> Start");
		UTILITY_API->CreateProgressBar();
		UTILITY_API->SetProgress("Sending to PLM...", 50);
		m_isSaveClicked = false;
		if (MandatoryFieldsValidation())
		{
			CreateProductCreateMap();
			this->hide();
			string dirPath;
			string parameter;
			parameter = to_string(m_createProductMap);
			string filePathZPRJ = UTILITY_API->GetProjectFilePath();
			string pathOfzprj = UTILITY_API->GetProjectFilePath();
			Utility::EraseSubString(pathOfzprj, UTILITY_API->GetProjectName());
			int fileSize = Utility::GetFileSize(filePathZPRJ);
			Utility::Logger("filesize::" + to_string(fileSize));
			if (fileSize > UPLOAD_FILE_SIZE)
			{
				string exportZprj = EXPORT_API->ExportZPrj(filePathZPRJ, true);
				string filepathZip = pathOfzprj + UTILITY_API->GetProjectName() + ".zprj";
				string responseZip = Utility::UploadFile(filepathZip, m_bearerToken);
				if (responseZip != "Null")
				{
					string filepathImg = pathOfzprj + UTILITY_API->GetProjectName() + ".png";
					string responseImg = Utility::UploadFile(filepathImg, m_bearerToken);
					if (responseImg != "Null")
					{
						vector<pair<string, string>> headerNameAndValueList;
						headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
						headerNameAndValueList.push_back(make_pair("authorization", m_bearerToken));
						string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/adobe/api/pdm/style/save", &parameter, headerNameAndValueList, "HTTP Post");
						string errorResponse = Utility::CheckErrorDescription(response);
						if (errorResponse.empty())
						{
							size_t found = response.find("200");
							if (found != string::npos && response.find("ok"))
							{
								int indexForContent = response.find("Content-Type:");
								string strForCheck = response.substr(indexForContent);
								int indexForJSON = strForCheck.find("{");
								string strForJSON = strForCheck.substr(indexForJSON);
								json keyjson = json::parse(strForJSON);
								string key = keyjson["key"].dump();
								//Linking Zprj
								string paramZip = CreateZipParam(responseZip, key);
								Utility::LinkAttachemntToStyle(paramZip, m_bearerToken);
								//Linking Image
								string paramImg = CreateImageParam(responseImg, key);
								Utility::LinkAttachemntToStyle(paramImg, m_bearerToken);
								UTILITY_API->DisplayMessageBox("Product Created Successfully in PLM");
								Utility::Logger("createProduct -> getInstance() -> Created Successfully");
							}
						}
						else
						{
							UTILITY_API->DisplayMessageBox(errorResponse);
							Utility::Logger("createProduct -> sendToPLM_clicked() ->" + errorResponse);
						}
					}
				}
				UTILITY_API->DeleteProgressBar(false);
			}
			else
			{
				UTILITY_API->DisplayMessageBox("User doesn't have a design to Send to PLM");
			}
		}
		Utility::Logger("createProduct -> SendToPLMClicked() -> End");
	}
	/**
	 * \brief creates related parameter for Image to send to PLM
	 * \param string response, string key 
	 * \return string 
	 */
	string createProduct::CreateImageParam(string response, string key)
	{
		Utility::Logger("createProduct -> createImageParam() -> Start");
		int indexForSuccessResponse = response.find("200");
		string SuccessString = response.substr(indexForSuccessResponse);
		int indexForFlowerBrace = SuccessString.find("{");
		string strForJSON = SuccessString.substr(indexForFlowerBrace);
		json ImgJson = json::parse(strForJSON);
		string objectKey = ImgJson["addedFiles"][0]["objectKey"].dump();
		objectKey = objectKey.erase(0, 1);
		objectKey = objectKey.erase(objectKey.size() - 1);
		string oldFileName = ImgJson["addedFiles"][0]["oldFileName"].dump();
		oldFileName = oldFileName.erase(0, 1);
		oldFileName = oldFileName.erase(oldFileName.size() - 1);
		json mainMap;
		json attsFileList;
		json detailsMap;
		json details;
		json attaFileListtoMap;
		mainMap["modifyId"] = 71;
		mainMap["Schema"] = "FSH5";
		details["dlType"] = 11;
		detailsMap = details;
		attaFileListtoMap["code"] = "E0012";
		attaFileListtoMap["type"] = "Image";
		attaFileListtoMap["objectKey"] = objectKey;
		attaFileListtoMap["oldFileName"] = oldFileName;
		attaFileListtoMap["referenceId"] = key;
		attaFileListtoMap["details"] = detailsMap;
		attsFileList[0] = attaFileListtoMap;
		mainMap["AttaFileListDto"] = attsFileList;
		Utility::Logger("createProduct -> createImageParam() -> End");
		
		return to_string(mainMap);
	}
	/**
	 * \brief creates related parameter for Zprj to send to PLM
	 * \param string response, string key 
	 * \return string 
	 */
	string createProduct::CreateZipParam(string response, string key)
	{
		Utility::Logger("createProduct -> CreateZipParam() -> Start");
		int indexForContentType = response.find("Content-Type:");
		string ContentTypeString = response.substr(indexForContentType);
		int indexForFlowerBrace = ContentTypeString.find("{");
		string strForJSON = ContentTypeString.substr(indexForFlowerBrace);
		json ImgJson = json::parse(strForJSON);
		string objectKey = ImgJson["addedFiles"][0]["objectKey"].dump();
		objectKey = objectKey.erase(0, 1);
		objectKey = objectKey.erase(objectKey.size() - 1);
		string oldFileName = ImgJson["addedFiles"][0]["oldFileName"].dump();
		oldFileName = oldFileName.erase(0, 1);
		oldFileName = oldFileName.erase(oldFileName.size() - 1);
		json mainMap;
		json attsFileList;
		json attsFileListtoMap;
		attsFileListtoMap["referenceId"] = key;
		attsFileListtoMap["code"] = "E0013";
		attsFileListtoMap["objectKey"] = objectKey;
		attsFileListtoMap["oldFileName"] = oldFileName;
		attsFileList[0] = attsFileListtoMap;
		mainMap["modifyId"] = 71;
		mainMap["Schema"] = "FSH5";
		mainMap["AttaFileListDto"] = attsFileList;
		Utility::Logger("createProduct -> createZipParam() -> End");
		
		return to_string(mainMap);
	}	
}