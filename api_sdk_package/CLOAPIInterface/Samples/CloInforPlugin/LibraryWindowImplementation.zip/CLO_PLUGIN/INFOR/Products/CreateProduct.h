#ifndef CREATEPRODUCT_H
#define CREATEPRODUCT_H

#include <QDialog>
#include <string>
#include <iostream>
#include <QMainWindow>
#include <QLineEdit>
#include <QTextEdit>
#include <QDateTimeEdit>
#include <QComboBox>
#include <QLabel>
#include <QTreeWidgetItem>
#include <QTableWidgetItem>
#include <vector>
#include <map>
#include "GeneratedFiles/ui_createproduct.h"
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"

#include "CLO_PLUGIN/INFOR/Libraries/json.h"
using json = nlohmann::json;

namespace CLOPlugin
{
	class  createProduct : public QDialog, public Ui::createProduct
	{
		Q_OBJECT
		static createProduct* _instance;
		std::vector<Utility::Fields> m_createFieldsVector;
		static string m_bearerToken;
		json m_createProductMap;
		bool m_isSaveClicked;
		std::map<string, string> m_attributeMap;
		map<string, map<string, string>> m_attsDropdownListMap;
		int m_currentBrandIndex;
		int m_currentDivisionIndex;
		int m_currentCategoryIndex;
		int m_signalOrigin;
	public:
		static createProduct* GetInstance();
		static void			Destroy();
		createProduct(QWidget* parent = 0);
		~createProduct();
		void GetFilteredProductJson();
		void SetBearerToken(string& bearerToken);
		void GetDropDownMap(json& lookUpsJson, string attributeValue, map<string, string>& attributeMap);
		void ReadJsonAndDrawDialog();
		bool MandatoryFieldsValidation();
		void DrawWidget(std::vector<Utility::Fields>& fieldsVector);
		void ReadPLMJson();
		void CreateProductCreateMap();
		string CreateImageParam(string response, string key);
		string CreateZipParam(string response, string key);
		void ClearAllFields();
		bool IsSaveClicked();
		string GetDependencies(int brand, int division, int category);
		void SetDependenciesToWidgets(string dependencies);
		void SetPresetValues(json dependencyJson);

	private slots:
		void Save_clicked();
		void Cancle_clicked();
		void on_Back_clicked();
		void sendToPLM_clicked();
		//void comboIndexChanged(const QString& text);
		void brandValueChanged(const QString& item);
		void divisionValueChanged(const QString& item);
		void categoryValueChanged(const QString& item);
	signals:
		void CreateProductBackClicked();
	};
}
#endif // CREATEPRODUCT_H
