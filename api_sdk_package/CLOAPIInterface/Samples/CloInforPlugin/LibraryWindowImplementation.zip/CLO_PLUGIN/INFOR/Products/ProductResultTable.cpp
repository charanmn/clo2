#pragma once
#include "ProductResultTable.h"
#include "CLO_PLUGIN/INFOR/DesignSuite/DesignSuite.h"
#include "ProductSearch.h"
#include "UpdateProduct.h"
#include <qmessagebox.h>
#include <qcheckbox.h>
#include <direct.h>
#include "classes/APICLODataBase.h"
#include "classes/APIStorage.h"
#include <CLOAPIInterface.h>
#include "qobject.h"
#include "classes/APIStorage.h"

using namespace std;
namespace CLOPlugin
{
	string ProductResultTable::m_bearerToken = " ";
	ProductResultTable* ProductResultTable::_instance = NULL;
	/**
	 * \brief Instantiate ProductResultTable object
	 * \return
	 */
	ProductResultTable* ProductResultTable::GetInstance()
	{
		Utility::Logger("ProductResultTable -> GetInstance() -> Start");
		if (_instance == NULL)
		{
			_instance = new ProductResultTable();
		}
		Utility::Logger("ProductResultTable -> GetInstance() -> End");
		return _instance;
	}
	/**
	 * \brief Destroys instantiated ProductResultTable object
	 */
	void ProductResultTable::Destroy()
	{
		Utility::Logger("ProductResultTable -> Destroy() -> Start");
		if (_instance)
		{
			delete _instance;
			_instance = NULL;
		}
		Utility::Logger("ProductResultTable -> Destroy() -> End");
	}
	/**
	 * \brief Prepares the complete result table using Widgets as parameter
	 * \param parent
	 * \param flags
	 */
	ProductResultTable::ProductResultTable(QWidget* parent, Qt::WindowFlags flags) : QDialog(parent, flags)
	{
		Utility::Logger("ProductResultTable -> Constructor() -> Start");
		
		setupUi(this);
		QFont font;
		font.setPointSize(14);
		font.setBold(true);
		ProductResultTable_2->setColumnCount(13);
		ProductResultTable_2->horizontalHeader()->setFont(font);
		ProductResultTable_2->setWordWrap(true);
		ProductResultTable_2->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		ProductResultTable_2->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		ProductResultTable_2->horizontalHeader()->setResizeMode(QHeaderView::Stretch);
		ProductResultTable_2->setStyleSheet("QTableWidget{font-family: Times new roman;}");
		ProductResultTable_2->horizontalHeader()->setFixedHeight(80);
		ProductResultTable_2->horizontalHeader()->setDefaultSectionSize(80);
		ProductResultTable_2->verticalHeader()->setDefaultSectionSize(80);
		ProductResultTable_2->setEditTriggers(QAbstractItemView::NoEditTriggers);
		m_headerItem = new QTreeWidgetItem;
		QStringList headerlist;
		headerlist << "Select" << "StyleCode" << "Name" << "Image" << "StyleId" << "Brand" << "Division" << "Season" << "Collection" << "Status" << "Category" << "  Sub\nCategory " << " Sub Sub\nCategory";
		ProductResultTable_2->setHorizontalHeaderLabels(headerlist);

		back->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_back_over.svg"));
		back->setIconSize(QSize(iconHieght, iconWidth));

		download->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_down_over.svg"));
		download->setIconSize(QSize(iconHieght, iconWidth));

		QObject::connect(download, SIGNAL(clicked()), this, SLOT(productResultTableDownload_clicked()));
		QObject::connect(cancel, SIGNAL(clicked()), this, SLOT(productResultTableCancel_clicked()));
		QObject::connect(back, SIGNAL(clicked()), this, SLOT(productResultTableBack_clicked()));
		m_attachmentsFileName = "";
		
		Utility::Logger("ProductResultTable -> Constructor() -> End");
	}

	ProductResultTable::~ProductResultTable()
	{

	}
	/**
	 * \brief Adds rows data to Results table for Products
	 * \param productResults 
	 * \param styleIcon 
	 */
	void ProductResultTable::AddRowData(Utility::ProductResults& productResults, QIcon styleIcon)
	{
		Utility::Logger("ProductResultTable -> AddRowData() -> Start");
		QTableWidgetItem* headerItem = new QTableWidgetItem();
		AddColoums(headerItem, productResults, styleIcon);
		m_productResults.push_back(productResults);
		Utility::Logger("ProductResultTable -> AddRowData() -> End");
	}
	/**
	 * \brief Add columns to Result table
	 * \param parent 
	 * \param productResults 
	 * \param styleIcon 
	 */
	void ProductResultTable::AddColoums(QTableWidgetItem* parent, Utility::ProductResults& productResults, QIcon styleIcon)
	{
		Utility::Logger("ProductResultTable -> AddColoums() -> Start");
		
		QString styleSheet = "::section {""color: white;""border: 1px grey;""text-align: right;""font-family: arial;""font-size: 14px; }";
		ProductResultTable_2->horizontalHeader()->setStyleSheet(styleSheet);
		ProductResultTable_2->verticalHeader()->setStyleSheet(styleSheet);
		int currentRow = ProductResultTable_2->rowCount();
		ProductResultTable_2->setRowCount(currentRow + 1);
		for (int c = 0; c < ProductResultTable_2->columnCount(); ++c)
		{
			QTableWidgetItem* dataItem = new QTableWidgetItem;
			dataItem->setTextAlignment(Qt::AlignCenter);
			Qt::ItemFlags flags;
			flags = dataItem->flags();
			flags |= Qt::ItemIsSelectable | Qt::ItemIsEditable;
			dataItem->setFlags(flags);
			ProductResultTable_2->setStyleSheet("QTableWidget::indicator:unchecked {background-color:white;}");
			QRadioButton* radioButton = new QRadioButton;
			radioButton->setCheckable(true);
			radioButton->setStyleSheet("margin-left:30%; margin-right:70%;");
			ProductResultTable_2->setCellWidget(currentRow, 0, radioButton);
			QTableWidgetItem* iconItem = new QTableWidgetItem;
			iconItem->setTextAlignment(Qt::AlignCenter);
			ProductResultTable_2->setIconSize(QSize(80, 80));
			iconItem->setSizeHint(QSize(80, 80));
			iconItem->setIcon(styleIcon);
			QTableWidgetItem* itemStyleCode = new QTableWidgetItem(productResults.styleCode);
			itemStyleCode->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemStyleId = new QTableWidgetItem(productResults.styleId);
			itemStyleId->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemName = new QTableWidgetItem(productResults.styleName);
			itemName->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemBrand = new QTableWidgetItem(productResults.brandName);
			itemBrand->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemDivision = new QTableWidgetItem(productResults.divisionId);
			itemDivision->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemSeason = new QTableWidgetItem(productResults.seasonId);
			itemSeason->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemCollection = new QTableWidgetItem(productResults.collectionId);
			itemCollection->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemStatus = new QTableWidgetItem(productResults.statusId);
			itemStatus->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemCategory = new QTableWidgetItem(productResults.categoryId);
			itemCategory->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemSubCategory = new QTableWidgetItem(productResults.subCategoryId);
			itemSubCategory->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* ItemSubSubCat = new QTableWidgetItem(productResults.subSubCategoryId);
			ItemSubSubCat->setTextAlignment(Qt::AlignCenter);
			ProductResultTable_2->setItem(currentRow, 1, itemStyleCode);
			ProductResultTable_2->setItem(currentRow, 4, itemStyleId);
			ProductResultTable_2->setItem(currentRow, 3, iconItem);
			ProductResultTable_2->setItem(currentRow, 2, itemName);
			ProductResultTable_2->setItem(currentRow, 5, itemBrand);
			ProductResultTable_2->setItem(currentRow, 6, itemDivision);
			ProductResultTable_2->setItem(currentRow, 7, itemSeason);
			ProductResultTable_2->setItem(currentRow, 8, itemCollection);
			ProductResultTable_2->setItem(currentRow, 9, itemStatus);
			ProductResultTable_2->setItem(currentRow, 10, itemCategory);
			ProductResultTable_2->setItem(currentRow, 11, itemSubCategory);
			ProductResultTable_2->setItem(currentRow, 12, ItemSubSubCat);
			QObject::connect(radioButton, SIGNAL(clicked()), this, SLOT(callRadioSelected()));
		}
		
		Utility::Logger("ProductResultTable -> addColoums() -> End");
	}
	/**
	 * \brief When download button clicked by user, it download corresponding details of product
	 */
	void  ProductResultTable::productResultTableDownload_clicked()
	{
		Utility::Logger("ProductResultTable -> ProductResultTableDownloadClicked() -> Start");
		const char* newDirPath = STYLE_ATTACHMENTS_DIRECTORY.c_str();
		mkdir(newDirPath);
		int rowCount = ProductResultTable_2->rowCount();
		int columnCount = ProductResultTable_2->columnCount();
		QString styleCode;
		QString styleName;
		QString styleId;
		QString brand;
		QString imageLoadPath;
		QString imageSavePath;
		QString imageFileName;
		bool isSelected = false;
		for (int row = 0; row < rowCount; row++)
		{
			QTableWidgetItem* item = ProductResultTable_2->verticalHeaderItem(row);
			QWidget* qWidget = ProductResultTable_2->cellWidget(row, 0);
			QRadioButton* tempRadioButton = qobject_cast<QRadioButton*>(qWidget);
			if (tempRadioButton->isChecked())
			{
				isSelected = true;
			}
		}
		if (isSelected == false)
		{
			UTILITY_API->DisplayMessageBox("Select one row to download");
		}
		else
		{
			this->hide();
			for (int row = 0; row < rowCount; row++)
			{
				QTableWidgetItem* item = ProductResultTable_2->verticalHeaderItem(row);
				QWidget* qWidget = ProductResultTable_2->cellWidget(row, 0);
				QRadioButton* tempRadioButton = qobject_cast<QRadioButton*>(qWidget);
				if (tempRadioButton->isChecked())
				{
					styleCode = ProductResultTable_2->item(row, 1)->text();
					styleId = ProductResultTable_2->item(row, 4)->text();
					styleName = ProductResultTable_2->item(row, 2)->text();
					for (int i = 0; i < m_productResults.size(); i++)
					{
						if (styleId == m_productResults[i].styleId)
						{
							imageFileName = m_productResults[i].imageFileName;
							imageLoadPath = QString::fromStdString(PRODUCTS_TEMP_DIRECTORY) + imageFileName;
							imageSavePath = QString::fromStdString(STYLE_ATTACHMENTS_DIRECTORY) + imageFileName;
							brand = m_productResults[i].brandName;
						}
					}
					QImage imgNew;
					imgNew.load(imageLoadPath);
					imgNew.save(imageSavePath);
					CreateDownloadAttachmentsMap(styleId.toInt());
					DownloadStyleAttachments();
					if (m_attachmentsFileName != "")
					{
						const Marvelous::ImportZPRJOption option;
						IMPORT_API->ImportZprj(STYLE_ATTACHMENTS_DIRECTORY + m_attachmentsFileName, option);
					}
					if (m_attachmentsFileName != "" || imageFileName != "")
					{
						CLOAPISample::LibraryAPIItem* setItem = new CLOAPISample::LibraryAPIItem();
						setItem->itemID = styleId;
						if (m_attachmentsFileName != "")
						{
							setItem->itemName = QString::fromStdString(m_attachmentsFileName);
							setItem->sampleItemData.itemPath = QString::fromStdString(m_attachmentsFileName);
						}
						else
						{
							setItem->itemName = imageFileName;
							setItem->sampleItemData.itemPath = imageFileName;
						}
						setItem->dateTime = "2019-08-20T16:21:41";
						setItem->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("PRODUCT");
						setItem->metaData[META_DATA_KEY_2_BRAND] = brand;
						setItem->metaData[META_DATA_KEY_8_PRODUCT_NAME] = styleName;
						setItem->metaData[META_DATA_KEY_9_PRODUCT_ID] = styleId;
						setItem->metaData[META_DATA_KEY_10_PRODUCT_NUMBER] = styleCode;
						setItem->sampleItemData.iconThumbnailPath = imageFileName;
						setItem->sampleItemData.previewThumbnailPath = imageFileName;
						bool alreadyExists = false;
						if (API_STORAGE)
						{
							for (int i = 0; i < API_STORAGE->m_LibraryAPIItemList.size(); i++)
							{
								if (API_STORAGE->m_LibraryAPIItemList[i]->metaData[META_DATA_KEY_10_PRODUCT_NUMBER] == styleCode)
								{
									API_STORAGE->m_LibraryAPIItemList[i] = setItem;
									alreadyExists = true;
									break;
								}
							}
							if (!alreadyExists)
								API_STORAGE->m_LibraryAPIItemList.push_back(setItem);
						}
					}
				
					break;
				}
			}
			wstring wide_string = wstring(PRODUCTS_TEMP_DIRECTORY.begin(), PRODUCTS_TEMP_DIRECTORY.end());
			//UTILITY::remove_dir(wide_string.c_str());

			for (int i = 0; i < m_productResults.size(); i++)
			{
				if (styleId == m_productResults[i].styleId)
				{
					m_productResults[i].styleCode = styleCode;
					m_productResults[i].attachmentFileName = QString::fromStdString(m_attachmentsFileName);
					m_productResults[i].attachmentAttaFileListId = QString::fromStdString(m_attachmentsAttaFileListId);
					UpdateProduct::GetInstance()->FillUpdateProductData(m_productResults[i]);
				}
			}
			UTILITY_API->DisplayMessageBox("Download completed");
			Utility::Logger("ProductResultTable -> ProductResultTableDownloadClicked() -> Download completed");
		}
		
		Utility::Logger("ProductResultTable -> ProductResultTableDownloadClicked() -> End");
	}
	/**
	 * \brief Downloads all attachments of style from json
	 */
	void ProductResultTable::DownloadStyleAttachments()
	{
		Utility::Logger("ProductResultTable -> DownloadStyleAttachments() -> Start");
		
		string parameters = to_string(m_downloadAttachmentsMap);
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", m_bearerToken));
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/view/api/view/layout/data/get", &parameters, headerNameAndValueList, "HTTP Post");
		json responseJson;
		string errorResponse = Utility::CheckErrorDescription(response);
		if (errorResponse.empty())
		{
			int indexForContentType = response.find("Content-Type:");
			string ContentTypeString = response.substr(indexForContentType);
			int indexForFlowerBrace = ContentTypeString.find("{");
			string strForJSON = ContentTypeString.substr(indexForFlowerBrace);
			responseJson = json::parse(strForJSON);
			GetStyleAttachments(responseJson);
		}
		else
		{
			UTILITY_API->DisplayMessageBox("ERROR::" + errorResponse);
			Utility::Logger("ProductResultTable -> DownloadStyleAttachments() ->" + errorResponse);
		}
		
		Utility::Logger("ProductResultTable -> DownloadStyleAttachments() -> End");
	}
	/**
	 * \brief Looks for Check box selection and collects all selected rows
	 */
	void ProductResultTable::callRadioSelected()
	{

		int rowCount1 = ProductResultTable_2->rowCount();
		for (int row = 0; row < rowCount1; row++)
		{
			QWidget* qWidget = ProductResultTable_2->cellWidget(row, 0);
			QRadioButton* tempRadioButton = qobject_cast<QRadioButton*>(qWidget);  //setCellWidget(currentRow, 0, radioButton);
			if (tempRadioButton->isChecked())
			{
				ProductResultTable_2->selectRow(row);
			}
		}
	}
	/**
	 * \brief Creates map of attachments to bo downloaded
	 * \param styleID 
	 */
	void ProductResultTable::CreateDownloadAttachmentsMap(int styleID)
	{
		Utility::Logger("ProductResultTable -> CreateDownloadAttachmentsMap() -> Start");
		json filterMap;
		json pageInfoMap;
		json conditions = json::object();
		m_downloadAttachmentsMap.clear();
		m_downloadAttachmentsMap["roleId"] = 1;
		m_downloadAttachmentsMap["userId"] = 71;
		m_downloadAttachmentsMap["schema"] = "FSH5";
		m_downloadAttachmentsMap["entity"] = "StyleAttachments";
		m_downloadAttachmentsMap["pageType"] = "list";
		m_downloadAttachmentsMap["personalizationId"] = 0;
		m_downloadAttachmentsMap["pageInfo"] = nullptr;
		m_downloadAttachmentsMap["sortInfo"] = nullptr;
		filterMap.clear();
		filterMap["fieldname"] = "IsDeleted";
		filterMap["operator"] = "=";
		filterMap["value"] = 0;
		conditions["Conditions"][0] = filterMap;
		filterMap.clear();
		filterMap["fieldname"] = "Code";
		filterMap["operator"] = "=";
		filterMap["value"] = "E0013";
		filterMap["logicalOperator"] = "AND";
		conditions["Conditions"][1] = filterMap;
		filterMap.clear();
		filterMap["fieldname"] = "ReferenceId";
		filterMap["operator"] = "=";
		filterMap["value"] = styleID;
		filterMap["logicalOperator"] = "AND";
		conditions["Conditions"][2] = filterMap;
		m_downloadAttachmentsMap["dataFilter"] = conditions;
		
		Utility::Logger("ProductResultTable -> CreateDownloadAttachmentsMap() -> End");
	}
	/**
	 * \brief Collects attachements of style from json
	 * \param response 
	 */
	void ProductResultTable::GetStyleAttachments(json response)
	{
		Utility::Logger("ProductResultTable -> GetStyleAttachments() -> Start");
		string column, attachmentURL;
		json completeStylesJson;
		string responseJsonStrStyle = response["entities"].dump();
		completeStylesJson = json::parse(responseJsonStrStyle);
		string responseJsonsize = to_string(completeStylesJson.size());
		if (completeStylesJson.size() > 2)
		{
			throw "Styles with multiple 3D asset attachments are not supported";
		}
		string responseString = "";
		bool attachmentsPresent = false;
		if (completeStylesJson.size() != 0)
		{
			for (int i = 0; i < completeStylesJson.size(); i++)
			{
				string entityJson = completeStylesJson[i].dump();
				json styles = json::parse(entityJson);
				string name = styles["name"].dump();
				name = name.erase(0, 1);
				name = name.erase(name.size() - 1);
				if (name == "StyleAttachments")
				{
					attachmentsPresent = true;
					column = styles["column"].dump();
					json columns = json::parse(column);
					attachmentURL = columns["CFilename"].dump();
					attachmentURL = attachmentURL.erase(0, 1);
					attachmentURL = attachmentURL.erase(attachmentURL.size() - 1);
					m_attachmentsFileName = columns["OFilename"].dump();
					if (m_attachmentsFileName != "Null")
					{
						m_attachmentsFileName = m_attachmentsFileName.erase(0, 1);
						m_attachmentsFileName = m_attachmentsFileName.erase(m_attachmentsFileName.size() - 1);
					}
					m_attachmentsAttaFileListId = columns["AttaFileListId"].dump();
					Utility::DownloadFilesFromURL(attachmentURL, STYLE_ATTACHMENTS_DIRECTORY + m_attachmentsFileName);
				}
				if (attachmentsPresent == false)
				{
					UTILITY_API->DisplayMessageBox("No project is associated with the downloaded Style. Downloading metadata only..");
				}
			}
		}
		Utility::Logger("ProductResultTable -> getStyleAttachments() -> End");
	}
	/**
	 * \brief Recordes Clock of Back button by user and stops sending request further.
	 */
	void ProductResultTable::productResultTableBack_clicked()
	{
		Utility::Logger("ProductResultTable -> ProductResultTableBackClicked() -> Start");
		this->close();
		ProductSearch::GetInstance()->setModal(true);
		ProductSearch::GetInstance()->show();
		Utility::Logger("ProductResultTable -> ProductResultTableBackClicked() -> End");
	}
	/**
	 * \brief Recordes Clock of Cancel button by user and terminates search action.
	 */
	void ProductResultTable::productResultTableCancel_clicked()
	{
		Utility::Logger("ProductResultTable -> ProductResultTableCancelClicked() -> Start");
		this->close();
		Utility::Logger("ProductResultTable -> ProductResultTableCancelClicked() -> End");
	}
	/**
	 * \brief Sets latest bearer token to local variable 
	 * \param bearerToken 
	 */
	void ProductResultTable::SetBearerToken(const string& bearerToken)
	{
		Utility::Logger("ProductResultTable -> SetBearerToken() -> Start");
		m_bearerToken = bearerToken;
		Utility::Logger("ProductResultTable -> SetBearerToken() -> End");
	}
}