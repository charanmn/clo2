#pragma once
#include <QDialog>
#include <string>
#include <iostream>
#include <QMainWindow>
#include <QLineEdit>
#include <QTextEdit>
#include <QDateTimeEdit>
#include <QComboBox>
#include <QLabel>
#include <QTreeWidgetItem>
#include <QTableWidgetItem>
#include <vector>
#include <map>
#include "GeneratedFiles/ui_ProductSearch.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
#include "CLO_PLUGIN/INFOR/Libraries/json.h"
using json = nlohmann::json;

namespace CLOPlugin
{
	class  ProductSearch : public QDialog, public Ui::ProductSearch
	{
		Q_OBJECT
		std::vector<Utility::Fields> m_searchFieldsVector;
		static ProductSearch* _instance;
		static string m_bearerToken;
		json m_productSearchMap;
		bool m_isUserInputEmpty;
		
		std::map<string, string> m_attributeMap;
		map<string, map<string, string>> m_attsDropdownListMap;
		int m_currentBrandIndex;
		int m_currentDivisionIndex;
		int m_currentCategoryIndex;
		int m_signalOrigin;
	public:
		ProductSearch(QWidget* parent = 0);
		static ProductSearch*	GetInstance();
		static void			Destroy();
		~ProductSearch();

		void GetDropDownMap(json& lookUpsJson, string attributeValue, map<string, string>& attributeMap);
		void ReadJsonAndDrawDialog();
		
		void DrawWidget(std::vector<Utility::Fields>& fieldsVector);
		void SetBearerToken(const string& bearerToken);
		void ReadPLMJson();
		void CreateResultTable(json responseJson);
		bool ExtractAllUIValues();
		void CreateProductSearchMap();
		void PLMSearch();
		void GetFilteredProductJson();
		void ClearAllFields();
		string GetDependencies(int brand, int division, int category);
		void SetDependenciesToWidgets(string dependencies);
		void SetPresetValues(json dependencyJson);
	private slots:
		void SearchClicked();
		void Cancle_clicked();
		void backclicked();
		void brandValueChanged(const QString& item);
		void divisionValueChanged(const QString& item);
		void categoryValueChanged(const QString& item);
	signals:
		void CreateProductBackClicked();
	};
}

