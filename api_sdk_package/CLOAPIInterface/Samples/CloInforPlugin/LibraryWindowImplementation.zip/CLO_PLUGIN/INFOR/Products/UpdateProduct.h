#pragma once
#include <QDialog>
#include <string>
#include <iostream>
#include <QMainWindow>
#include <QLineEdit>
#include <QTextEdit>
#include <QDateTimeEdit>
#include <QComboBox>
#include <QLabel>
#include <QTreeWidgetItem>
#include <QTableWidgetItem>
#include <vector>
#include <map>
#include "GeneratedFiles/ui_UpdateProduct.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"

namespace CLOPlugin
{

	class  UpdateProduct : public QDialog, public Ui::UpdateProduct
	{
		Q_OBJECT
		static UpdateProduct* _instance;
		std::vector<Utility::Fields> m_updateFieldsVector;
		Utility::ProductResults m_ProductResults;
		static string m_bearerToken;
		bool m_isSaveClicked;
		QLineEdit* m_lineEdit;
		QLineEdit* m_lineEditBrand;
		std::map<string, string> m_attributeMap;
		map<string, map<string, string>> m_attsDropdownListMap;
		int m_currentBrandIndex;
		int m_currentDivisionIndex;
		int m_currentCategoryIndex;
		int m_signalOrigin;
	public:
		UpdateProduct(QWidget* parent = nullptr);
		static UpdateProduct*	GetInstance();
		static void			Destroy();

		~UpdateProduct();
		
		void ReadPLMJson();
		void ReadJsonAndDrawDialog();
		void GetDropDownMap(json& lookUpsJson, string attributeValue, map<string, string>& attributeMap);
		void DrawWidget(std::vector<Utility::Fields>& fieldsVector);
		void FillUpdateProductData(Utility::ProductResults& data);
		void SetBearerToken(const string& bearerToken);
		void ExtractAllUIValues();
		void UpdateProductMetaData();
		int GetDocumentIdForFile(string& filename);
		void DeleteDocuments(int imageDocLibId, int attachmentDocLibId);
		void UnlinkDocuments(string& imageDocLibId, string& attachmentDocLibId);
		void UploadAndLinkDocuments();
		string CreateImageParam(string response, string key);
		string CreateZipParam(string response, string key);
		void ClearAllFields();
		bool IsSaveClicked();
		void SetAllFields();
		void GetFilteredProductJson();
		void ClearDownloadedProjectData();
		bool MandatoryFieldsValidation();
		string GetDependencies(int brand, int division, int category);
		void SetDependenciesToWidgets(string dependencies);
		void SetPresetValues(json dependencyJson);
	private slots:

		void updateInPlm_clicked();
		void saveAndClose_clicked();
		void back_clicked();
		void closeWindow_clicked();
		void brandValueChanged(const QString& item);
		void divisionValueChanged(const QString& item);
		void categoryValueChanged(const QString& item);
	};
}