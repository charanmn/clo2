#include "ColorSearch.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QLabel>
#include <QMessageBox>
#include <QCheckBox>
#include <any>
#include <optional>
#include "qlistview.h"
#include "CLO_PLUGIN/INFOR/Libraries/json.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
#include "CLO_PLUGIN/INFOR/DesignSuite/DesignSuite.h"
#include "ColorResultTable.h"
#include "classes/APIDefine.h"
#include <iostream>

using namespace std;
/*
*brief having the methods for navigating all the functions for color related. 
*nlohmann used for parsing and mapping json.
*/
using json = nlohmann::json;
namespace CLOPlugin
{
	ColorSearch* ColorSearch::_instance = NULL;
	/*
	*m_bearerToken memeber variable to get and set the bearerToken. 
	*/
	string ColorSearch::m_bearerToken = " ";
	/**
	 * \brief Responsible for setting bearer token to member variable for Rest calls
	 * \param bearerToken
	 */
	void ColorSearch::SetBearerToken(const string& bearerToken)
	{
		m_bearerToken = bearerToken;
	}
	/**
	 * \brief Instantiate ColorSearch object
	 * \return
	 */
	ColorSearch* ColorSearch::GetInstance()
	{
		if (_instance == NULL)
		{
			_instance = new ColorSearch();
		}
		return _instance;
	}
	/**
	 * \brief Destroys instantiated ColorSearch object
	 */
	void ColorSearch::Destroy()
	{
		if (_instance)
		{
			delete _instance;
			_instance = NULL;
		}
	}
	/*
	*brief clear all filled values before display UI.
	*/
	void ColorSearch::ClearAllFields()
	{
		for (int i = 0; i < ColorSearchTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = ColorSearchTree->topLevelItem(i);
			QWidget* qWidgetColumn0 = ColorSearchTree->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = ColorSearchTree->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string lable = qlabel->text().toStdString();
			QLineEdit* qlineedit = qobject_cast<QLineEdit*>(qWidgetColumn1);

			if (qlineedit)
			{
				qlineedit->setText("");
			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
				if (qComboBox)
				{
					int indexOfEmptyString = qComboBox->findText("");
					qComboBox->setCurrentIndex(indexOfEmptyString);
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
					if (qtextEdit)
					{
						qtextEdit->setText("");
					}
				}
			}
		}
	}
	ColorSearch::ColorSearch(QWidget* parent) : QDialog(parent)
	{
		setupUi(this);
		QFont fontStyle("Times new roman", 16, QFont::Bold);
		QTreeWidgetItem* dataItem = new QTreeWidgetItem;
		QSize size(425, 450);
		Qt::ItemFlags flags;
		flags = dataItem->flags();
		flags |= Qt::ItemIsSelectable | Qt::ItemIsEditable | Qt::ItemIsEnabled;
		dataItem->setFlags(flags);
	//	QFont fontStyle("Times new roman", 16, QFont::Bold);
		this->setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint | Qt::CustomizeWindowHint);
		ColorSearchTree->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		ColorSearchTree->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		ColorSearchTree->setStyleSheet("QTreeWidget::item { border-bottom: 1px solid #232323;""padding : 10px;""height: 25px;""}");
		
		ColorSearchTree->setFixedSize(size);
		ColorSearchTree->setColumnWidth(1, 210);
		ColorSearchTree->setColumnWidth(0, 195);
		label_ps->setFont(fontStyle);
		layout()->setSizeConstraint(QLayout::SetFixedSize);
		this->adjustSize();
		m_solid = false;
		back->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_back_over.svg"));
		back->setIconSize(QSize(iconHieght, iconWidth));

		search->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_search_over.svg"));
		search->setIconSize(QSize(iconHieght, iconWidth));

		QObject::connect(search, SIGNAL(clicked()), this, SLOT(Search_clicked()));
		QObject::connect(back, SIGNAL(clicked()), this, SLOT(back_clicked()));
		QObject::connect(closeWindow, SIGNAL(clicked()), this, SLOT(Cancle_clicked())); //now spelling
		m_isUserInputEmpty = true;
		ReadInforJson();
		ReadJsonAndDrawDialog();
		
		ColorSearchTree->setFocusPolicy(Qt::FocusPolicy::StrongFocus);
		ColorSearchTree->setSelectionBehavior(QAbstractItemView::SelectRows);
		ColorSearchTree->setSelectionBehavior(QAbstractItemView::SelectItems);
		ColorSearchTree->setTabKeyNavigation(true);
	}
	/*
	*brief read the filtered json file.
	*fill read values to the m_ColorsFieldsVector.
	*calling the drawWidget(m_ColorsFieldsVector) to fill the widget.
	*/
	void ColorSearch::ReadJsonAndDrawDialog()
	{
		json jsonString;
		Utility::Fields tempField;
		ifstream filename;
		filename.open("C:\\MiddlewareFiles\\colorSearchFiltered.json");
		filename >> jsonString;
		filename.close();
		string completeJsonString, uiTypeJSONObject, presetListJSONObject, fieldValues;
		completeJsonString = jsonString.dump();
		json j1 = json::parse(completeJsonString);
		uiTypeJSONObject = j1["uiTypeList"].dump();
		json componentsJson = json::parse(uiTypeJSONObject);
		presetListJSONObject = j1["presetList"].dump();
		json presetListJSON = json::parse(presetListJSONObject);
		fieldValues = j1["fieldList"].dump();
		json fieldValuesJson = json::parse(fieldValues);

		for (int i = 0; i < fieldValuesJson.size(); i++)
		{
			string fieldValuesString = fieldValuesJson[i].dump();
			fieldValuesString = fieldValuesString.erase(0, 1);
			fieldValuesString = fieldValuesString.erase(fieldValuesString.size() - 1);
			tempField.labelValue = QString::fromStdString(fieldValuesString);
			string uiTypes = componentsJson[fieldValuesString].dump();
			uiTypes = uiTypes.erase(0, 1);
			uiTypes = uiTypes.erase(uiTypes.size() - 1);
			tempField.fieldUItype = QString::fromStdString(uiTypes);
			if (tempField.fieldUItype == "dropdown")
			{
				string presetList = presetListJSON[fieldValuesString].dump();
				presetList = presetList.erase(0, 1);
				presetList = presetList.erase(presetList.size() - 1);
				presetList.erase(std::remove(presetList.begin(), presetList.end(), '\"'), presetList.end());
				QStringList listQt;
				listQt = QString::fromStdString(presetList).split(",");
				tempField.presetValues = listQt;
			}
			m_colorsFieldsVector.push_back(tempField);
		}
		DrawWidget(m_colorsFieldsVector);	
	}
	/*
	*brief input from readJsonAndDrawDialog().
	*create labels and widgetitems(combobox,lineEdit,textarea) from the m_ColorsFieldsVector.
	*calling the drawWidget(m_ColorsFieldsVector) to fill the widget.
	*/
	void ColorSearch::DrawWidget(std::vector<Utility::Fields>& fieldsVector)
	{
		for each (auto field in fieldsVector)
		{
			if (field.fieldUItype == "text")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QLineEdit* lineEdit = new QLineEdit();
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				lineEdit->setStyleSheet(inputStyle);
				ColorSearchTree->addTopLevelItem(topLevel);
				ColorSearchTree->setItemWidget(topLevel, 0, label);
				ColorSearchTree->setItemWidget(topLevel, 1, lineEdit);
				lineEdit->setText(field.userInputValues);

			}

			if (field.fieldUItype == "dropdown")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QComboBox* comboBox = new QComboBox();
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				comboBox->setStyleSheet(inputStyle);
				ColorSearchTree->addTopLevelItem(topLevel);
				ColorSearchTree->setItemWidget(topLevel, 0, label);
				ColorSearchTree->setItemWidget(topLevel, 1, comboBox);
				comboBox->setStyleSheet("combobox-popup: 0; font: 75 8pt \"Times New Roman\";combobox-popup:0 ");
				comboBox->addItems(field.presetValues);
				int indexOfEmptyString = comboBox->findText("");
				comboBox->setCurrentIndex(indexOfEmptyString);
			}

			if (field.fieldUItype == "textarea")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QTextEdit* textEdit = new QTextEdit();
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				ColorSearchTree->addTopLevelItem(topLevel);
				ColorSearchTree->setItemWidget(topLevel, 0, label);
				ColorSearchTree->setItemWidget(topLevel, 1, textEdit);
				textEdit->setText(field.userInputValues);
				textEdit->setStyleSheet("border: 1px solid black;""background-color: #222222;""font: 75 8pt \"Times New Roman\";");
				textEdit->setMaximumSize(190, 80);
			}

			if (field.fieldUItype == "DateEdit")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QDateEdit* dateTimeEdit = new QDateEdit();
				bool enable = true;
				dateTimeEdit->setCalendarPopup(enable);
				QString dataricovero("");
				QDate date = QDate::fromString(dataricovero, "");
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				ColorSearchTree->addTopLevelItem(topLevel);
				ColorSearchTree->setItemWidget(topLevel, 0, label);
				ColorSearchTree->setItemWidget(topLevel, 1, dateTimeEdit);
			}
		}
	}
	ColorSearch::~ColorSearch()
	{

	}
	/*
	*brief validating UI feilds.
	*call from Search_clicked()
	*return boolean.
	*/
	bool ColorSearch::ExtractAllUIValuesAndMapToJson()
	{
		for (int i = 0; i < ColorSearchTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = ColorSearchTree->topLevelItem(i);
			QWidget* qWidgetColumn0 = ColorSearchTree->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = ColorSearchTree->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string lable = qlabel->text().toStdString();
			QLineEdit* qlineedit = qobject_cast<QLineEdit*>(qWidgetColumn1);
			if (qlineedit)
			{
				m_colorsFieldsVector[i].userInputValues = qlineedit->text();
				if (!qlineedit->text().isEmpty())
				{
					m_isUserInputEmpty = false;
				}
			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
				if (qComboBox)
				{
					m_colorsFieldsVector[i].userInputValues = qComboBox->currentText();
					if (!qComboBox->currentText().isEmpty())
					{
						m_isUserInputEmpty = false;
					}
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
					if (qtextEdit)
					{
						m_colorsFieldsVector[i].userInputValues = qtextEdit->toPlainText();
						if (!qtextEdit->toPlainText().isEmpty())
						{
							m_isUserInputEmpty = false;
						}
					}
				}
			}
		}
	
		if (m_isUserInputEmpty)
		{
			UTILITY_API->DisplayMessageBox("Please enter atleast one field to search Colors.");
			return false;
		}	
		return true;
	}
	/*
	*brief when the user cliked search button.
	*call validate UI feild.
	*call createSearchMap() to create parameter 
	*PLMSearch to make a rest call.
	*/
	void ColorSearch::Search_clicked()
	{
		bool isExtracted = ExtractAllUIValuesAndMapToJson();
		if (isExtracted == true)
		{
			this->hide();
			CreateSearchMap();
			PLMSearch();
			m_isUserInputEmpty = true;
		}
	}
	/*
	*brief crete map.json file.
	*called from Search_clicked().
	*it have the parameter to make the rest call, what the user filled UI as a input.
	*/
	void ColorSearch::CreateSearchMap()
	{
		ofstream newfile;
		newfile.open("C:\\MiddlewareFiles\\color.json");			
		json emptyJsonObject;
		json mapArray;
		json pagInfoMap;
		json filterMap;
		json conditions = json::object();
		pagInfoMap["Page"] = 1;
		pagInfoMap["PageSize"] = 40;
		pagInfoMap["pageCount"] = 1;
		pagInfoMap["totalCount"] = 2;
		m_colorSearchMap["roleId"] = 1;
		m_colorSearchMap["userId"] = 71;
		m_colorSearchMap["entity"] = "Colors";
		m_colorSearchMap["Schema"] = "FSH5";
		m_colorSearchMap["fromAi"] = true;
		m_colorSearchMap["pageType"] = "list";
		m_colorSearchMap["sortInfo"] = emptyJsonObject;
		m_colorSearchMap["PageInfo"] = pagInfoMap;
		int count = 0;
		for (auto arrayElement : m_colorsFieldsVector)
		{
			string attLabel = arrayElement.labelValue.toStdString();
			string userSelected = arrayElement.userInputValues.toStdString();
			if (userSelected != "")
			{
				if (arrayElement.fieldUItype == "dropdown")
				{
					for (auto it = m_attributeMap.begin(); it != m_attributeMap.end(); it++)
					{
						if (it->first == attLabel)
						{
							mapArray["fieldName"] = it->second;
							map<string, string> attNameIdMap;
							attNameIdMap.clear();
							attNameIdMap.insert(m_attsDropdownListMap[attLabel].begin(), m_attsDropdownListMap[attLabel].end());
							for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
							{
								if (it->first == userSelected)
								{
									mapArray["operator"] = "=";
									mapArray["value"] = stoi(it->second);
									break;
								}
							}
							break;
						}
					}
					conditions["Conditions"][count++] = mapArray;
				}
				else if (attLabel == "Code")
				{
					filterMap.clear();
					filterMap["fieldName"] = attLabel;
					filterMap["operator"] = "like";
					filterMap["value"] = userSelected;
					conditions["Conditions"][count++] = filterMap;
				}
				else if (attLabel == "Name")
				{
					filterMap.clear();
					filterMap["fieldName"] = attLabel;
					filterMap["operator"] = "like";
					filterMap["value"] = userSelected;
					conditions["Conditions"][count++] = filterMap;
				}
				else
				{
					filterMap.clear();
					filterMap["fieldName"] = attLabel;
					filterMap["operator"] = "=";
					filterMap["value"] = userSelected;
					conditions["Conditions"][count++] = filterMap;
				}
			}
		}
		conditions["Search"] = nullptr;

		m_colorSearchMap["dataFilter"] = conditions;
		newfile << m_colorSearchMap;
		newfile.close();
	}
	/*
	*brief make a rest call to get a response from infor.
	*try catch to remove �.
	*pass the reponse to create result table as json.
	*/
	void ColorSearch::PLMSearch()
	{
		string parameter = to_string(m_colorSearchMap);
		vector<pair<string, string>> headerNameAndValueList;

		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));

		headerNameAndValueList.push_back(make_pair("authorization", m_bearerToken));
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/view/api/view/layout/data/get", &parameter, headerNameAndValueList, "HTTP Post");
		json responseJson;
		string errorResponse = Utility::CheckErrorDescription(response);
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			int indexForContent = response.find("Content-Type:");
			string strForCheck = response.substr(indexForContent);
			int indexForJSON = strForCheck.find("{");
			string strForJSON = strForCheck.substr(indexForJSON);
			std::replace(strForJSON.begin(), strForJSON.end(), '�', ' ');
			try
			{
				responseJson = json::parse(strForJSON);
			}
			catch (json::exception & err)
			{
				
			}

			CreateResultTable(responseJson);

		}
		else
		{
			UTILITY_API->DisplayMessageBox(errorResponse);
		}
	}
	/*
	*brief segregate the response, passing input to result table and execute it.
	*/
	void ColorSearch::CreateResultTable(json& responseJson)
	{
		this->hide();		
		ColorResultTable colorResultTable;
		string entities = responseJson["entities"].dump();
		json completeEntitiesJson = json::parse(entities);
		colorResultTable.SetBearerToken(m_bearerToken); 
		if (completeEntitiesJson.size() != 0)
		{
			int count = 0;
			bool solid;
			Utility::ColorResults tempColorResults;
			for (int i = 0; i < completeEntitiesJson.size(); i++)
			{

				string entityJson = completeEntitiesJson[i].dump();
				json material = json::parse(entityJson);

				string name = material["name"].dump();
				name = name.erase(0, 1);
				name = name.erase(name.size() - 1);
				string qimage, column, strcolorSubType, TypeName, strTypeName, strStatus, strShade, strcolorId, strcolorFamily, strColorName, strColorCode, thumbnail, colorSubType, strType, strRGB, strCMYK, strPantoneCode;
				if (name == "Colors")
				{
					count = count + 1;
					column = material["column"].dump();
					json columns = json::parse(column);
					
					strColorName = columns["Name"].dump();
					strColorName = strColorName.erase(0, 1);
					strColorName = strColorName.erase(strColorName.size() - 1);

					strColorCode = columns["Code"].dump();
					strColorCode = strColorCode.erase(0, 1);
					strColorCode = strColorCode.erase(strColorCode.size() - 1);

					colorSubType = columns["SubType"].dump();
					if (colorSubType != "null")
					{
						strcolorSubType = columns["SubType_Lookup"]["Name"].dump();
						strcolorSubType = strcolorSubType.erase(0, 1);
						strcolorSubType = strcolorSubType.erase(strcolorSubType.size() - 1);
					}			

					string shade = columns["Shade"].dump();
					if (shade != "null")
					{
						strShade = columns["Shade_Lookup"]["Name"].dump();
						strShade = strShade.erase(0, 1);
						strShade = strShade.erase(strShade.size() - 1);
					}

					strRGB = columns["RGB"].dump();
					strRGB = strRGB.erase(0, 1);
					strRGB = strRGB.erase(strRGB.size() - 1);
					
					strCMYK = columns["CMYK"].dump();
					strCMYK = strCMYK.erase(0, 1);
					strCMYK = strCMYK.erase(strCMYK.size() - 1);
				
					strType = columns["Type"].dump();
					{
						TypeName = columns["Color_Type_Lookup"]["Name"].dump();
						TypeName = TypeName.erase(0, 1);
						TypeName = TypeName.erase(TypeName.size() - 1);
					}
					
					if (strType == "1")
					{
						strTypeName = "Single";
						m_solid = true;
					}
					else if(strType == "2")
						strTypeName = "Combination";
					else if (strType == "3")
						strTypeName = "Print";
					
					strPantoneCode = columns["PantoneCode"].dump();
					if (strPantoneCode != "null")
					{
						strPantoneCode = strPantoneCode.erase(0, 1);
						strPantoneCode = strPantoneCode.erase(strPantoneCode.size() - 1);
					}
					else
						strPantoneCode = " ";
					
					string family = columns["ColorwayFamilyId"].dump();
					if (family != "null")
					{
						strcolorFamily = columns["ColorwayFamilyId_Lookup"]["Name"].dump();
						strcolorFamily = strcolorFamily.erase(0, 1);
						strcolorFamily = strcolorFamily.erase(strcolorFamily.size() - 1);
					}
					
					string statusValue = columns["Status"].dump();
					if (statusValue != "null")
					{
						strStatus = columns["Status_Lookup"]["Name"].dump();
						strStatus = strStatus.erase(0, 1);
						strStatus = strStatus.erase(strStatus.size() - 1);
					}	
					 
					QPixmap pixmap;
					thumbnail = columns["ImageThumb"].dump();					
					if (thumbnail != "null")
					{
						QImage img;
						QImage styleIcon;
						thumbnail = thumbnail.erase(0, 1);
						thumbnail = thumbnail.erase(thumbnail.size() - 1);
						string filenameToSave = strColorCode + ".png";						
						styleIcon.load("C:\\MiddlewareFiles\\color.png");
						pixmap = QPixmap::fromImage(styleIcon);
						
					}
					tempColorResults.colorCode = QString::fromStdString(strColorCode);
					tempColorResults.colorCMYK   = QString::fromStdString(strCMYK);
					tempColorResults.colorFamily = QString::fromStdString(strcolorFamily);
					tempColorResults.colorId = QString::fromStdString(strcolorId);
					tempColorResults.colorName= QString::fromStdString(strColorName);
					tempColorResults.colorPantoneCode = QString::fromStdString(strPantoneCode);
					tempColorResults.colorRGB = QString::fromStdString(strRGB);
					tempColorResults.colorShade = QString::fromStdString(strShade);
					tempColorResults.colorStatus = QString::fromStdString(strStatus); 
					tempColorResults.colorSubType = QString::fromStdString(strcolorSubType);
					tempColorResults.colorType = QString::fromStdString(strTypeName);
					if (strTypeName == "Single")
					{
						solid = m_solid;
						colorResultTable.AddRowData(tempColorResults, pixmap);
						m_solid = false;
					}
				}

			}
			if (solid)
			{
				colorResultTable.setModal(true);
				colorResultTable.exec();
			}
			else
			{
				UTILITY_API->DisplayMessageBox("This color is not a solid color");
				this->show();
			}
		}
		else
		{
			UTILITY_API->DisplayMessageBox("No Result Found");
			this->show();
		}
	}
	/*
	*brief clik of back buuton go back to the DesignSuite UI.
	*/
	void ColorSearch::back_clicked()
	{
		this->hide();
		DesignSuite::GetInstance()->setModal(true);
		DesignSuite::GetInstance()->show();
	}
	/*
	*brief clik of Cancle buuton close the current UI.
	*/
	void ColorSearch::Cancle_clicked()
	{
		this->close();
	}
	/*
	*brief read the colorDetails.json file crete the colorSearchFiltered.json.
	*colorSearchFiltered.json file is input for the ColorSearch UI.
	*/
	void  ColorSearch::ReadInforJson() {
		json completeStyleJson;
		m_attsDropdownListMap.clear();
		m_attributeMap.clear();
		ifstream filename(MIDDLEWARE_DIRECTORY + "ColorDetails.json");
		filename >> completeStyleJson;
		filename.close();
		ofstream newfile(MIDDLEWARE_DIRECTORY + "colorSearchFiltered.json");
		json finalJsontoSave;
		auto jsonFieldList = json::array();
		auto jsonUiTypeList = json::object();
		auto presetArray = json::array();
		auto presetList = json::object();
		auto jsonDataFieldList = json::object();
		auto jsonMandatoryFieldsList = json::array();
		int uiPresetCount = 0;
		string completeStyleJsonString, componentsString, compObjString;
		completeStyleJsonString = completeStyleJson.dump();
		json jsonObject = json::parse(completeStyleJsonString);
		componentsString = jsonObject["layout"]["components"].dump();
		json componentsJson = json::parse(componentsString);
		for (int i = 0; i < componentsJson.size(); i++) {
			compObjString = componentsJson[i].dump();
			json compObjJson = json::parse(compObjString);
			string propsString = compObjJson["props"].dump();
			json  propsJson = json::parse(propsString);
			string visible = propsJson["isVisibleAi"].dump();
			if (visible == "true")
			{
				
				string fieldType = compObjJson["fieldType"].dump();
				fieldType = fieldType.erase(0, 1);
				fieldType = fieldType.erase(fieldType.size() - 1);
				
				string lookupRef = compObjJson["lookupRef"].dump();
				lookupRef = lookupRef.erase(0, 1);
				lookupRef = lookupRef.erase(lookupRef.size() - 1);

				string dataField = compObjJson["dataField"].dump();
				dataField = dataField.erase(0, 1);
				dataField = dataField.erase(dataField.size() - 1);
				
				string requi = propsJson["isRequired"].dump();
				if (lookupRef == "ul")
				{
					m_attributeMap.insert(std::make_pair(dataField, dataField));
					jsonUiTypeList[dataField] = fieldType;
					jsonDataFieldList[dataField] = dataField;
					jsonFieldList.push_back(dataField);
					if (requi == "true")
					{
						jsonMandatoryFieldsList.push_back(dataField);
					}
				}
				else
				{
					m_attributeMap.insert(std::make_pair(lookupRef, dataField));
					jsonUiTypeList[lookupRef] = fieldType;
					jsonDataFieldList[lookupRef] = dataField;
					jsonFieldList.push_back(lookupRef);
					if (requi == "true")
					{
						jsonMandatoryFieldsList.push_back(lookupRef);
					}
				}
				if (fieldType == "dropdown")
				{
					string lookups = jsonObject["lookups"].dump();
					json lookupsJSON = json::parse(lookups);
					map<string, string> tempAttribMap;
					GetDropDownMap(lookupsJSON, lookupRef, tempAttribMap);
					presetArray.clear();
					presetArray.push_back("");
					for (auto it = tempAttribMap.begin(); it != tempAttribMap.end(); it++)
					{
						presetArray.push_back(it->first);
					}
					presetList[lookupRef] = presetArray;
					m_attsDropdownListMap.insert(std::make_pair(lookupRef, tempAttribMap));
				}

			}
		}
	
		auto newjsonFieldList = json::array();
		newjsonFieldList.push_back("Code");
		newjsonFieldList.push_back("Name");
		newjsonFieldList.push_back("ColorFamily");
		newjsonFieldList.push_back("Shade");
		newjsonFieldList.push_back("Status");
		newjsonFieldList.push_back("PantoneCode");
		newjsonFieldList.push_back("NRFCode");
		newjsonFieldList.push_back("AltName");					
		finalJsontoSave["fieldList"] = newjsonFieldList;
		finalJsontoSave["uiTypeList"] = jsonUiTypeList;
		finalJsontoSave["presetList"] = presetList;
		finalJsontoSave["mandatory_fieldList"] = jsonMandatoryFieldsList;
		finalJsontoSave["dataFieldList"] = jsonDataFieldList;
		newfile << finalJsontoSave;
		newfile.close();
	}
	/*
	*brief input from readInforJson() to get the drop down list.
	*/	
	void ColorSearch::GetDropDownMap(json& lookUpsJson, string attributeValue, map<string, string>& attribMap)
	{
		map<string, string> tempMap;
		for (int i = 0; i < lookUpsJson.size(); i++) {
			string lookupNameAndId = lookUpsJson[i].dump();
			json lookupNameAndIdJSON = json::parse(lookupNameAndId);
			string colName = lookupNameAndIdJSON["name"].dump();
			colName = colName.erase(0, 1);
			colName = colName.erase(colName.size() - 1);

			if (attributeValue.compare(colName) == 0)
			{
				string id, name;
				string columnStg = lookupNameAndIdJSON["column"].dump();
				json colNameAndIDJSON = json::parse(columnStg);
				id = colNameAndIDJSON["Id"].dump();

				name = colNameAndIDJSON["Name"].dump();
				name = name.erase(0, 1);
				name = name.erase(name.size() - 1);
				tempMap.insert(std::make_pair(name, id));
			}
		}
		attribMap = tempMap;
	}
}