#include "ColorResultTable.h"
#include "CLO_PLUGIN/INFOR/DesignSuite/DesignSuite.h"
#include <qmessagebox.h>
#include <qcheckbox.h>
#include <direct.h>
#include "classes/APICLODataBase.h"
#include "classes/APIStorage.h"
#include <CLOAPIInterface.h>
#include "ColorSearch.h"
#include <iostream>
#include "classes/APIStorage.h"
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
vector<pair<string, Marvelous::CloApiRgb>>	m_RGBcolorList;
/*
*brief having the methods for navigating all the functions for colorResult related.
*/
using namespace std;

namespace CLOPlugin
{
	/*
	*m_bearerToken memeber variable to get and set the bearerToken. 
	*/
	string ColorResultTable::m_bearerToken = " ";
	ColorResultTable* ColorResultTable::_instance = NULL;

	ColorResultTable* ColorResultTable::GetInstance()
	{
		if (_instance == NULL)
		{
			_instance = new ColorResultTable();
		}
		return _instance;
	}
	void ColorResultTable::Destroy()
	{
		if (_instance)
		{
			m_RGBcolorList.clear();
			delete _instance;
			_instance = NULL;
		}
	}
	ColorResultTable::ColorResultTable(QWidget* parent, Qt::WindowFlags flags) : QDialog(parent, flags)
	{
		setupUi(this);
		m_strSwatchName = "PLM Solid Colors";
		QFont font;
		font.setPointSize(15);
		font.setBold(true);
		font.setFamily("Times New Roman");
		ColorTable->setColumnCount(12);
		ColorTable->resizeColumnToContents(11);
		ColorTable->resizeColumnsToContents();
		ColorTable->resizeRowsToContents();
		ColorTable->horizontalHeader()->setResizeMode(QHeaderView::Stretch);
		ColorTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
		ColorTable->horizontalHeader()->setFont(font);
		ColorTable->setWordWrap(true);
		ColorTable->horizontalHeader()->setStretchLastSection(true);
		m_headerItem = new QTableWidgetItem;
		ColorTable->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
		ColorTable->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		ColorTable->horizontalHeader()->setFixedHeight(80);
		ColorTable->horizontalHeader()->setDefaultSectionSize(80);
		ColorTable->resizeColumnsToContents();
		ColorTable->verticalHeader()->setDefaultSectionSize(80);
		ColorTable->verticalHeader()->blockSignals(true);
		QStringList headerlist;
		headerlist << "Select" << "Code" << "Name" << "Image" << "Type" << "Shade" <<"Sub Type" << "Color\nFamily"   << "Status" << "RGB" << "Pantone\nCode" << "CMYK";
		QTableWidgetItem* itemCheckbox = new QTableWidgetItem(" ");
		itemCheckbox->setCheckState(Qt::Unchecked);
		QModelIndexList selection = ColorTable->selectionModel()->selectedRows();
		ColorTable->setItem(0, 0, itemCheckbox);
		ColorTable->setHorizontalHeaderLabels(headerlist); 

		back->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_back_over.svg"));
		back->setIconSize(QSize(iconHieght, iconWidth));

		download->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_down_over.svg"));
		download->setIconSize(QSize(iconHieght, iconWidth));

		QObject::connect(download, SIGNAL(clicked()), this, SLOT(colorResultTableDownload_clicked()));
		QObject::connect(cancel, SIGNAL(clicked()), this, SLOT(colorResultTableCancel_clicked()));
		QObject::connect(back, SIGNAL(clicked()), this, SLOT(colorResultTableBack_clicked()));
	}

	ColorResultTable::~ColorResultTable()
	{

	}
	/*
	*brief click of back button go back to ColorSearch UI.
	*/
	void ColorResultTable::colorResultTableBack_clicked()
	{
		this->hide();
		ColorSearch::GetInstance()->setModal(true);
		ColorSearch::GetInstance()->show();
	}
	/*
	*brief click of cancel button close ColorResultTable UI.
	*/
	void ColorResultTable::colorResultTableCancel_clicked()
	{
		this->close();
	}
	/*
	*brief adding rows to ColorResultTable UI.
	*input from ColorSearch.cpp file.
	*/
	void ColorResultTable::AddRowData(Utility::ColorResults& colorResults, QIcon fabIcon)
	{
		QTableWidgetItem* headerItem = new QTableWidgetItem();

		AddColoums(headerItem, colorResults, fabIcon);

		m_colorResults.push_back(colorResults);
	}
	/*
	*brief sets rowCount in color result table
	*input count of rows
	*/
	void ColorResultTable::SetRowCount(int count)
	{
		ColorTable->setRowCount(count);
	}
	/*
	*brief adding colomns to ColorResultTable UI.
	*input from addColoums().
	*/
	void ColorResultTable::AddColoums(QTableWidgetItem* parent, Utility::ColorResults& colorResults, QIcon fabIcon)
	{
			QString styleSheet = "::section {"

			"color: white;"
			"border: 1px grey;"
			"text-align: right;"
			"font-family: arial;"
			"font-size: 14px; }";

		ColorTable->horizontalHeader()->setStyleSheet(styleSheet);
		ColorTable->verticalHeader()->setStyleSheet(styleSheet);
		ColorTable->setWordWrap(true);
		ColorTable->resizeRowsToContents();
		ColorTable->resizeColumnsToContents();
		ColorTable->resizeColumnToContents(12);
		ColorTable->resizeRowToContents(12);		
		int currentRow = ColorTable->rowCount();
		ColorTable->setRowCount(currentRow + 1);
		for (int c = 0; c < ColorTable->columnCount(); ++c)
		{
			QTableWidgetItem* dataItem = new QTableWidgetItem;
			dataItem->setTextAlignment(Qt::AlignCenter);			
			Qt::ItemFlags flags;
			flags = dataItem->flags();
			flags |= Qt::ItemIsSelectable | Qt::ItemIsEditable;
			dataItem->setFlags(flags);
			ColorTable->setStyleSheet("QTableWidget::indicator:unchecked {background-color:white;}");
			ColorTable->resizeRowsToContents();
			ColorTable->resizeColumnsToContents();
						
			dataItem->setFlags(dataItem->flags() | Qt::ItemIsUserCheckable);
			dataItem->setCheckState(Qt::Unchecked);

			QTableWidgetItem* itemRGB = new QTableWidgetItem(colorResults.colorRGB);
			itemRGB->setTextAlignment(Qt::AlignCenter); //subtype type CMYK Pantone

			QTableWidgetItem* itemCode = new QTableWidgetItem(colorResults.colorCode);
			itemCode->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemSubType = new QTableWidgetItem(colorResults.colorSubType);
			itemSubType->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemName = new QTableWidgetItem(colorResults.colorName);
			itemName->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemId = new QTableWidgetItem(colorResults.colorId);
			itemId->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemCMYK= new QTableWidgetItem(colorResults.colorCMYK);
			itemCMYK->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemFamily = new QTableWidgetItem(colorResults.colorFamily);
			itemFamily->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemShade = new QTableWidgetItem(colorResults.colorShade);
			itemShade->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemStatus = new QTableWidgetItem(colorResults.colorStatus);
			itemStatus->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemPantone = new QTableWidgetItem(colorResults.colorPantoneCode);
			itemPantone->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemType = new QTableWidgetItem(colorResults.colorType);
			itemType->setTextAlignment(Qt::AlignCenter);
			ColorTable->resizeColumnToContents(11);
			ColorTable->resizeRowToContents(11);
			
			QTableWidgetItem* iconItem = new QTableWidgetItem;
			QPixmap pixmap("C:\\MiddlewareFiles\\color.png");;
			
			ColorTable->setIconSize(QSize(80,80));
			iconItem->setSizeHint(QSize(80, 80));
			ColorTable->setWordWrap(true);						
			
			QImage image = pixmap.toImage();			
			QColor color;
			
			QRgb baseColor;
			QStringList listRGB;
			listRGB = colorResults.colorRGB.split(',');
			
			int red =  listRGB.at(0).toInt();
			int green =  listRGB.at(1).toInt();
			int blue =  listRGB.at(2).toInt();

			color.setRgb(red, green, blue);
			QPixmap newImage = pixmap;
			QPainter painter(&newImage);
			painter.setCompositionMode(QPainter::CompositionMode_SourceIn);
			painter.fillRect(newImage.rect(), color);
			painter.end();
			
			iconItem->setIcon(newImage);
			QCheckBox* selectItem = new QCheckBox;
			selectItem->setCheckState(Qt::Unchecked);
			selectItem->setStyleSheet("margin-left:35%; margin-right:65%;");
			ColorTable->setStyleSheet("QTableWidget::indicator:unchecked {background-color:white;}");

			ColorTable->setCellWidget(currentRow, 0, selectItem);
			ColorTable->setItem(currentRow, 1, itemCode);
			ColorTable->setItem(currentRow, 2, itemName);
			ColorTable->setItem(currentRow, 4, itemType);
			ColorTable->setItem(currentRow, 5, itemShade);
			ColorTable->setItem(currentRow, 6, itemSubType);
			ColorTable->setItem(currentRow, 7, itemFamily);
			ColorTable->setItem(currentRow, 8, itemStatus);
			ColorTable->setItem(currentRow, 9, itemRGB);
			ColorTable->setItem(currentRow, 10, itemPantone);
			ColorTable->setItem(currentRow, 11, itemCMYK);
			ColorTable->setItem(currentRow, 3, iconItem);
			QObject::connect(selectItem, SIGNAL(clicked()), this, SLOT(callCheckBoxSelected())); //to select multiple rows
		}
	}
	/*
	*brief used to highilght the row. if checkbox is selected.
	*/	
	void  ColorResultTable::callCheckBoxSelected()
	{
		int totalRowCount = ColorTable->rowCount();
		ColorTable->setSelectionMode(QAbstractItemView::MultiSelection);
		QStringList selectedRows;
		selectedRows.clear();
		for (int rowCount = 0; rowCount < totalRowCount; rowCount++)
		{
			QWidget* qWidget = ColorTable->cellWidget(rowCount, 0);
			QCheckBox* temp = qobject_cast<QCheckBox*>(qWidget);
			if (temp->checkState() == Qt::Checked)
			{			
				selectedRows << QString::fromStdString(to_string(rowCount));
			}
		}
		ColorTable->clearSelection();
		for (auto iterate : selectedRows)
		{
			ColorTable->selectRow(iterate.toInt());
		}
		selectedRows.clear();
	}
	/*
	*brief click of download button selected rows getting dounload to clo files.
	*/
	void  ColorResultTable::colorResultTableDownload_clicked()
	{
		int rowCount = ColorTable->rowCount();
		int columnCount = ColorTable->columnCount();
		QString colorName;
		QString colorCode, colorType, colorRGB;
		QString type;
		string cColorName, name;
		QString imageLoadPath;
		QString imageSavePath;
		QString imageFileName;
		const char* newDirPath = COLORS_ASSETS_DIRECTORY.c_str();
		mkdir(newDirPath);
		bool isSelected = false;
		bool isSolid = false;
		for (int row = 0; row < rowCount; row++)
		{
			QWidget* qWidget = ColorTable->cellWidget(row, 0); //to select multiple rows
			QCheckBox* tempCheckBox = qobject_cast<QCheckBox*>(qWidget);
			if (tempCheckBox->checkState() == Qt::Checked)
			{
				isSelected = true;
			}
		}
		if (isSelected == false)
		{
			UTILITY_API->DisplayMessageBox("Select atleast one row to download");
		}
		else
		{
			this->hide();
			QImage imageNew;
			QString imageLoadPath, imageSavePath, code;
			for (int row = 0; row < rowCount; row++)
			{
				QWidget* qWidget = ColorTable->cellWidget(row, 0); //to select multiple rows
				QCheckBox* tempCheckBox = qobject_cast<QCheckBox*>(qWidget);
				if (tempCheckBox->checkState() == Qt::Checked)
				{
					QImage imageNew;
					colorName = ColorTable->item(row, 2)->text();
					colorCode = ColorTable->item(row, 1)->text();
					colorType = ColorTable->item(row, 4)->text();
					colorRGB = ColorTable->item(row, 9)->text();

					int matchingindex = 0;
					for (int i = 0; i < m_colorResults.size(); i++)
					{
						if (colorCode == m_colorResults[i].colorCode)
						{
							matchingindex = i;
							break;
						}
					}
					
					QString imageLoadPath, imageSavePath, code;
					if (colorType == "Single")
					{
						QStringList listRGB;
						listRGB = colorRGB.split(',');
						int rValue = m_rgbValues.R = listRGB.at(0).toInt();
						int gValue = m_rgbValues.G = listRGB.at(1).toInt();
						int bValue = m_rgbValues.B = listRGB.at(2).toInt();
						cColorName = colorCode.toUtf8();
						int i;
						if (m_RGBcolorList.size() == 0)
							m_RGBcolorList.push_back(make_pair(cColorName, m_rgbValues));
						else
							for (i = 0; i < m_RGBcolorList.size(); i++)
								if ((m_RGBcolorList[i].first == cColorName))
								{
									m_RGBcolorList[i] = pair<string, Marvelous::CloApiRgb>(cColorName, m_rgbValues);
									break;
								}
						if (i == m_RGBcolorList.size())
							m_RGBcolorList.push_back(make_pair(cColorName, m_rgbValues));
						isSolid = true;
						m_strRetSwatchColor = UTILITY_API->AddColorSwatch(m_RGBcolorList, m_strSwatchName);						
						m_colorSwatchfilename = m_strRetSwatchColor;
								
					}
					else
					{
						CLOAPISample::LibraryAPIItem* setItem = new CLOAPISample::LibraryAPIItem();
						setItem->itemID = colorCode;
						setItem->itemName = colorCode + ".png";
						imageLoadPath = QString::fromStdString(COLORS_TEMP_DIRECTORY) + colorCode + ".png";
						imageSavePath = QString::fromStdString(COLORS_ASSETS_DIRECTORY) + colorCode + ".png";
						imageNew.load(imageLoadPath);
						imageNew.save(imageSavePath);
						setItem->sampleItemData.itemPath = colorCode + ".png";
						setItem->sampleItemData.iconThumbnailPath = colorCode + ".png";
						setItem->sampleItemData.previewThumbnailPath = colorCode + ".png";
						setItem->dateTime = "2019-08-20T16:21:41";
						setItem->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("Non Solid Color");
						setItem->metaData[META_DATA_KEY_16_COLOR_CODE] = m_colorResults[matchingindex].colorId;
						setItem->metaData[META_DATA_KEY_14_COLOR_NAME] = m_colorResults[matchingindex].colorName;
						setItem->metaData[META_DATA_KEY_17_COLOR_SUBTYPE] = m_colorResults[matchingindex].colorSubType;
						bool alreadyExists = false;
						if (API_STORAGE)
						{
							for (int i = 0; i < API_STORAGE->m_LibraryAPIItemList.size(); i++)
							{
								if (API_STORAGE->m_LibraryAPIItemList[i]->metaData[META_DATA_KEY_16_COLOR_CODE] == colorCode)
								{
									API_STORAGE->m_LibraryAPIItemList[i] = setItem; //overwrite the same file
									alreadyExists = true;
									break;
								}

							}
							if (!alreadyExists)
							{
								API_STORAGE->m_LibraryAPIItemList.push_back(setItem);
							}
						}
					}
				}
			}
			wstring wideString = wstring(COLORS_TEMP_DIRECTORY.begin(), COLORS_TEMP_DIRECTORY.end());
			
			CLOAPISample::APIStorage::getInstance()->SendFileName(m_colorSwatchfilename);
			UTILITY_API->DisplayMessageBox("Download completed");
			this->close();
		}
	}
	/*
	*brief set bearerToken vaule.
	*recived from DesignSuite class.
	*/	
	void ColorResultTable::SetBearerToken(const string& bearerToken)
	{
		m_bearerToken = bearerToken;
	}
}