
#pragma once

#include <string>
#include <iostream>
#include <fstream>
#include <QDialog>
#include <QtCore>
#include <QtGui>
#include <QTreeWidgetItem>
#include "Ui_ColorResultTable.h"
#include "CLO_PLUGIN/INFOR/Libraries/json.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"

using namespace std;
using nlohmann::json;
/*
*Brief having all the methods declaration to use in ColorResultTable.cpp file.
*using private slots to connecting the signals.
*nlohmann used for parsing and mapping json.
*/
namespace CLOPlugin
{

	class ColorResultTable : public QDialog, public Ui::ColorResultTable
	{
		Q_OBJECT
			
		static string m_bearerToken;
		static ColorResultTable* _instance;
		QTableWidgetItem* m_headerItem;
		std::vector<Utility::ColorResults> m_colorResults;
		
		

	public:
		string	m_strSwatchName;
		Marvelous::CloApiRgb m_rgbValues;
		CLOAPI::UtilityAPIInterface m_objUtilityAPI;
		int m_count;
		string	m_strRetSwatchColor;
		string  m_colorSwatchfilename;
		
		ColorResultTable(QWidget* parent = 0, Qt::WindowFlags flags = Qt::Dialog | Qt::FramelessWindowHint);
		~ColorResultTable();		
		static ColorResultTable* GetInstance();
		static void	Destroy();			
		void AddRowData(Utility::ColorResults& colorResults, QIcon fabIcon);
		void AddColoums(QTableWidgetItem* parent, Utility::ColorResults& colorResults, QIcon fabIcon);		
		void SetBearerToken(const string& bearerToken);
		void SetRowCount(int count);
		
	private slots:
		void colorResultTableBack_clicked();

		void colorResultTableCancel_clicked();

		void colorResultTableDownload_clicked();
		void callCheckBoxSelected();
	};
}
