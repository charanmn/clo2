#pragma once


#include "Configuration.h"

Configuration* Configuration::_instance = NULL;