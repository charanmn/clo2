#pragma once
#include "ComboBoxItem.h"
#include "CLOAPIInterface/CLOAPIInterface.h"

ComboBoxItem::ComboBoxItem(QTreeWidgetItem* item, int column)
{
    this->item = item;
    this->column = column;
}
/*
* Private Slot, which gets called in Connect statments
*/
void ComboBoxItem::changeText(const QString& text)
{
    //UTILITY_API->DisplayMessageBox("Combobox changeText ::" + text.toStdString());
}

