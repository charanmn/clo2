#pragma once
#ifndef CONFIGURATION_H
#define CONFIGURATION_H

#include <string>
using namespace std;
#include "CLOAPIInterface.h"
#include "UtilityAPIInterface.h"
class Configuration
{
	static Configuration* _instance; // zero initialized by default
	string m_URL;
public:

	inline static Configuration* getInstance()
	{
		if (_instance == NULL)
		{
			_instance = new Configuration();
		}
		return _instance;
	}
	inline static void	destroy()
	{
		if (_instance)
		{
			delete _instance;
			_instance = NULL;
		}
	}
	string getter()
	{
		return m_URL;
	}
	void setter(string str)
	{
		m_URL = str;
		//UTILITY_API->DisplayMessageBox("vlaue setted" + m_URL);
	}
};



#endif // CONFIGURATION_H