#pragma once
#include <algorithm> 
#include <fstream>
#include <iostream> 
#include <QString>
#include <QStringList>
#include <QTextStream>
#include <QVariant>
#include <sstream>
#include <tchar.h>
#include <time.h>
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
#include "CLO_PLUGIN/INFOR/Libraries/jsonQt.h"
#include "CLOAPIInterface.h"
#include "qfileinfo.h"
#pragma comment(lib, "libcurl.lib")
#pragma comment(lib, "wldap32.lib")
#pragma comment(lib, "ws2_32.lib")
#include <direct.h>
#include <iostream>
#include "CLO_PLUGIN/INFOR/Libraries/curl/include/curl/curl.h"
#include "CLO_PLUGIN/INFOR/Libraries/json.h"

using namespace std;
using QtJson::JsonObject;
using json = nlohmann::json;

/**
 * \holds all common variable names used on entire CLO plugin 
 */
namespace Utility
{
	/**
	 * \These are some of the common fields will read from attribute details JSON 
	 */
	struct Fields
	{
		QString labelValue;
		QString fieldUItype;
		QStringList presetValues;
		bool isMandatory;
		QString userInputValues;
		bool isDisabledField;
		QString dataFieldValue;
	};
	/**
	 * \These are variable which will hold values of attributes specific to Products 
	 */
	struct ProductResults
	{
		QString styleId;
		QString styleCode;
		QString	styleName;
		QString brandName;
		QString brandValue;
		QString imageFileName;
		QString imageAttaFileListId;
		QString attachmentFileName;
		QString attachmentAttaFileListId;
		QString statusId;
		QString divisionId;
		QString genderId;
		QString categoryId;
		QString subCategoryId;
		QString subSubCategoryId;
		QString collectionId;
		QString seasonId;
		QString description;
		QString userId;

	};
	/**
	 * \These are variable which will hold values of attributes specific to Fabric Materials  
	 */
	struct MaterialFabricResults
	{
		QString fabricCode;
		QString fabricName;
		QString	fabricId;
		QString fabricType;
		QString fabricBrand;
		QString fabricDivision;
		QString fabricStatus;
		QString fabricSeason;
		QString fabricUser;
		QString fabricCategory;
		QString fabricMainCategory;
		QString fabricCategoryGroup;
		bool fabricAtachment;
		bool fabricImage;

	};
	/**
	 * \These are variable which will hold values of attributes specific to Trim Materials  
	 */
	struct TrimResults
	{
		QString trimCode;
		QString trimName;
		QString	trimId;
		QString trimType;
		QString trimBrand;
		QString trimDivision;
		QString trimStatus;
		QString trimSeason;
		QString trimUser;
		QString trimCategory;
		QString trimMainCategory;
		QString trimDescription;
		bool trimAtachment;
		bool trimImage;

	};
	/**
	 * \These are variable which will hold values of attributes specific to Colors  
	 */
	struct ColorResults
	{
		QString colorCode;
		QString colorName;
		QString	colorId;
		QString colorSubType;
		QString colorType;
		QString colorShade;
		QString colorFamily;
		QString colorStatus;
		QString colorRGB;
		QString colorCMYK;
		QString colorPantoneCode;
	};
	/**
	 * \brief Method removes spaces from input string and returns back.
	 * \param inputString 
	 * \return string 
	 */
	inline string RemoveSpaces(string  inputString)
	{
		inputString.erase(remove(inputString.begin(), inputString.end(), ' '), inputString.end());
		return inputString;
	}
	/**
	 * \brief Displays Message on screen, when isEnabled is true
	 * \param inputString 
	 */
	inline void CustomMessageBox(string inputString)
	{
		//Move as global variable
		bool isEnabled = false;	//true false

		if (isEnabled)
		{
			//UTILITY_API->DisplayMessageBox(inputString);
		}
	}
	/**
	 * \brief Returns current Date & Time in string format
	 * \param inputString 
	 * \return string
	 */
	inline string GetCurrentDateTime(string inputString)
	{
		time_t now = time(0);
		struct tm  time_struct;
		char  buffer[80];
		time_struct = *localtime(&now);
		if (inputString == NOW_TEXT)
			strftime(buffer, sizeof(buffer), "%Y-%m-%d %X", &time_struct); //@To-Do Declare Date Format in Definitions and use here
		else if (inputString == DATE_TEXT)
			strftime(buffer, sizeof(buffer), "%Y-%m-%d", &time_struct); //@To-Do Declare Date Format in Definitions and use here
		return string(buffer);
	}
	/**
	 * \brief Method writes log messages to logger file
	 * \param loggerMessage 
	 */
	inline void Logger(string loggerMessage) 
	{
		string logPath = (MIDDLEWARE_DIRECTORY + GetCurrentDateTime(DATE_TEXT) + TEXT_FILE_EXTENSION);
		std::ofstream logfileopen(logPath.c_str(), std::ios_base::out | std::ios_base::app);
		string now = GetCurrentDateTime(NOW_TEXT);
		logfileopen << loggerMessage << TAB_SPACE_CHAR << now << NEW_LINE_CHAR;
		logfileopen.close();
	}
	
	static string basicAuthorizationString;

	/**
	 * \brief Checks the input char is base64 char or not
	 * \param base64Char 
	 * \return bool
	 */
	inline bool IsBase64Char(unsigned char base64Char) 
	{
		return (isalnum(base64Char) || (base64Char == '+') || (base64Char == '/'));
	}
	/**
	 * \brief Reads content of file and returns string of content, given file name as parameter
	 * \param filename 
	 * \return QString
	 */
	inline QString ReadFile(const QString &fileName) 
	{
		QFile file(fileName);
		if (!file.open(QFile::ReadWrite | QFile::Text))
		{
			return QString();
		}
		else 
		{
			QTextStream in(&file);
			return in.readAll();
		}
	}
	/**
	 * \brief Converts input string to Base64 String
	 * \param inputString 
	 * \return string
	 */
	inline string ConvertToBase64(const std::string & inputString) 
	{
		std::string base64String;
		int upperLimit = 0, lowerLimit = -6;
		
		for (unsigned char c : inputString)
		{
			upperLimit = (upperLimit << 8) + c;
			lowerLimit += 8;
			while (lowerLimit >= 0)
			{
				base64String.push_back(BASE64_CHARS[(upperLimit >> lowerLimit) & 0x3F]);
				lowerLimit -= 6;
			}
		}
		
		if (lowerLimit > -6) base64String.push_back(BASE64_CHARS[((upperLimit << 8) >> (lowerLimit + 8)) & 0x3F]);

		while (base64String.size() % 4) base64String.push_back(EQUALS_CHAR);
		
		return base64String;
	}
	/**
	 * \brief Reads JSON file and creates JSON Object
	 * \param filePath 
	 * \param searchKey 
	 */
	inline void ReadJsonFile(QString filePath, QString &searchKey)
	{
		QString jsonString;
		try {
			jsonString = ReadFile(filePath); // Reading the JSON file
		}
		catch (errno_t) 
		{
			qFatal("Error in readJsonFile() - Could not read JSON file!");
		}
		
		bool parseSuccessful;
		JsonObject jsonObject = QtJson::parse(jsonString, parseSuccessful).toMap(); // Parsing the JSON file and storing it to JSON Object

		if (!parseSuccessful)
		{
			qFatal("Error in readJsonFile() - An error occurred while parsing JSON file");
		}
		
		JsonObject urlsJSON = jsonObject["urlList"].toMap(); //Get URLs from JSON Object jsonObject. @TO-Do urlList move to Definitions.h
		searchKey = urlsJSON[searchKey].toString();
	}
	/**
	 * \brief Forms Basic Authorization string using User Id and Password for Rest Basic Authentication
	 * \param userId 
	 * \param password 
	 */
	inline void SetUserIdAndPassword(string userId, string password)
	{
		basicAuthorizationString = BASIC + ConvertToBase64(userId + COLON + password);
	}
	/**
	 * \brief Hits Rest End point with a HTTP request for Authorization
	 * \param restEndPoint 
	 * \param restCallParameters 
	 * \param response 
	 * \return bool
	 */
	inline bool SendJsonRequest(string restEndPoint, string restCallParameters, string &response)
	{
		vector<pair<string, string>> headerNameAndValue;
		headerNameAndValue.push_back(make_pair(AUTHORIZATION, basicAuthorizationString));
		headerNameAndValue.push_back(make_pair(INFOR_TENANT, FPLMUAT_TST));
		
		response = REST_API->CallRESTPost(restEndPoint, &restCallParameters, headerNameAndValue, HTTP_POST);

		size_t found = response.find(RESPONSE_200);
		if (found != string::npos)
			return true;
		
		return false;
	}
	/**
	 * \brief Decodes Base 64 Encoded string returns
	 * \param encodedString 
	 * \return string
	 */
	inline string DecodeBase64(std::string const &encodedString)
	{
		int encodedStringLength = encodedString.size();
		int i = 0;
		int j = 0;
		int charIndex = 0;
		unsigned char charArrayOf4[4], charArrayOf3[3];
		std::string decodedString;
		
		while (encodedStringLength-- && (encodedString[charIndex] != EQUALS_CHAR) && IsBase64Char(encodedString[charIndex]))
		{
			charArrayOf4[i++] = encodedString[charIndex]; charIndex++;
			if (i == 4) {
				for (i = 0; i < 4; i++)
					charArrayOf4[i] = BASE64_CHARS.find(charArrayOf4[i]);

				charArrayOf3[0] = (charArrayOf4[0] << 2) + ((charArrayOf4[1] & 0x30) >> 4);
				charArrayOf3[1] = ((charArrayOf4[1] & 0xf) << 4) + ((charArrayOf4[2] & 0x3c) >> 2);
				charArrayOf3[2] = ((charArrayOf4[2] & 0x3) << 6) + charArrayOf4[3];

				for (i = 0; (i < 3); i++) 
				{
					decodedString += charArrayOf3[i];
				}

				i = 0;
			}
		}
		if (i)
		{
			for (j = i; j < 4; j++)
				charArrayOf4[j] = 0;

			for (j = 0; j < 4; j++)
				charArrayOf4[j] = BASE64_CHARS.find(charArrayOf4[j]);

			charArrayOf3[0] = (charArrayOf4[0] << 2) + ((charArrayOf4[1] & 0x30) >> 4);
			charArrayOf3[1] = ((charArrayOf4[1] & 0xf) << 4) + ((charArrayOf4[2] & 0x3c) >> 2);
			charArrayOf3[2] = ((charArrayOf4[2] & 0x3) << 6) + charArrayOf4[3];

			for (j = 0; (j < i - 1); j++) 
			{
				decodedString += charArrayOf3[j];
			}
		}
		return decodedString;
	}
	/**
	 * \brief Method checks for error decriiption in Rest call response, //@To-Do Modifications are required
	 * \param response 
	 * \return string
	 */
	inline string CheckErrorDescription(string response) {
		string finalErrorMessage = "";
		string str1 = "ruleDescription";
		size_t found = response.find(str1);
		string str2 = "Unauthorized";
		size_t found1 = response.find(str2);
		string str3 = "Message";
		size_t found2 = response.find(str3);
		//	if (response.find("Message")) {
		if (found2 != string::npos) {
			int indexForContent1234 = response.find("Date");
			string str323 = response.substr(0, indexForContent1234);
			//UTILITY_API->DisplayMessageBox("checkErrorDescriptionstr323:: " + str323);
			int indexForContent12 = response.find("\"Message\""); //index of ruleDescription
			int indexForContent13 = response.find("at Infor.FashionPLM");
			//UTILITY_API->DisplayMessageBox("found indexForContent13: " + to_string(indexForContent13));
			int valueForToken = indexForContent13 - indexForContent12;
			string str3 = response.substr(indexForContent12, valueForToken);
			//UTILITY_API->DisplayMessageBox("checkErrorDescriptionstr3:: " + str3);
			finalErrorMessage = str323 + "\n" + str3;
			//UTILITY_API->DisplayMessageBox("finalErrorMessage found2" + finalErrorMessage);
			return finalErrorMessage;
		}
		else if (found != string::npos || found1 != string::npos) {
			//UTILITY_API->DisplayMessageBox("Inside checkErrorDescription");
			int indexForContent1234 = response.find("Date");
			string str323 = response.substr(0, indexForContent1234);
			//UTILITY_API->DisplayMessageBox("str323 ::" + str323);
			//UTILITY_API->DisplayMessageBox("Inside checkErrorDescription1");
			int indexForContent1 = response.find("\"ruleDescription\""); //index of ruleDescription
			//UTILITY_API->DisplayMessageBox("indexForContent1 ::" + to_string(indexForContent1));
			int indexForContent3 = response.find(",\"ruleCaption\"");
			//UTILITY_API->DisplayMessageBox("indexForContent3 ::" + to_string(indexForContent3));
			//UTILITY_API->DisplayMessageBox("Inside checkErrorDescription2");
			int valueForToken = indexForContent3 - indexForContent1;
			//UTILITY_API->DisplayMessageBox("valueForToken ::" + to_string(valueForToken));
			string str3 = response.substr(indexForContent1, valueForToken);
			finalErrorMessage = str323 + "\n" + str3;
			//UTILITY_API->DisplayMessageBox(finalErrorMessage);
			//UTILITY_API->DisplayMessageBox("finalErrorMessage found or found1" + finalErrorMessage);
			return finalErrorMessage;
		}
		else {
			return finalErrorMessage;
		}
	}
	/**
	 * \brief Calculates size of the content from file
	 * \param path 
	 * \return size_t
	 */
	static size_t GetFileSize(const std::string& path)
	{
		std::streampos begin, end;
		std::ifstream myFile(path.c_str(), std::ios::binary);
		begin = myFile.tellg();
		myFile.seekg(0, std::ios::end);
		end = myFile.tellg();
		myFile.close();
		
		return ((end - begin) > 0) ? (end - begin) : 0;
	}
	/**
	 * \brief Calls Rest service to Upload files from CLO to Rest Service//@To-Do Modifications are required
	 * \param filePath 
	 * \param token 
	 * \return string
	 */
	inline string UploadFile(string filePath, string token) 
	{
		QFile templateFile(QString::fromStdString(filePath));
		if (!templateFile.open(QFile::ReadOnly | QFile::Text))
		{
			string errorMessage = "Unable to open template";
			UTILITY_API->DisplayMessageBox(errorMessage);
			return "";
		}
		else    // file opened and ready to read from
		{
			std::string contentType = "";
			QFileInfo fileInfo(templateFile);
			std::string fileName = fileInfo.fileName().toStdString();
			std::string fileExtension = fileInfo.suffix().toStdString();
			
			if (fileExtension.compare("bmp") == 0 || fileExtension.compare("BMP") == 0) {
				contentType = "image/bmp";
			}
			else if (fileExtension.compare("gif") == 0 || fileExtension.compare("GIF") == 0) {
				contentType = "image/gif";
			}
			else if (fileExtension.compare("jpg") == 0 || fileExtension.compare("JPG") == 0) {
				contentType = "image/jpeg";
			}
			else if (fileExtension.compare("jpeg") == 0 || fileExtension.compare("JPEG") == 0) {
				contentType = "image/jpeg";
			}
			else if (fileExtension.compare("png") == 0 || fileExtension.compare("PNG") == 0) {
				contentType = "image/png";
			}
			else if (fileExtension.compare("pdf") == 0) {
				contentType = "application/pdf";
			}
			else if (fileExtension.compare("doc") == 0 || fileExtension.compare("docx") == 0) {
				contentType = "application/msword";
			}
			else if (fileExtension.compare("ppt") == 0 || fileExtension.compare("pptx") == 0) {
				contentType = "application/vnd.ms-powerpoint";
			}
			else if (fileExtension.compare("zip") == 0 || fileExtension.compare("rar") == 0) {
				contentType = "application/zip";
			}
			else if (fileExtension.compare("rtf") == 0) {
				contentType = "application/rtf";
			}
			else if (fileExtension.compare("xls") == 0 || fileExtension.compare("xlsx") == 0) {
				contentType = "application/vnd.ms-excel";
			}
			
			std::ifstream inFile(filePath, std::ios_base::binary);
			inFile.seekg(0, std::ios_base::end);
			size_t length = inFile.tellg();
			inFile.seekg(0, std::ios_base::beg);
			std::vector<char> buffer;
			buffer.reserve(length);
			std::copy(std::istreambuf_iterator<char>(inFile), std::istreambuf_iterator<char>(), std::back_inserter(buffer));
			std::stringstream fileStream;
			for (size_t i = 0; i < buffer.size(); ++i)
			{
				fileStream << buffer[i];
			}
			string requestToken = token;
			string atta = "{ \"objectFilePath\":\" blob:https:\/\/uat.fplm.awsdev.infor.com\/c08975fd-c1c5-4084-ac80-6b4ae6359fdf\",\"objectExtension\":null,\"sequence\":0,\"details\":{\"name\":null,\"note\":null,\"dlType\":0,\"type\":\"skeches\"},\"referenceId\":0,\"modifyDate\":\"0001-01-01T00:00:00\",\"code\":\"\",\"isDefault\":false,\"objectId\":0,\"originalObjectName\":\"" + fileName + "\",\"objectStream\":null,\"tempId\":\"MC4yMjczMDIz\"}\r\n";
			std::stringstream ss;
			ss << "Content-Length: " << GetFileSize(filePath) << "";
			std::string contentLength = ss.str();
			string requestParams = "------WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"\r\n";
			requestParams += "atta: " + atta + "\r\n";
			requestParams += "Content-Type: " + contentType + "\r\n";
			requestParams += contentLength + "\r\n\r\n";
			requestParams += fileStream.str();
			requestParams += "\r\n";
			requestParams += "------WebKitFormBoundary7MA4YWxkTrZu0gW--";
			vector<pair<string, string>> requestHeader;
			requestHeader.push_back(make_pair("Authorization", requestToken));
			requestHeader.push_back(make_pair("Content-Type", "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW"));
			requestHeader.push_back(make_pair("x-infor-tenant", "FPLMUAT_TST"));
			string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/documents/api/document/UploadFile", &requestParams, requestHeader, "Uploading...");
			//UTILITY_API->DisplayMessageBox("CallRESTPost response upload::" + response);
			//int indexForContent = response.find("Content-Type:");
			//string strForCheck = response.substr(indexForContent);
			//int indexForJSON = strForCheck.find("{");
			//string strForJSON = strForCheck.substr(indexForJSON);
			//json checkErrorJson = json::parse(strForJSON);
			//string errorFiles = checkErrorJson["errorFiles"].dump();
			//json errorFilesJson = json::parse(errorFiles);
			//int errorFilesSize = errorFilesJson.size();
			////UTILITY_API->DisplayMessageBox("errorFilesSize::" + errorFilesSize);
			//if (errorFilesSize != 0) 
			//{
			//	string errorMessage = checkErrorJson["errorFiles"][0]["errorMessage"].dump();
			//	UTILITY_API->DisplayMessageBox("errorMessage" + errorMessage);
			//	return "Null";
			//}
			return response;
		}
	}
	/**
	 * \brief Attaches file as attachement to Style by calling rest service//@To-Do Modifications are required
	 * \param param 
	 * \param token 
	 * \return string
	 */
	inline string  LinkAttachemntToStyle(string& param, string& token)
	{	
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", token));
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/documents/api/document/SaveMetadata",&param, headerNameAndValueList, "HTTP Post");
		
		return "";
	}
	/**
	 * \brief Download image from URL //@To-Do Modifications are required
	 * \param url 
	 * \param fileName 
	 */
	inline void DownloadImageFromURL(string& url, string& fileName)
	{
		CURL* image;
		CURLcode imageResult;
		FILE* fp = nullptr;
	
		const char* tempurl = url.c_str(); 
		image = curl_easy_init();
		
		if (image)
		{
			fp = fopen(fileName.c_str(), "wb");
			if (fp == NULL) UTILITY_API->DisplayMessageBox("File cannot be opened");
			
			curl_easy_setopt(image, CURLOPT_WRITEFUNCTION, NULL);
			curl_easy_setopt(image, CURLOPT_WRITEDATA, fp);
			curl_easy_setopt(image, CURLOPT_URL, tempurl);
			curl_easy_setopt(image, CURLOPT_SSL_VERIFYPEER, 0);
			// Grab image
			imageResult = curl_easy_perform(image);
			
			if (imageResult)
				cout << "Cannot grab the image!\n";
		}
		// Clean up the resources
		curl_easy_cleanup(image);
		// Close the file
		fclose(fp);
	}
	/**
	 * \brief Writes data to file stream
	 * \param ptr 
	 * \param size 
	 * \param nmemb 
	 * \param stream 
	 * \return size_t
	 */
	inline size_t WriteData(void* ptr, size_t size, size_t nmemb, FILE* stream) {
		size_t written;
		written = fwrite(ptr, size, nmemb, stream);
		
		return written;
	}
	/**
	 * \brief Downloads file from Rest Service URL
	 * \param URL 
	 * \param fileName 
	 */
	inline void DownloadFilesFromURL(string& URL, string& fileName)
	{
		CURL* curl;
		FILE* fp;
		CURLcode res;
		string url1;
		const char* url = URL.c_str();
		curl_version_info_data* vinfo = curl_version_info(CURLVERSION_NOW);
		if (vinfo->features & CURL_VERSION_SSL) {
			printf("CURL: SSL enabled\n");
		}
		else {
			printf("CURL: SSL not enabled\n");
		}
		curl = curl_easy_init();
		if (curl) {
			fp = fopen(fileName.c_str(), "wb");
			/* Setup the https:// verification options. Note we   */
			/* do this on all requests as there may be a redirect */
			/* from http to https and we still want to verify     */
			curl_easy_setopt(curl, CURLOPT_URL, url);
			curl_easy_setopt(curl, CURLOPT_CAINFO, "./ca-bundle.crt");
			//curl_easy_setopt(curl, CURLOPT_USERPWD, "wcadmin:wcadmin"); //now ani trims image isssue
			curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
			curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, false);
			curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteData);
			curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);
			res = curl_easy_perform(curl);
			curl_easy_cleanup(curl);
			int i = fclose(fp);
		}
	}
	/**
	 * \brief Deletes all files and directory of the provided folder
	 * \param folder 
	 */
	inline void RemoveDirectory(const wchar_t* folder)
	{
		std::wstring folderPath = std::wstring(folder) + _T("/*.*");
		std::wstring searchPath = std::wstring(folder) + _T("/");
		WIN32_FIND_DATA findData;
		HANDLE hanldeFind = ::FindFirstFile(folderPath.c_str(), &findData);
		if (hanldeFind != INVALID_HANDLE_VALUE) {
			do {
				if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
					if (wcscmp(findData.cFileName, _T(".")) != 0 && wcscmp(findData.cFileName, _T("..")) != 0)
					{
						RemoveDirectory((wchar_t*)(searchPath + findData.cFileName).c_str());
					}
				}
				else {
					DeleteFile((searchPath + findData.cFileName).c_str());
				}
			} while (::FindNextFile(hanldeFind, &findData));
			::FindClose(hanldeFind);
			_wrmdir(folder);
		}
	}
	//To-Do Is this required?
	inline int getFileSize(const std::string& fileName)
	{
		ifstream file(fileName.c_str(), ifstream::in | ifstream::binary);

		if (!file.is_open())
		{
			return -1;
		}

		file.seekg(0, ios::end);
		int fileSize = file.tellg();
		file.close();

		return fileSize;
	}
	/**
	 * \brief Search for Sub String in a String and deletes it.
	 * \param completeString 
	 * \param toEraseString 
	 */
	inline void EraseSubString(std::string& completeString, const std::string& toEraseString)
	{
		// Search for the substring in string
		size_t pos = completeString.find(toEraseString);

		if (pos != std::string::npos)
		{
			// If found then erase it from string
			completeString.erase(pos, toEraseString.length()+5);
		}
	}
}