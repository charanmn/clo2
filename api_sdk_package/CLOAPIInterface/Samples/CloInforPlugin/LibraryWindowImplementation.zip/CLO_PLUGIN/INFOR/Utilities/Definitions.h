#pragma once

#include <QString>
#include <QVariant>
#include <string>

using namespace std;
const int iconHieght = 18;
const int iconWidth = 18;
const QString inputStyle = "font: 75 10pt \"Tahoma\";";
const QString inputFont = "font: 75 10pt \"Tahoma\";";

#define UPLOAD_FILE_SIZE 5242880 //5MB


const string SAMPLE_ASSETS_DIRECTORY = "C:\\sample_assets\\";
const QString SAMPLES_STORAGE_DIRECTORY = QString("C:\\sample_assets\\plm\\");
const string MATERIALS_TEMP_DIRECTORY = "C:\\MiddlewareFiles\\TempMaterials\\";
const string PRODUCTS_TEMP_DIRECTORY = "C:\\MiddlewareFiles\\TempProducts\\";
const string MATERIALS_ASSETS_DIRECTORY = "C:\\sample_assets\\plm\\material\\";
const string STYLE_ATTACHMENTS_DIRECTORY = "C:\\sample_assets\\plm\\product\\";
const string TRIMS_TEMP_DIRECTORY = "C:\\MiddlewareFiles\\TempTrims\\";
const string TRIMS_ASSETS_DIRECTORY = "C:\\sample_assets\\plm\\trim\\";
const string COLORS_TEMP_DIRECTORY = "C:\\MiddlewareFiles\\TempColors\\";
const string COLORS_ASSETS_DIRECTORY = "C:\\sample_assets\\plm\\color\\";
const string MIDDLEWARE_DIRECTORY = "C:\\MiddlewareFiles\\";

const string NOW_TEXT = "now";
//const char* DATE_TIME_FORMAT = "%Y-%m-%d %X";
const string DATE_TEXT = "date";
//const char* DATE_FORMAT = "%Y-%m-%d";
const string TEXT_FILE_EXTENSION = ".txt";
//const char* URL_LIST_KEY = "urlList";
const string BASIC = "Basic ";
const string COLON = "Basic ";
const string AUTHORIZATION = "Authorization";
const string INFOR_TENANT = "x-infor-tenant";
const string FPLMUAT_TST = "FPLMUAT_TST";
const string HTTP_POST = "HTTP Post";
const string RESPONSE_200 = "200";



const char NEW_LINE_CHAR = '\n';
const char TAB_SPACE_CHAR = '\t';
const char EQUALS_CHAR = '=';

const string BASE64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";