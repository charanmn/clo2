#pragma once
#include "DesignSuite.h"
#include <QDebug>
#include <qmessagebox.h>
#include "CLO_PLUGIN/INFOR/Materials/Fabrics/FabricsSearchDialog.h"
#include "CLO_PLUGIN/INFOR/Products/createproduct.h"
#include "CLO_PLUGIN/INFOR/Products/ProductSearch.h"
#include "CLO_PLUGIN/INFOR/Products/UpdateProduct.h"
#include <exception>
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
#include "CLO_PLUGIN/INFOR/Materials/Trims/TrimsSearch.h"
#include "CLO_PLUGIN/INFOR/Colors/ColorSearch.h"

using namespace std;
/*
*brief having the methods for navigating all the functions for (product,material,color)related.
*getInstance and destroy methods for making the classs as a singleton 
*/

namespace CLOPlugin
{
	/*
	*m_bearerToken memeber variable to get and set the bearerToken. 
	*/
	DesignSuite* DesignSuite::_instance = NULL;
	string DesignSuite::m_bearerToken = " ";

	DesignSuite* DesignSuite::GetInstance()
	{
		if (_instance == NULL) {
			_instance = new DesignSuite();
		}

		return _instance;
	}

	void DesignSuite::Destroy()
	{
		if (_instance) {
			delete _instance;
			_instance = NULL;
		}
	}

	DesignSuite::DesignSuite(QWidget* parent, Qt::WindowFlags flags)
		: QDialog(parent, flags)
	{
		setupUi(this);
		const char* newDirPath = MIDDLEWARE_DIRECTORY.c_str();
		mkdir(newDirPath);
		newDirPath = SAMPLE_ASSETS_DIRECTORY.c_str();
		mkdir(newDirPath);
		newDirPath = SAMPLES_STORAGE_DIRECTORY.toStdString().c_str();
		mkdir(newDirPath);
		newDirPath = MATERIALS_ASSETS_DIRECTORY.c_str();
		mkdir(newDirPath);
		newDirPath = STYLE_ATTACHMENTS_DIRECTORY.c_str();
		mkdir(newDirPath);


		ShMaterial->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_search_over.svg"));
		ShMaterial->setIconSize(QSize(iconHieght, iconWidth));

		CreateProduct->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_add_over.svg"));
		CreateProduct->setIconSize(QSize(iconHieght, iconWidth));

		searchProducts->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_search_over.svg"));
		searchProducts->setIconSize(QSize(iconHieght, iconWidth));

		UpdateProduct->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_update_over.svg"));
		UpdateProduct->setIconSize(QSize(iconHieght, iconWidth));

		ShColor->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_search_over.svg"));
		ShColor->setIconSize(QSize(iconHieght, iconWidth));

		trimsSearch->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_search_over.svg"));
		trimsSearch->setIconSize(QSize(iconHieght, iconWidth));

		QObject::connect(Cancel, SIGNAL(clicked()), this, SLOT(closeWindow()));
		QObject::connect(ShMaterial, SIGNAL(clicked()), this, SLOT(materialSearch()));
		QObject::connect(CreateProduct, SIGNAL(clicked()), this, SLOT(clickedCreatProd()));
		QObject::connect(searchProducts, SIGNAL(clicked()), this, SLOT(clickedSearchProd()));
		QObject::connect(UpdateProduct, SIGNAL(clicked()), this, SLOT(clickedUpdateProd()));
		QObject::connect(ShColor, SIGNAL(clicked()), this, SLOT(clickedSearchColors()));
		QObject::connect(trimsSearch, SIGNAL(clicked()), this, SLOT(clickedSearchTrims()));	
	}

	DesignSuite::~DesignSuite()
	{
	}
	/*
	*brief usign try catch for through the exception.
	*clickedSearchColors for execute the functionality when the clike of search Color button.
	*Passing the m_bearerToken.
	*Clear all fields items in the ColorSearch UI.
	*/
	void DesignSuite::clickedSearchColors()
	{
		this->hide();
		try
		{
			ColorSearch::GetInstance()->setModal(true);
			ColorSearch::GetInstance()->setWindowTitle("Color Search Criteria");
			ColorSearch::GetInstance()->SetBearerToken(m_bearerToken);
			ColorSearch::GetInstance()->ClearAllFields();
			ColorSearch::GetInstance()->exec();
		}

		catch (exception & e)
		{
			UTILITY_API->DisplayMessageBox("Exception!!" + string(e.what()));
		}
		catch (const char* msg)
		{
			UTILITY_API->DisplayMessageBox("Exception :: " + string(msg));
		}
	}
	/*
	*brief usign try catch for through the exception.
	*clickedSearchTrims for execute the functionality when the clike of Search Material-Trims button.
	*Passing the m_bearerToken.
	*Clear all fields items in the TrimsSearch UI.
	*/
	void DesignSuite::clickedSearchTrims()
	{
		this->hide();
		try
		{
			TrimsSearch::GetInstance()->setModal(true);
			TrimsSearch::GetInstance()->setWindowTitle("Trims Search Criteria");
			TrimsSearch::GetInstance()->SetBearerToken(m_bearerToken);
			TrimsSearch::GetInstance()->ClearAllFields();
			TrimsSearch::GetInstance()->exec();
		}
		catch (exception & e)
		{
			UTILITY_API->DisplayMessageBox("Exception!!" + string(e.what()));
		}
		catch (const char* msg)
		{
			UTILITY_API->DisplayMessageBox("Exception :: " + string(msg));
		}
	}
	/*
	*brief set bearerToken vaule.
	*recived from authontication class.
	*/
	void DesignSuite::SetBearerToken(string& bearerToken)
	{
		m_bearerToken = bearerToken;
	}

	/*
	*brief usign try catch for through the exception.
	*clickedSearchTrims for execute the functionality when the clike of Search Material-Fabrics button.
	*Passing the m_bearerToken.
	*Clear all fields items in the MaterialSearchDialog UI.
	*/
	void DesignSuite::materialSearch()
	{
		this->hide();
		try
		{
			MaterialSearchDialog::GetInstance()->setModal(true);
			MaterialSearchDialog::GetInstance()->SetBearerToken(m_bearerToken);
			MaterialSearchDialog::GetInstance()->ClearAllFields();
			MaterialSearchDialog::GetInstance()->exec();
		}
		catch (exception & e)
		{
			UTILITY_API->DisplayMessageBox("Exception!!" + string(e.what()));
		}
		catch (const char* msg)
		{
			UTILITY_API->DisplayMessageBox("Exception :: " + string(msg));
		}
	}

	/*
	*brief usign try catch for through the exception.
	*clickedCreatProd for execute the functionality when the clike of create product button.
	*Passing the m_bearerToken.
	*Clear all fields items in createProduct UI, when the user donsn't save&close button .
	*/

	void DesignSuite::clickedCreatProd()
	{		
		this->hide();
		try
		{
			createProduct::GetInstance()->setModal(true);
			createProduct::GetInstance()->SetBearerToken(m_bearerToken);
			if(createProduct::GetInstance()->IsSaveClicked() == false)
			{
				createProduct::GetInstance()->ClearAllFields();
			}
			createProduct::GetInstance()->exec();
		}
		catch (exception & e)
		{
			UTILITY_API->DisplayMessageBox("Exception!!" + string(e.what()));
		}
		catch (const char* msg)
		{
			UTILITY_API->DisplayMessageBox("Exception :: " + string(msg));
		}
		
	}
	/*
	*brief usign try catch for through the exception.
	*clickedSearchProd for execute the functionality when the clike of Search product button.
	*Passing the m_bearerToken.
	*Clear all fields items in the ProductSearch UI.
	*/
	void DesignSuite::clickedSearchProd()
	{
		this->hide();
		try
		{
			ProductSearch::GetInstance()->setModal(true);
			ProductSearch::GetInstance()->SetBearerToken(m_bearerToken);
			ProductSearch::GetInstance()->ClearAllFields();
			ProductSearch::GetInstance()->exec();
		}
		catch (exception& e)
		{
			UTILITY_API->DisplayMessageBox("Exception!!" + string(e.what()));
		}
		catch (const char* msg)
		{
			UTILITY_API->DisplayMessageBox("Exception :: " + string(msg));
		}
	}
	/*
	*brief usign try catch for through the exception.
	*clickedUpdateProd() for execute the functionality when the clike of Update product button.
	*Passing the m_bearerToken.
	*Clear all fields items in the ProductSearch UI.
	*/
	void DesignSuite::clickedUpdateProd()
	{
		this->hide();
		try
		{
			UpdateProduct::GetInstance()->setModal(true);
			UpdateProduct::GetInstance()->SetBearerToken(m_bearerToken);
			if (createProduct::GetInstance()->IsSaveClicked() == false)
			{
				UpdateProduct::GetInstance()->ClearAllFields();
			}
			UpdateProduct::GetInstance()->SetAllFields();
			UpdateProduct::GetInstance()->exec();
		}
		catch (exception & e)
		{
			UTILITY_API->DisplayMessageBox("Exception!!" + string(e.what()));
		}
		catch (const char* msg)
		{
			UTILITY_API->DisplayMessageBox("Exception :: " + string(msg));
		}
	}
	/*
	*brief closeWindow to close the designSuite UI.
	*/
	void DesignSuite::closeWindow()
	{
		close();
	}
	/*
	*brief get bearerToken vale from authontication.
	*return string.
	*/
	string& DesignSuite::GetBearerToken()
	{
		return m_bearerToken;
	}
}

