#include "FabricsResultTable.h"
#include <qmessagebox.h>
#include <qcheckbox.h>
#include <direct.h>
#include "classes/APICLODataBase.h"
#include "classes/APIStorage.h"
#include "classes/APIDefine.h"
#include <CLOAPIInterface.h>
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
#include "FabricsSearchDialog.h"

using namespace std;
bool checkzfab = false;
namespace CLOPlugin {
	string ResultTable::m_bearerToken = " ";
	/**
	 * \brief Prepares the complete result table using Widgets as parameter
	 * \param parent 
	 * \param flags 
	 */
	ResultTable::ResultTable(QWidget* parent, Qt::WindowFlags flags) : QDialog(parent, flags)
	{
		Utility::Logger("ResultTable -> Constructor() -> Start");
		
		setupUi(this);
		QString styleSheet = "::section {""color: white;""border: 1px grey;""text-align: center;""font-family: times new roman;""font-size: 14px; }";

		tableWidget->horizontalHeader()->setStyleSheet(styleSheet);
		tableWidget->verticalHeader()->setStyleSheet(styleSheet);
		tableWidget->setFocusPolicy(Qt::NoFocus);
		tableWidget->setVisible(false);
		tableWidget->resizeColumnsToContents();
		tableWidget->setVisible(true);
		tableWidget->setColumnCount(14);
		tableWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		tableWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		tableWidget->verticalHeader()->blockSignals(true);
		tableWidget->horizontalHeader()->setFixedHeight(80);
		tableWidget->horizontalHeader()->setDefaultSectionSize(80);
		tableWidget->verticalHeader()->setDefaultSectionSize(80);
		tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
		QFont font;
		font.setPointSize(14);
		font.setBold(true);
		tableWidget->horizontalHeader()->setFont(font);
		QStringList headerlist;
		tableWidget->horizontalHeader()->setResizeMode(QHeaderView::Stretch);
		tableWidget->setWordWrap(true);
	
		headerlist << "Select" << "Number" << "Name" << "Image" << "Id" << "Main\n Category" << "Category" << "Category\n Group" << "Type" <<"Brand" << "Division" << "Season" << "Status"<<"User";

		QTableWidgetItem* itemCheckbox = new QTableWidgetItem(" ");
		itemCheckbox->setCheckState(Qt::Unchecked);
		QModelIndexList selection = tableWidget->selectionModel()->selectedRows();
		tableWidget->setItem(0, 0, itemCheckbox);
		
		tableWidget->setHorizontalHeaderLabels(headerlist);
	

		Back->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_back_over.svg"));
		Back->setIconSize(QSize(iconHieght, iconWidth));

		OK->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_down_over.svg"));
		OK->setIconSize(QSize(iconHieght, iconWidth));

		QObject::connect(OK, SIGNAL(clicked()), this, SLOT(DownloadClicked()));
		QObject::connect(Back, SIGNAL(clicked()), this, SLOT(OnBackClicked()));
		QObject::connect(closeWindow1, SIGNAL(clicked()), this, SLOT(closeWindow()));		

		Utility::Logger("ResultTable -> Constructor() -> End");
	}
	ResultTable::~ResultTable()
	{
	
	}
	/**
	 * \brief Adds rows data to Results table for Materials
	 * \param MaterialFabricResults 
	 * \param FabIcon 
	 */
	void ResultTable::AddRowData(Utility::MaterialFabricResults& MaterialFabricResults, QIcon FabIcon)
	{
		Utility::Logger("ResultTable -> AddRowData() -> Start");

		QTableWidgetItem* headerItem = new QTableWidgetItem();
		AddColoums(headerItem, MaterialFabricResults, FabIcon);
		m_FabricResults.push_back(MaterialFabricResults);

		Utility::Logger("ResultTable -> AddRowData() -> End");
	}
	/**
	 * \brief Add columns to Result table
	 * \param parent 
	 * \param MaterialFabricResults 
	 * \param FabIcon 
	 */
	void ResultTable::AddColoums(QTableWidgetItem* parent, Utility::MaterialFabricResults& MaterialFabricResults, QIcon FabIcon)
	{
		Utility::Logger("ResultTable -> AddColoums() -> Start");

		QString styleSheet = "::section {""color: white;""border: 1px grey;""text-align: right;""font-family: arial;""font-size: 14px; }";
		tableWidget->horizontalHeader()->setStyleSheet(styleSheet);
		tableWidget->verticalHeader()->setStyleSheet(styleSheet);

		int currentRow = tableWidget->rowCount();
		tableWidget->setRowCount(currentRow + 1);
		
		for (int c = 0; c < tableWidget->columnCount(); ++c)
		{
			QCheckBox* checkBox = new QCheckBox;
			checkBox->setCheckable(true);
			checkBox->setStyleSheet("margin-left:35%; margin-right:65%;");			
			checkBox->setCheckState(Qt::Unchecked);
			tableWidget->setStyleSheet("QTableWidget::indicator:unchecked {background-color:white;}");
			tableWidget->setCellWidget(currentRow, 0, checkBox);
			
			QTableWidgetItem* itemImage = new QTableWidgetItem;
			itemImage->setTextAlignment(Qt::AlignCenter);
			
			tableWidget->setIconSize(QSize(80, 80));
			itemImage->setSizeHint(QSize(80, 80));
			itemImage->setIcon(FabIcon);

			QTableWidgetItem* itemCode = new QTableWidgetItem(MaterialFabricResults.fabricCode);
			itemCode->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemName = new QTableWidgetItem(MaterialFabricResults.fabricName);
			itemName->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemFabID = new QTableWidgetItem(MaterialFabricResults.fabricId);
			itemFabID->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemType = new QTableWidgetItem(MaterialFabricResults.fabricType);
			itemType->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemBrand = new QTableWidgetItem(MaterialFabricResults.fabricBrand);
			itemBrand->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemDivision = new QTableWidgetItem(MaterialFabricResults.fabricDivision);
			itemDivision->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemStatus = new QTableWidgetItem(MaterialFabricResults.fabricStatus);
			itemStatus->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemSeason = new QTableWidgetItem(MaterialFabricResults.fabricSeason);
			itemSeason->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemUser = new QTableWidgetItem(MaterialFabricResults.fabricUser);
			itemUser->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemCategory = new QTableWidgetItem(MaterialFabricResults.fabricCategory);
			itemCategory->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemMainCategory = new QTableWidgetItem(MaterialFabricResults.fabricMainCategory);
			itemMainCategory->setTextAlignment(Qt::AlignCenter);

			QTableWidgetItem* itemCategoryGroup = new QTableWidgetItem(MaterialFabricResults.fabricCategoryGroup);
			itemCategoryGroup->setTextAlignment(Qt::AlignCenter);
					
			tableWidget->setCellWidget(currentRow, 0, checkBox/*dataItem*/);
			tableWidget->setItem(currentRow, 1, itemCode);
			tableWidget->setItem(currentRow, 2, itemName);
			tableWidget->setItem(currentRow, 3, itemImage);
			tableWidget->setItem(currentRow, 4, itemFabID);
			tableWidget->setItem(currentRow, 5, itemMainCategory);
			tableWidget->setItem(currentRow, 6, itemCategory);
			tableWidget->setItem(currentRow, 7, itemCategoryGroup);
			tableWidget->setItem(currentRow, 8, itemType);
			tableWidget->setItem(currentRow, 9, itemBrand);
			tableWidget->setItem(currentRow, 10, itemDivision);
			tableWidget->setItem(currentRow, 11, itemSeason);
			tableWidget->setItem(currentRow, 12, itemStatus);
			tableWidget->setItem(currentRow, 13, itemUser);
			QObject::connect(checkBox, SIGNAL(clicked()), this, SLOT(callCheckBoxSelected()));
		}
		Utility::Logger("ResultTable -> AddColoums() -> End");
	}
	/**
	 * \brief Looks for Check box selection and collects all selected rows
	 */
	void  ResultTable::callCheckBoxSelected()
	{
		int totalRowCount = tableWidget->rowCount();
		tableWidget->setSelectionMode(QAbstractItemView::MultiSelection);
		QStringList selectedRows;
		selectedRows.clear();
		for (int rowCount = 0; rowCount < totalRowCount; rowCount++)
		{
			QWidget* qWidget = tableWidget->cellWidget(rowCount, 0);
			QCheckBox* temp = qobject_cast<QCheckBox*>(qWidget);
			if (temp->checkState() == Qt::Checked)
			{			
				selectedRows << QString::fromStdString(to_string(rowCount));
			}

		}
		tableWidget->clearSelection();
		for (auto iterate : selectedRows)
		{
			tableWidget->selectRow(iterate.toInt());
		}
		selectedRows.clear();
	}
	/**
	 * \brief When download button clicked by user, it download corresponding details of material
	 */
	void  ResultTable::DownloadClicked() 
	{
		Utility::Logger("ResultTable -> DownloadClicked() -> Start");
		
		int rowCount = tableWidget->rowCount();
		int columnCount = tableWidget->columnCount();
		QString materialeId;
		QString materialName;
		QString materialCode;
		QString brand;
		QString imageLoadPath;
		QString imageSavePath;
		QString imageFileName;
		const char* newDirPath = MATERIALS_ASSETS_DIRECTORY.c_str();
		mkdir(newDirPath);
		bool isSelected = false;
		
		for (int row = 0; row < rowCount; row++)
		{
			QWidget* qWidget = tableWidget->cellWidget(row, 0);
			QCheckBox* tempCheckBox = qobject_cast<QCheckBox*>(qWidget); 
			if (tempCheckBox->checkState() == Qt::Checked)
			{
				isSelected = true;
			}
		}
		if (isSelected == false)
		{
			UTILITY_API->DisplayMessageBox("Select atleast one row to download");
		}
		else
		{
			this->hide();
			QImage imgNew;
			QString imageLoadPath, imageSavePath, code;
			for (int row = 0; row < rowCount; row++)
			{
				QWidget* qWidget = tableWidget->cellWidget(row, 0);
				QCheckBox* tempCheckBox = qobject_cast<QCheckBox*>(qWidget);
				if (tempCheckBox->checkState() == Qt::Checked)
				{
					QImage imgNew;
					materialeId = tableWidget->item(row, 4)->text();
					materialName = tableWidget->item(row, 2)->text();
					materialCode = tableWidget->item(row, 1)->text();
					int matchingindex = 0;
					for (int i = 0; i < m_FabricResults.size(); i++)
					{
						if (materialeId == m_FabricResults[i].fabricId)
						{
							matchingindex = i;
							break;
						}
					}
					QString imageLoadPath, imageSavePath, code;

					if ( m_FabricResults[matchingindex].fabricImage || m_FabricResults[matchingindex].fabricAtachment)
					{
						CLOAPISample::LibraryAPIItem* setItem = new CLOAPISample::LibraryAPIItem();
						if (m_FabricResults[matchingindex].fabricAtachment)
						{
							setItem->itemID = materialCode;
							setItem->itemName = materialCode + ".zfab";
							QString itemPath = materialCode + ".zfab";
							setItem->sampleItemData.itemPath = itemPath;
							setItem->sampleItemData.iconThumbnailPath = itemPath;
							setItem->sampleItemData.previewThumbnailPath = itemPath;
							setItem->dateTime = "2019-08-20T16:21:41";
							setItem->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("MATERIAL");
							setItem->metaData[META_DATA_KEY_2_BRAND] = m_FabricResults[matchingindex].fabricBrand;
							setItem->metaData[META_DATA_KEY_6_MATERIAL_ID] = m_FabricResults[matchingindex].fabricId;
							setItem->metaData[META_DATA_KEY_5_MATERIAL_NAME] = m_FabricResults[matchingindex].fabricName;
							setItem->metaData[META_DATA_KEY_7_MATERIAL_NUMBER] = materialCode;
						}
						else
						{
							setItem->itemID = materialCode;
							setItem->itemName = materialCode + ".png";
							imageLoadPath = QString::fromStdString(MATERIALS_TEMP_DIRECTORY) + materialCode + ".png";
							imageSavePath = QString::fromStdString(MATERIALS_ASSETS_DIRECTORY) + materialCode + ".png";
							imgNew.load(imageLoadPath);
							imgNew.save(imageSavePath);
							setItem->sampleItemData.itemPath = materialCode + ".png";
							setItem->sampleItemData.iconThumbnailPath = materialCode + ".png";
							setItem->sampleItemData.previewThumbnailPath = materialCode + ".png";
							setItem->dateTime = "2019-08-20T16:21:41";
							setItem->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("MATERIAL");
							setItem->metaData[META_DATA_KEY_2_BRAND] = m_FabricResults[matchingindex].fabricBrand;
							setItem->metaData[META_DATA_KEY_6_MATERIAL_ID] = m_FabricResults[matchingindex].fabricId;
							setItem->metaData[META_DATA_KEY_5_MATERIAL_NAME] = m_FabricResults[matchingindex].fabricName;
							setItem->metaData[META_DATA_KEY_7_MATERIAL_NUMBER] = materialCode;
						}
						bool alreadyExists = false;
						if (API_STORAGE)
						{
							for (int i = 0; i < API_STORAGE->m_LibraryAPIItemList.size(); i++)
							{
								if (API_STORAGE->m_LibraryAPIItemList[i]->metaData[META_DATA_KEY_7_MATERIAL_NUMBER] == materialCode)
								{
									API_STORAGE->m_LibraryAPIItemList[i] = setItem; //overwrite the same file
									alreadyExists = true;
									break;
								}
							}
							if (!alreadyExists)
								API_STORAGE->m_LibraryAPIItemList.push_back(setItem);
						}
					}
				}
			}
			wstring wideString = wstring(MATERIALS_TEMP_DIRECTORY.begin(), MATERIALS_TEMP_DIRECTORY.end());
			Utility::RemoveDirectory(wideString.c_str());
			UTILITY_API->DisplayMessageBox("Download completed");
			Utility::Logger("ResultTable -> DownloadClicked() -> Download completed.");
		}
		Utility::Logger("ResultTable -> DownloadClicked() -> End");
	}
	/**
	 * \brief Creates map of attachments to bo downloaded
	 * \param MaterialId 
	 */
	void ResultTable::CreateDownloadAttachmentsMap(int MaterialId)
	{
		Utility::Logger("ResultTable -> CreateDownloadAttachmentsMap() -> Start");

		json filterMap;
		json pageInfoMap;
		json conditions = json::object();

		m_downloadAttachmentsMap.clear();
		m_downloadAttachmentsMap["roleId"] = 1;
		m_downloadAttachmentsMap["userId"] = 71;
		m_downloadAttachmentsMap["schema"] = "FSH5";
		m_downloadAttachmentsMap["entity"] = "MaterialAttachments";
		m_downloadAttachmentsMap["pageType"] = "list";
		m_downloadAttachmentsMap["personalizationId"] = 0;
		m_downloadAttachmentsMap["pageInfo"] = nullptr;
		m_downloadAttachmentsMap["sortInfo"] = nullptr;

		filterMap.clear();
		filterMap["fieldname"] = "IsDeleted";
		filterMap["operator"] = "=";
		filterMap["value"] = 0;
		conditions["Conditions"][0] = filterMap;

		filterMap.clear();
		filterMap["fieldname"] = "Code";
		filterMap["operator"] = "=";
		filterMap["value"] = "E0024";
		conditions["Conditions"][1] = filterMap;

		filterMap.clear();
		filterMap["fieldname"] = "ReferenceId";
		filterMap["operator"] = "=";
		filterMap["value"] = MaterialId;
		conditions["Conditions"][2] = filterMap;

		m_downloadAttachmentsMap["dataFilter"] = conditions;

		Utility::Logger("ResultTable -> CreateDownloadAttachmentsMap() -> End");
	}
	/**
	 * \brief Downloads all attachments of style from json
	 */
	void ResultTable::DownloadStyleAttachments()
	{
		Utility::Logger("ResultTable -> DownloadStyleAttachments() -> Start");

		string parameters = to_string(m_downloadAttachmentsMap);
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", m_bearerToken));
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/view/api/view/layout/data/get", &parameters, headerNameAndValueList, "HTTP Post");

		json responseJson;
		string errorResponse = Utility::CheckErrorDescription(response);
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			int indexForContent = response.find("Content-Type:");
			string strForCheck = response.substr(indexForContent);
			int indexForJSON = strForCheck.find("{");
			string strForJSON = strForCheck.substr(indexForJSON);
			responseJson = json::parse(strForJSON);
			//UTILITY_API->DisplayMessageBox("strForJSON ::" + strForJSON);
			GetStyleAttachments(responseJson);
		}
		else
		{
			UTILITY_API->DisplayMessageBox(errorResponse);
			Utility::Logger("ResultTable -> DownloadStyleAttachments()" + errorResponse);
		}

		Utility::Logger("ResultTable -> DownloadStyleAttachments() -> End");
	}
	/**
	 * \brief Collects attachements of style from json
	 * \param response 
	 */
	void ResultTable::GetStyleAttachments(json response)
	{
		Utility::Logger("ResultTable -> GetStyleAttachments() -> Start");

		string column, attachmentURL;
		json completeStylesJson;
		string responseJsonStrStyle = response["entities"].dump();
		completeStylesJson = json::parse(responseJsonStrStyle);
		string responseJsonsize = to_string(completeStylesJson.size());
		string responseString = "";
		if (completeStylesJson.size() != 0)
		{
			for (int i = 0; i < completeStylesJson.size(); i++)
			{
				string entityJson = completeStylesJson[i].dump();
				json styles = json::parse(entityJson);
				string name = styles["name"].dump();
				name = name.erase(0, 1);
				name = name.erase(name.size() - 1);

				if (name == "MaterialAttachments")
				{
					column = styles["column"].dump();
					json columns = json::parse(column);
					attachmentURL = columns["CFilename"].dump();

					attachmentURL = attachmentURL.erase(0, 1);
					attachmentURL = attachmentURL.erase(attachmentURL.size() - 1);

					m_attachmentsFileName = columns["OFilename"].dump();
					if (m_attachmentsFileName != "Null")
					{
						m_attachmentsFileName = m_attachmentsFileName.erase(0, 1);
						m_attachmentsFileName = m_attachmentsFileName.erase(m_attachmentsFileName.size() - 1);
					}
					m_attachmentsAttaFileListId = columns["AttaFileListId"].dump();
				}
				Utility::DownloadFilesFromURL(attachmentURL, MATERIALS_ASSETS_DIRECTORY + m_attachmentsFileName);
			}
		}
		Utility::Logger("ResultTable -> GetStyleAttachments() -> End");
	}
	/**
	 * \brief Recordes Clock of Back button by user and stops sending request further.
	 */
	void ResultTable::OnBackClicked()
	{
		Utility::Logger("ResultTable -> OnBackClicked() -> Start");

		this->close();
		MaterialSearchDialog::GetInstance()->setModal(true);
		MaterialSearchDialog::GetInstance()->show();

		Utility::Logger("ResultTable -> OnBackClicked() -> End");
	}
	/**
	 * \brief Closes the window
	 */
	void ResultTable::closeWindow()
	{	
		Utility::Logger("ResultTable -> CloseWindow() -> Start");

		this->close();

		Utility::Logger("ResultTable -> CloseWindow() -> End");
	}
	/**
	 * \brief Sets latest bearer token to local variable
	 * \param bearerToken 
	 */
	void ResultTable::SetBearerToken(const string& bearerToken)
	{
		Utility::Logger("ResultTable -> SetBearerToken() -> Start");
		m_bearerToken = bearerToken;
		Utility::Logger("ResultTable -> SetBearerToken() -> End");
	}
}