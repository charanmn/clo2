#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <QDialog>
#include <QtCore>
#include <QtGui>
#include <QTreeWidgetItem>
#include <QTableWidgetItem>
#include "GeneratedFiles/ui_FabricsResultTable.h"
#include "CLO_PLUGIN/INFOR/Libraries/json.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
/**
 *  This file all the variable declarations and function declarations which are used in Fabrics result table
 */
using nlohmann::json; // making use of json and mapjson from nlohmann json
using namespace std;
/**
 *  CLOPlugin namespace is used to keep all the functions and attributes in this class to be under CLOPlugin namespace.
 */
namespace CLOPlugin {
	class ResultTable : public QDialog, public Ui::ResultTable
	{
		Q_OBJECT
			static string m_bearerToken;
		std::vector<Utility::MaterialFabricResults> m_FabricResults;
		json m_downloadAttachmentsMap;
		string m_attachmentsFileName;
		string m_attachmentsAttaFileListId;
	public:
		ResultTable(QWidget* parent = 0, Qt::WindowFlags flags = Qt::Dialog | Qt::FramelessWindowHint);
		~ResultTable();
		void AddRowData(Utility::MaterialFabricResults& MaterialFabricResults, QIcon FabIcon);
		void AddColoums(QTableWidgetItem* parent, Utility::MaterialFabricResults& MaterialFabricResults, QIcon FabIcon);
		void SetBearerToken(const string& bearerToken);
		void CreateDownloadAttachmentsMap(int MaterialId);
		void GetStyleAttachments(json response);
		void DownloadStyleAttachments();
	private slots:
		void DownloadClicked();
		void closeWindow();
		void OnBackClicked();
		void callCheckBoxSelected();
	};
}
