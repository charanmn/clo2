#include "TrimsResultTable.h"
#include <qmessagebox.h>
#include <qcheckbox.h>
#include <direct.h>
#include "classes/APICLODataBase.h"
#include "classes/APIStorage.h"
#include <CLOAPIInterface.h>
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
#include "TrimsSearch.h"
/**
 *  This file is used to display the trims results on the result table
	 It allows the user to download the trims
 */
using namespace std;
/**
 *  CLOPlugin namespace is used to keep all the functions in this class to be under CLOPlugin namespace.
 */
namespace CLOPlugin {
	string TrimsResultTable::m_bearerToken = " ";
	/**
	 * \brief TrimsResultTable constructor. It has Qt UI related settings to the trims result table 
		also it contains signals and slots connections
	 * \param inputs: QWidget and WindowFlags
	 **/
	 TrimsResultTable::TrimsResultTable(QWidget* parent, Qt::WindowFlags flags)
		: QDialog(parent, flags)
	{
		setupUi(this);
		setWindowTitle(tr(" Trims Result Table"));
		QString styleSheet = "::section {""color: white;""border: 1px grey;""text-align: right;""font-family: arial;""font-size: 14px; }";
		TrimtableWidget->horizontalHeader()->setStyleSheet(styleSheet);
		TrimtableWidget->verticalHeader()->setStyleSheet(styleSheet);
		TrimtableWidget->setColumnCount(11);
		TrimtableWidget->horizontalHeader()->setFixedHeight(80);
		TrimtableWidget->horizontalHeader()->setDefaultSectionSize(80);
		TrimtableWidget->verticalHeader()->setDefaultSectionSize(80);
		TrimtableWidget->resizeColumnsToContents();
		TrimtableWidget->verticalHeader()->blockSignals(true);
		TrimtableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
		QFont font;
		font.setPointSize(14);
		font.setBold(true);
		TrimtableWidget->horizontalHeader()->setFont(font);
		QStringList headerlist;
		TrimtableWidget->horizontalHeader()->setResizeMode(QHeaderView::Stretch);
		TrimtableWidget->setWordWrap(true);
		TrimtableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
		headerlist << "Select" << "Code" << "Name" << "Image" << "Trim_ID"  << "Main\nCategory" << "Category" <<"Material\nType" <<"Brand" << "Division" << "Status"  ;
		QTableWidgetItem* itemCheckbox = new QTableWidgetItem(" ");
		itemCheckbox->setCheckState(Qt::Unchecked);
		QModelIndexList selection = TrimtableWidget->selectionModel()->selectedRows();
		TrimtableWidget->setItem(0, 0, itemCheckbox);
		TrimtableWidget->setHorizontalHeaderLabels(headerlist);

		Back->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_back_over.svg"));
		Back->setIconSize(QSize(iconHieght, iconWidth));

		OK->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_down_over.svg"));
		OK->setIconSize(QSize(iconHieght, iconWidth));

		QObject::connect(OK, SIGNAL(clicked()), this, SLOT(DownloadClicked()));
		QObject::connect(Back, SIGNAL(clicked()), this, SLOT(OnBackClicked()));
		QObject::connect(toolButton, SIGNAL(clicked()), this, SLOT(closeWindow()));
	}
/**
	 * \brief  destructortor of TrimsResultTable
	 deletes the object of this class.
 */
	TrimsResultTable::~TrimsResultTable()
	{
	}
	/**
	 * \brief adds rows to the Trims Result Table
	 * \input param structure of Trims Results and QIcon
	 * \return void
	 */
	void TrimsResultTable::AddRowData(Utility::TrimResults& trimsResults, QIcon fabIcon)
	{
		QTableWidgetItem* headerItem = new QTableWidgetItem();
		AddColoums(headerItem, trimsResults, fabIcon);
		m_trimsResults.push_back(trimsResults);
	}
	/**
	 * \brief adds columns to the Trims Result Table
	 * \input param:  QTableWidget Item, structure of Trims Results and QIcon
	 * \return void
	 */
	void TrimsResultTable::AddColoums(QTableWidgetItem* parent, Utility::TrimResults& TrimResults, QIcon FabIcon)
	{
		int currentRow = TrimtableWidget->rowCount();
		TrimtableWidget->setWordWrap(true);
		TrimtableWidget->setRowCount(currentRow + 1);
		for (int c = 0; c < TrimtableWidget->columnCount(); ++c)
		{
			QTableWidgetItem* dataItem = new QTableWidgetItem;
			dataItem->setFlags(dataItem->flags() | Qt::ItemIsUserCheckable);
			dataItem->setCheckState(Qt::Unchecked);
			//QCheckBox* radioButton = new QCheckBox;
			//radioButton->setCheckable(true);
			//radioButton->setStyleSheet("margin-left:50%; margin-right:50%;");
			////TrimtableWidget->setCellWidget(currentRow, 0, radioButton);
			//TrimtableWidget->setStyleSheet("QTableWidget::indicator:unchecked {background-color:white;}");
			QTableWidgetItem* itemImage = new QTableWidgetItem;
			TrimtableWidget->setIconSize(QSize(80, 80));
			itemImage->setSizeHint(QSize(80, 80));
			itemImage->setIcon(FabIcon);
			QTableWidgetItem* itemCode = new QTableWidgetItem(TrimResults.trimCode);
			itemCode->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemName = new QTableWidgetItem(TrimResults.trimName);
			itemName->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemFabID = new QTableWidgetItem(TrimResults.trimId);
			itemFabID->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemType = new QTableWidgetItem(TrimResults.trimType);
			itemType->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemBrand = new QTableWidgetItem(TrimResults.trimBrand);
			itemBrand->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemDivision = new QTableWidgetItem(TrimResults.trimDivision);
			itemDivision->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemStatus = new QTableWidgetItem(TrimResults.trimStatus);
			itemStatus->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemDescription = new QTableWidgetItem(TrimResults.trimDescription);
			itemDescription->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemMainCat = new QTableWidgetItem(TrimResults.trimMainCategory);
			itemMainCat->setTextAlignment(Qt::AlignCenter);
			QTableWidgetItem* itemCat = new QTableWidgetItem(TrimResults.trimCategory);
			itemCat->setTextAlignment(Qt::AlignCenter);
			QCheckBox* selectItem = new QCheckBox;
			selectItem->setCheckState(Qt::Unchecked);
			selectItem->setStyleSheet("margin-left:35%; margin-right:65%;");
			TrimtableWidget->setStyleSheet("QTableWidget::indicator:unchecked {background-color:white;}");
			TrimtableWidget->setCellWidget(currentRow, 0, selectItem);
			TrimtableWidget->setItem(currentRow, 1, itemCode);
			TrimtableWidget->setItem(currentRow, 2, itemName); 
			TrimtableWidget->setItem(currentRow, 3, itemImage);
			TrimtableWidget->setItem(currentRow, 4, itemFabID);
			TrimtableWidget->setItem(currentRow, 5, itemMainCat);
			TrimtableWidget->setItem(currentRow, 6, itemCat);
			TrimtableWidget->setItem(currentRow, 7, itemType);
			TrimtableWidget->setItem(currentRow, 8, itemBrand);
			TrimtableWidget->setItem(currentRow, 9, itemDivision);
			TrimtableWidget->setItem(currentRow, 10, itemStatus);
			QObject::connect(selectItem, SIGNAL(clicked()), this, SLOT(callCheckBoxSelected()));
		}
	}
	/**
	 * \brief calls the check box which is selected in the result table
	 * \input param:  void
	 * \return void
	 */
	void  TrimsResultTable::callCheckBoxSelected()
	{
		int totalRowCount = TrimtableWidget->rowCount();
		TrimtableWidget->setSelectionMode(QAbstractItemView::MultiSelection);
		QStringList selectedRows;
		selectedRows.clear();
		for (int rowCount = 0; rowCount < totalRowCount; rowCount++)
		{
			QWidget* qWidget = TrimtableWidget->cellWidget(rowCount, 0);
			QCheckBox* tempCheckBox = qobject_cast<QCheckBox*>(qWidget);
			if (tempCheckBox->checkState() == Qt::Checked)
			{
				selectedRows << QString::fromStdString(to_string(rowCount));
			}
		}
		TrimtableWidget->clearSelection();
		for (auto iterate : selectedRows)
		{
			TrimtableWidget->selectRow(iterate.toInt());
		}
		selectedRows.clear();
	}
	/**
	 * \brief After clicking on download button, selected trims will be displyed on the side pane
	 * \input param:  void
	 * \return void
	 */
	void  TrimsResultTable::DownloadClicked()
	{
		int rowCount = TrimtableWidget->rowCount();
		int columnCount = TrimtableWidget->columnCount();
		QString qstrTrimID;
		QString qstrTrimName;
		QString qstrTrimCode;
		QString brand;
		QString imageLoadPath;
		QString imageSavePath;
		QString imageFileName;
		const char* newDirPath = TRIMS_ASSETS_DIRECTORY.c_str();
		mkdir(newDirPath);
		bool isSelected = false;
		for (int row = 0; row < rowCount; row++)
		{
			QWidget* qWidget = TrimtableWidget->cellWidget(row, 0); 
			QCheckBox* tempCheckBox = qobject_cast<QCheckBox*>(qWidget);
			if (tempCheckBox->checkState() == Qt::Checked)
			{
				isSelected = true;
			}
		}
		if (isSelected == false)
		{
			UTILITY_API->DisplayMessageBox("Select atleast one row to download");
		}
		else
		{
			this->hide();
			QImage imgNew;
			QString imageLoadPath, imageSavePath, code;
			for (int row = 0; row < rowCount; row++)
			{

				QWidget* qWidget = TrimtableWidget->cellWidget(row, 0);
				QCheckBox* tempCheckBox = qobject_cast<QCheckBox*>(qWidget);
				if (tempCheckBox->checkState() == Qt::Checked)
				{
					QImage imgNew;
					qstrTrimID = TrimtableWidget->item(row, 4)->text();
					qstrTrimName = TrimtableWidget->item(row, 2)->text();
					qstrTrimCode = TrimtableWidget->item(row, 1)->text();
					int matchingindex = 0;
					for (int i = 0; i < m_trimsResults.size(); i++)
					{
						if (qstrTrimID == m_trimsResults[i].trimId)
						{
							matchingindex = i;
							break;
						}
					}
					QString imageLoadPath, imageSavePath, code;
					CLOAPISample::LibraryAPIItem* setItem = new CLOAPISample::LibraryAPIItem();
					setItem->itemID = qstrTrimCode;
					setItem->itemName = qstrTrimCode + ".png";
					imageLoadPath = QString::fromStdString(TRIMS_TEMP_DIRECTORY) + qstrTrimCode + ".png";
					imageSavePath = QString::fromStdString(TRIMS_ASSETS_DIRECTORY) + qstrTrimCode + ".png";
					imgNew.load(imageLoadPath);
					imgNew.save(imageSavePath);
					setItem->sampleItemData.itemPath = qstrTrimCode + ".png";
					setItem->sampleItemData.iconThumbnailPath = qstrTrimCode + ".png";
					setItem->sampleItemData.previewThumbnailPath = qstrTrimCode + ".png";
					setItem->dateTime = "2019-08-20T16:21:41";
					setItem->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("TRIM");
					setItem->metaData[META_DATA_KEY_2_BRAND] = m_trimsResults[matchingindex].trimBrand;
					setItem->metaData[META_DATA_KEY_12_TRIM_ID] = m_trimsResults[matchingindex].trimId;
					setItem->metaData[META_DATA_KEY_11_TRIM_NAME] = m_trimsResults[matchingindex].trimName;
					setItem->metaData[META_DATA_KEY_13_TRIM_NUMBER] = qstrTrimCode;
					bool alreadyExists = false;
					if (API_STORAGE)
					{
						for (int i = 0; i < API_STORAGE->m_LibraryAPIItemList.size(); i++)
						{
							if (API_STORAGE->m_LibraryAPIItemList[i]->metaData[META_DATA_KEY_13_TRIM_NUMBER] == qstrTrimCode)
							{
								alreadyExists = true;
								break;
							}
						}
						if (!alreadyExists)
						{
							API_STORAGE->m_LibraryAPIItemList.push_back(setItem);
						}
					}
				}
			}
			wstring wideString = wstring(TRIMS_TEMP_DIRECTORY.begin(), TRIMS_TEMP_DIRECTORY.end());
			Utility::RemoveDirectory(wideString.c_str());
			UTILITY_API->DisplayMessageBox("Download completed");
		}
	}
/**
	 * \brief On click of BACK button in the result table , it will navigate to the trims search page
	 * \input param:  void
	 * \return void
	 */	
	void TrimsResultTable::OnBackClicked()
	{
		this->close();
		TrimsSearch::GetInstance()->setModal(true);
		TrimsSearch::GetInstance()->show();
	}
	/**
	 * \brief On click of Close button in the result table , it will close the result table window.
	 * \input param:  void
	 * \return void
	 */
	void TrimsResultTable::closeWindow()
	{
		this->close();
	}
		/**
	 * \brief This function sets the bearerToken
	 * \input param:  string of bearer Token
	 * \return void
	 */
	void TrimsResultTable::SetBearerToken(const string& bearerToken)
	{
		m_bearerToken = bearerToken;
	}
}