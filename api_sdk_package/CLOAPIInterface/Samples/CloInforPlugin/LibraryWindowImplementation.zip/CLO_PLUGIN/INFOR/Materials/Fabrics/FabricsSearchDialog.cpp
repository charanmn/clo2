#pragma once
#include "FabricsSearchDialog.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QLabel>
#include <QMessageBox>
#include <QCheckBox>
#include <any>
#include <optional>
#include "qlistview.h"
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
#include "CLO_PLUGIN/INFOR/Libraries/json.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
#include "CLO_PLUGIN/INFOR/Utilities/ComboBoxItem.h"
#include "CLO_PLUGIN/INFOR/DesignSuite/DesignSuite.h"
#include "FabricsResultTable.h"	
#pragma comment(lib, "libcurl.lib")
#pragma comment(lib, "wldap32.lib")
#pragma comment(lib, "ws2_32.lib")
#include "CLO_PLUGIN/INFOR/Libraries/curl/include/curl/curl.h"
#include <iostream>
#include <direct.h>
using json = nlohmann::json;

using namespace std;

using mapjson = nlohmann::json;
bool matImageAtt= false;
bool matZfabAtt = false;

namespace CLOPlugin
{
	MaterialSearchDialog* MaterialSearchDialog::_instance = NULL;

	string MaterialSearchDialog::m_bearerToken = " ";

	/**
	 * \brief Responsible for setting bearer token to member variable for Rest calls
	 * \param bearerToken 
	 */
	void MaterialSearchDialog::SetBearerToken(const string& bearerToken)
	{
		Utility::Logger("MaterialSearchDialog -> SetBearerToken() -> Start");
		m_bearerToken = bearerToken;
		Utility::Logger("MaterialSearchDialog -> SetBearerToken() -> end");
	}
	/**
	 * \brief Instantiate MaterialSearchDialog object
	 * \return 
	 */
	MaterialSearchDialog* MaterialSearchDialog::GetInstance()
	{
		Utility::Logger("MaterialSearchDialog -> GetInstance() -> Start");
		if (_instance == NULL)
		{
			_instance = new MaterialSearchDialog();
		}
		Utility::Logger("MaterialSearchDialog -> GetInstance() -> end");
		
		return _instance;
	}
	/**
	 * \brief Destroys instantiated MaterialSearchDialog object
	 */
	void MaterialSearchDialog::Destroy()
	{
		Utility::Logger("MaterialSearchDialog -> Destroy() -> Start");
		if (_instance)
		{
			delete _instance;
			_instance = NULL;
		}
		Utility::Logger("MaterialSearchDialog -> Destroy() -> Start");
	}
	/**
	 * \brief Clears all UI fields of QT Widget of Material Search page
	 */
	void MaterialSearchDialog::ClearAllFields()
	{
		Utility::Logger("MaterialSearchDialog -> ClearAllFields() -> Start");

		m_signalOrigin = 0;
		for (int i = 0; i < MaterialSearchTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = MaterialSearchTree->topLevelItem(i);
			QWidget* qWidgetColumn0 = MaterialSearchTree->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = MaterialSearchTree->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string lable = qlabel->text().toStdString();
			QLineEdit* qlineedit = qobject_cast<QLineEdit*>(qWidgetColumn1);

			if (qlineedit)
			{
				qlineedit->setText("");
			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
				if (qComboBox)
				{
					int indexOfEmptyString = qComboBox->findText("");
					qComboBox->setCurrentIndex(indexOfEmptyString);
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
					if (qtextEdit)
					{
						qtextEdit->setText("");
					}
				}
			}
		}
		Utility::Logger("MaterialSearchDialog -> ClearAllFields() -> end");
	}
	MaterialSearchDialog::MaterialSearchDialog(QWidget* parent) : QDialog(parent)
	{
		Utility::Logger("MaterialSearchDialog -> Constructor() -> Start");
		
		setupUi(this);
		QTreeWidgetItem* dataItem = new QTreeWidgetItem;
		
		Qt::ItemFlags flags;
		flags = dataItem->flags();
		flags |= Qt::ItemIsSelectable | Qt::ItemIsEditable | Qt::ItemIsEnabled;
		dataItem->setFlags(flags);
		QFont fontStyle("Times new roman", 16, QFont::Bold);
		this->setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint | Qt::CustomizeWindowHint);
		
		QSize size(425, 500);
		MaterialSearchTree->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		MaterialSearchTree->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		MaterialSearchTree->setFocusPolicy(Qt::FocusPolicy::StrongFocus);
		MaterialSearchTree->setSelectionBehavior(QAbstractItemView::SelectRows);
		MaterialSearchTree->setSelectionBehavior(QAbstractItemView::SelectItems);
		MaterialSearchTree->setTabKeyNavigation(true);
		MaterialSearchTree->setStyleSheet("QTreeWidget::item { border-bottom: 1px solid #232323;""padding : 10px;""height: 25px;""}");
		MaterialSearchTree->setFixedSize(size);
		MaterialSearchTree->setColumnWidth(1, 210);
		MaterialSearchTree->setColumnWidth(0, 195);

		m_signalOrigin = 0;
		m_currentBrandIndex = 0;
		m_currentDivisionIndex = 0;

		label_ps->setFont(fontStyle);
		layout()->setSizeConstraint(QLayout::SetFixedSize);
		this->adjustSize();

		back->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_back_over.svg"));
		back->setIconSize(QSize(iconHieght, iconWidth));

		search->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_search_over.svg"));
		search->setIconSize(QSize(iconHieght, iconWidth));

		QObject::connect(search, SIGNAL(clicked()), this, SLOT(Search_clicked()));
		QObject::connect(back, SIGNAL(clicked()), this, SLOT(back_clicked()));
		QObject::connect(closeWindow, SIGNAL(clicked()), this, SLOT(Cancle_clicked()));
		m_isUserInputEmpty = true;
				
		ReadPLMJson();
		ReadJsonAndDrawDialog();
		
		Utility::Logger("MaterialSearchDialog -> Constructor() -> end");
	}
	/**
	 * \brief Reads JSON for all UI fields and draws
	 */
	void MaterialSearchDialog::ReadJsonAndDrawDialog()
	{
		Utility::Logger("MaterialSearchDialog -> ReadJsonAndDrawDialog() -> Start");

		json jsonString;
		Utility::Fields tempField;
		ifstream filename;
		filename.open("C:\\MiddlewareFiles\\materialSearchFiltered.json");
		filename >> jsonString;
		filename.close();
		string completeJsonString, uiTypeJSONObject, presetListJSONObject, fieldValues;
		completeJsonString = jsonString.dump();
		json completeJson = json::parse(completeJsonString);
		uiTypeJSONObject = completeJson["uiTypeList"].dump();
		json componentsJson = json::parse(uiTypeJSONObject);
		presetListJSONObject = completeJson["presetList"].dump();
		json presetListJSON = json::parse(presetListJSONObject);
		fieldValues = completeJson["fieldList"].dump();
		json fieldValuesJson = json::parse(fieldValues);

		for (int i = 0; i < fieldValuesJson.size(); i++)
		{
			string fieldValuesString = fieldValuesJson[i].dump();
			fieldValuesString = fieldValuesString.erase(0, 1);
			fieldValuesString = fieldValuesString.erase(fieldValuesString.size() - 1);
			tempField.labelValue = QString::fromStdString(fieldValuesString);
			string uiTypes = componentsJson[fieldValuesString].dump();
			uiTypes = uiTypes.erase(0, 1);
			uiTypes = uiTypes.erase(uiTypes.size() - 1);
			tempField.fieldUItype = QString::fromStdString(uiTypes);
			if (tempField.fieldUItype == "dropdown")
			{
				string presetList = presetListJSON[fieldValuesString].dump();
				presetList = presetList.erase(0, 1);
				presetList = presetList.erase(presetList.size() - 1);
				presetList.erase(std::remove(presetList.begin(), presetList.end(), '\"'), presetList.end());
				QStringList listQt;
				listQt = QString::fromStdString(presetList).split(",");
				tempField.presetValues = listQt;
			}
			m_materialsFieldsVector.push_back(tempField);
		}
		DrawWidget(m_materialsFieldsVector);
		
		Utility::Logger("MaterialSearchDialog -> ReadJsonAndDrawDialog() -> End");
	}
	/**
	 * \brief Draws UI widget using all read fields
	 * \param fieldsVector 
	 */
	void MaterialSearchDialog::DrawWidget(std::vector<Utility::Fields>& fieldsVector)
	{
		Utility::Logger("MaterialSearchDialog -> DrawWidget() -> Start");
		for each(auto field in fieldsVector)
		{
			if (field.fieldUItype == "text")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();  // Creating new TreeWidgetItem
				QLineEdit* lineEdit = new QLineEdit();						// Creating new LineEdit Widget
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
			
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{					
					if (isupper(tempLabel[capsCount]))
					{					
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount+1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				lineEdit->setStyleSheet(inputStyle);
				MaterialSearchTree->addTopLevelItem(topLevel);						// Adding ToplevelItem
				MaterialSearchTree->setItemWidget(topLevel, 0, label);				// Adding label at column 1
				MaterialSearchTree->setItemWidget(topLevel, 1, lineEdit);
			}

			if (field.fieldUItype == "dropdown")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QComboBox* comboBox = new QComboBox(this);
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));// Setting created font style to label
				comboBox->setStyleSheet(inputStyle);
				
				MaterialSearchTree->addTopLevelItem(topLevel);
				MaterialSearchTree->setItemWidget(topLevel, 0, label);
				MaterialSearchTree->setItemWidget(topLevel, 1, comboBox);

				comboBox->setStyleSheet("font: 75 8pt \"Tahoma\"; combobox-popup:0");
				
				if (field.labelValue == "Brand")
				{
					QObject::connect(comboBox, SIGNAL(currentIndexChanged(const QString&)), this,
						SLOT(brandValueChanged(const QString&)));
				}
				if (field.labelValue == "Division")
				{
					QObject::connect(comboBox, SIGNAL(currentIndexChanged(const QString&)), this,
						SLOT(divisionValueChanged(const QString&)));
				}
				
				comboBox->addItems(field.presetValues);
				int indexOfEmptyString = comboBox->findText("");
				comboBox->setCurrentIndex(indexOfEmptyString);
				
			}

			if (field.fieldUItype == "textarea")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();  // Creating new TreeWidgetItem
				QTextEdit* textEdit = new QTextEdit();						// Creating new LineEdit Widget
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
	
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				
				MaterialSearchTree->addTopLevelItem(topLevel);						// Adding ToplevelItem
				MaterialSearchTree->setItemWidget(topLevel, 0, label);				// Adding label at column 1
				MaterialSearchTree->setItemWidget(topLevel, 1, textEdit);
				textEdit->setText(field.userInputValues);
				textEdit->setStyleSheet("border: 1px solid black;"
					"background-color: #222222;"
					"font: 75 8pt \"Tahoma\";"
				);
				textEdit->setMaximumSize(190, 80);
			}

			if (field.fieldUItype == "DateEdit")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QDateEdit* dateTimeEdit = new QDateEdit();
				bool enable = true;
				dateTimeEdit->setCalendarPopup(enable);			// Setting Popup Calendar for Date time picker.
				QString dataricovero("");
				QDate date = QDate::fromString(dataricovero, "");
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string temLable = field.labelValue.toStdString();
				
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < temLable.length(); capsCount++)
				{
					if (isupper(temLable[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							temLable = temLable.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(temLable));
				dateTimeEdit->setStyleSheet(inputStyle);
				
				MaterialSearchTree->addTopLevelItem(topLevel);
				MaterialSearchTree->setItemWidget(topLevel, 0, label);
				MaterialSearchTree->setItemWidget(topLevel, 1, dateTimeEdit);
				
			}
		}
		Utility::Logger("MaterialSearchDialog -> DrawWidget() -> End");
	}
	MaterialSearchDialog::~MaterialSearchDialog()
	{
		Utility::Logger("MaterialSearchDialog -> readPLMJson() -> Start");
	}
	/**
	 * \brief Responsible for extracting all user selected values of Material Search form
	 * \return 
	 */
	bool MaterialSearchDialog::ExtractAllUIValues()
	{
		Utility::Logger("MaterialSearchDialog -> readPLMJson() -> Start");

		for (int i = 0; i < MaterialSearchTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem *topItem = MaterialSearchTree->topLevelItem(i);
			QWidget *qWidgetColumn0 = MaterialSearchTree->itemWidget(topItem, 0);
			QWidget * qWidgetColumn1 = MaterialSearchTree->itemWidget(topItem, 1);
			QLabel *qlabel = qobject_cast<QLabel *>(qWidgetColumn0);
			string lable = qlabel->text().toStdString();
			QLineEdit *qlineedit = qobject_cast<QLineEdit *>(qWidgetColumn1);

			if (qlineedit)
			{
				m_materialsFieldsVector[i].userInputValues = qlineedit->text();
				if (!qlineedit->text().isEmpty())
				{
					m_isUserInputEmpty = false;
				}
			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
				if (qComboBox)
				{
					m_materialsFieldsVector[i].userInputValues = qComboBox->currentText();
					if (!qComboBox->currentText().isEmpty())
					{
						m_isUserInputEmpty = false;
					}
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
					if (qtextEdit)
					{
						m_materialsFieldsVector[i].userInputValues = qtextEdit->toPlainText();
						if (!qtextEdit->toPlainText().isEmpty())
						{
							m_isUserInputEmpty = false;
						}
					}
				}
			}
		}
		if (m_isUserInputEmpty)
		{
			UTILITY_API->DisplayMessageBox("Please enter atleast one field to search Materials.");
			Utility::Logger("MaterialSearchDialog -> readPLMJson() -> end");
			return false;
		}
		Utility::Logger("MaterialSearchDialog -> readPLMJson() -> end");
		return true;
	}
	/**
	 * \brief Using extracted values of User selected values, creates Map of Field and values
	 */
	void MaterialSearchDialog::CreateSearchMap()
	{
		Utility::Logger("MaterialSearchDialog -> CreateSearchMap() -> Start");
		json emptyJsonObject;
		json mapArray;
		json pagInfoMap;
		json filterMap;
		json conditions = json::object();

		pagInfoMap["Page"] = 1;
		pagInfoMap["PageSize"] = 40;
		pagInfoMap["pageCount"] = 1;
		pagInfoMap["totalCount"] = 8;

		m_materialSearchMap["roleId"] = 1;
		m_materialSearchMap["userId"] = 71;
		m_materialSearchMap["entity"] = "Material";
		m_materialSearchMap["Schema"] = "FSH5";
		m_materialSearchMap["fromAi"] = true;
		m_materialSearchMap["pageType"] = "list";
		m_materialSearchMap["sortInfo"] = emptyJsonObject;
		m_materialSearchMap["PageInfo"] = pagInfoMap;

		int count = 0;
		for (auto array_element : m_materialsFieldsVector)
		{
			string attLabel = array_element.labelValue.toStdString();
			string userSelected = array_element.userInputValues.toStdString();
			if (userSelected != "")
			{
				if (array_element.fieldUItype == "dropdown")
				{
					for (auto it = m_attributeMap.begin(); it != m_attributeMap.end(); it++)
					{
						if (it->first == attLabel)
						{
							mapArray["fieldName"] = it->second;
							map<string, string> attNameIdMap;
							attNameIdMap.clear();
							attNameIdMap.insert(m_attsDropdownListMap[attLabel].begin(), m_attsDropdownListMap[attLabel].end());
							for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
							{
								if (it->first == userSelected)
								{
									mapArray["operator"] = "=";
									mapArray["value"] = stoi(it->second);
									break;
								}
							}
							break;
						}
					}
					conditions["Conditions"][count++] = mapArray;
				}
				else if (attLabel == "MaterialCode")
				{
					filterMap.clear();
					filterMap["fieldName"] = attLabel;
					filterMap["operator"] = "like";
					filterMap["value"] = userSelected;
					conditions["Conditions"][count++] = filterMap;
				}
				else if (attLabel == "MaterialName")
				{
					filterMap.clear();
					filterMap["fieldName"] = attLabel;
					filterMap["operator"] = "like";
					filterMap["value"] = userSelected;
					conditions["Conditions"][count++] = filterMap;
				}
				else
				{
					filterMap.clear();
					filterMap["fieldName"] = attLabel;
					filterMap["operator"] = "=";
					filterMap["value"] = userSelected;
					conditions["Conditions"][count++] = filterMap;
				}
			}
		}
		conditions["Search"] = nullptr;

		m_materialSearchMap["dataFilter"] = conditions;
		Utility::Logger("MaterialSearchDialog -> CreateSearchMap() -> Start");
	}
	/**
	 * \brief USing fields and value map, Searches for Objects in PLM
	 */
	void MaterialSearchDialog::PLMSearch()
	{
		Utility::Logger("MaterialSearchDialog -> PLMSearch() -> Start");
		
		string parameter = to_string(m_materialSearchMap);
		vector<pair<string, string>> headerNameAndValueList;

		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", m_bearerToken));
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/adobe/api/view/layout/data/get", &parameter, headerNameAndValueList, "HTTP Post");
		json responseJson;
		string errorResponse = Utility::CheckErrorDescription(response);
	
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			

			int indexForContent = response.find("Content-Type:");
			string contentString = response.substr(indexForContent);
			int indexForJSON = contentString.find("{");

			string strForJSON = contentString.substr(indexForJSON);
			std::replace(strForJSON.begin(), strForJSON.end(), '�', ' ');

			try
			{
				responseJson = json::parse(strForJSON);
			}
			catch (json::exception & err)
			{
				// output exception information
				Utility::Logger( "message: " + QString(err.what()).toStdString() +
					+ "exception id: " + to_string(err.id) );
			}
			CreateResultTable(responseJson);
		}
		else
		{
			UTILITY_API->DisplayMessageBox(errorResponse);
		}
		Utility::Logger("MaterialSearchDialog -> PLMSearch() -> end");
	}
	/**
	 * \brief Recordes Clock of Search by user and send request for Search operation
	 */
	void MaterialSearchDialog::Search_clicked()
	{
		Utility::Logger("MaterialSearchDialog -> Search_clicked() -> Start");
		if (ExtractAllUIValues())
		{
			this->hide();
			CreateSearchMap();
			PLMSearch();
			m_isUserInputEmpty = true;
		}
		Utility::Logger("MaterialSearchDialog -> Search_clicked() -> end");
	}
	/**
	 * \brief Using results from PLM, create Results table and diaplays
	 * \param responseJson 
	 */
	void MaterialSearchDialog::CreateResultTable(json& responseJson)
	{
		Utility::Logger("MaterialSearchDialog -> createResultTable() -> Start");
		
		const char* newDirPath = MATERIALS_TEMP_DIRECTORY.c_str();
		mkdir(newDirPath);

		string entities = responseJson["entities"].dump();
		json completeEntitiesJson = json::parse(entities);
		ResultTable materialsResultTable;
		materialsResultTable.SetBearerToken(m_bearerToken);
		bool isImage = false;
		bool isZfab = false;
		if (completeEntitiesJson.size() != 0)
		{
			int rowCount = 0;
			Utility::MaterialFabricResults tempFabricResults;
			for (int i = 0; i < completeEntitiesJson.size(); i++)
			{
				string entityJson = completeEntitiesJson[i].dump();
				json material = json::parse(entityJson);

				string name = material["name"].dump();
				name = name.erase(0, 1);
				name = name.erase(name.size() - 1);
				string column, materialId, materialName, materialCode, 
					thumbnail, materialAttach, filenameToSave, brandValue, brandId, statusValue;
				string statusId, typeId, typeValue, divisionValue, divisionId, 
					genderId, genderValue, userValue, userId, seasonValue, seasonId, categoryId, 
					categoryValue,categoryGroupId, categoryGroupValue,mainCategoryId, mainCategoryValue;

				if (name == "Material")
				{
					rowCount = rowCount + 1;
					column = material["column"].dump();
					json columns = json::parse(column);
					
					materialId = columns["MaterialId"].dump();

					materialName = columns["MaterialName"].dump();
					if (materialName != "null")
					{
						materialName = materialName.erase(0, 1);
						materialName = materialName.erase(materialName.size() - 1);
					}
					else
					{
						materialName = "";
					}

					materialCode = columns["MaterialCode"].dump();
					materialCode = materialCode.erase(0, 1);
					materialCode = materialCode.erase(materialCode.size() - 1);

					brandValue = columns["BrandId"].dump();
					if (brandValue != "null")
					{
						brandId = columns["BrandId_Lookup"]["Name"].dump();
						brandId = brandId.erase(0, 1);
						brandId = brandId.erase(brandId.size() - 1);
					}
					statusValue = columns["Status"].dump();
					if (statusValue != "null")
					{
						statusId = columns["Status_Lookup"]["Name"].dump();
						statusId = statusId.erase(0, 1);
						statusId = statusId.erase(statusId.size() - 1);
					}

					divisionValue = columns["DivisionId"].dump();
					if (divisionValue != "null")
					{
						divisionId = columns["DivisionId_Lookup"]["Name"].dump();
						divisionId = divisionId.erase(0, 1);
						divisionId = divisionId.erase(divisionId.size() - 1);
					}
					genderValue = columns["GenderId"].dump();
					if (genderValue != "null")
					{
						genderId = columns["GenderId_Lookup"]["Name"].dump();
						genderId = genderId.erase(0, 1);
						genderId = genderId.erase(genderId.size() - 1);
					}
					seasonValue = columns["SeasonId"].dump();
					if (seasonValue != "null")
					{
						seasonId = columns["SeasonId_Lookup"]["Name"].dump();
						seasonId = seasonId.erase(0, 1);
						seasonId = seasonId.erase(seasonId.size() - 1);
					}
					userId = columns["ModifyId"].dump();
					if (userId != "null")
					{
						userValue = columns["ModifyId_Lookup"]["Name"].dump();
						userValue = userValue.erase(0, 1);
						userValue = userValue.erase(userValue.size() - 1);
					}
					typeId =  columns["MaterialTypeId"].dump();
					if (typeId != "null")
					{
						typeValue = columns["MaterialTypeId_Lookup"]["Name"].dump();
						typeValue = typeValue.erase(0, 1);
						typeValue = typeValue.erase(typeValue.size() - 1);
					}
					categoryId = columns["CategoryId"].dump();
					if (categoryId != "null")
					{
						categoryValue = columns["CategoryId_Lookup"]["Name"].dump();
						categoryValue = categoryValue.erase(0, 1);
						categoryValue = categoryValue.erase(categoryValue.size() - 1);
					}
					categoryGroupId = columns["CategoryGroupId"].dump();
					if (categoryGroupId != "null")
					{
						categoryGroupValue = columns["CategoryGroupId_Lookup"]["Name"].dump();
						categoryGroupValue = categoryGroupValue.erase(0, 1);
						categoryGroupValue = categoryGroupValue.erase(categoryGroupValue.size() - 1);
					}
					mainCategoryId = columns["MainCategoryId"].dump();
					if (mainCategoryId != "null")
					{
						mainCategoryValue = columns["MainCategoryId_Lookup"]["Name"].dump();
						mainCategoryValue = mainCategoryValue.erase(0, 1);
						mainCategoryValue = mainCategoryValue.erase(mainCategoryValue.size() - 1);
					}
					QPixmap pixmap;
					matImageAtt = false;
					thumbnail = columns["Image"].dump();
					
					if (thumbnail != "null")
					{
						thumbnail = thumbnail.erase(0, 1);
						thumbnail = thumbnail.erase(thumbnail.size() - 1);

						filenameToSave = materialCode + ".png";
						//UTILITY_API->DisplayMessageBox("thumbnail ::" + thumbnail);
						Utility::DownloadImageFromURL(thumbnail, MATERIALS_TEMP_DIRECTORY + filenameToSave);
						matImageAtt = true;
						
						QImage img;
						QImage styleIcon;

						styleIcon.load(QString::fromStdString(MATERIALS_TEMP_DIRECTORY + filenameToSave));
						pixmap = QPixmap::fromImage(styleIcon);
					}
					DownloadAtachment(materialId, materialCode);

					tempFabricResults.fabricCode = QString::fromStdString(materialCode);
					tempFabricResults.fabricName = QString::fromStdString(materialName);
					tempFabricResults.fabricId = QString::fromStdString(materialId);
					tempFabricResults.fabricType = QString::fromStdString(typeValue);
					tempFabricResults.fabricBrand = QString::fromStdString(brandId);
					tempFabricResults.fabricDivision = QString::fromStdString(divisionId);
					tempFabricResults.fabricStatus = QString::fromStdString(statusId);
					tempFabricResults.fabricSeason = QString::fromStdString(seasonId);
					tempFabricResults.fabricUser = QString::fromStdString(userValue);
					tempFabricResults.fabricCategory = QString::fromStdString(categoryValue);
					tempFabricResults.fabricCategoryGroup = QString::fromStdString(categoryGroupValue);
					tempFabricResults.fabricMainCategory = QString::fromStdString(mainCategoryValue);
					tempFabricResults.fabricAtachment = matZfabAtt;
					tempFabricResults.fabricImage = matImageAtt;
					if (matImageAtt|| matZfabAtt)
					{
						isImage = matImageAtt;
						isZfab = matZfabAtt;
						materialsResultTable.AddRowData(tempFabricResults, pixmap);
						matZfabAtt = false;
						matImageAtt = false;
					}
				}
			}
			if(((isImage) || (isZfab)) )
			{
				materialsResultTable.setModal(true);
				materialsResultTable.exec();
			}
			else if (rowCount > 0)
			{
				UTILITY_API->DisplayMessageBox("This record does not have an image or zfab");
				this->show();
			}
		}
		else
		{
			UTILITY_API->DisplayMessageBox("No Result Found");
			this->show();
		}
		Utility::Logger("MaterialSearchDialog -> createResultTable() -> end");
	}
	/**
	 * \brief Recordes Clock of Back button by user and stops sending request further.
	 */
	void MaterialSearchDialog::back_clicked()
	{
		Utility::Logger("MaterialSearchDialog -> BackClicked() -> Start");
		m_signalOrigin = 0;
		this->hide();
		DesignSuite::GetInstance()->setModal(true);
		DesignSuite::GetInstance()->show();
		Utility::Logger("MaterialSearchDialog -> BackClicked() -> end");
	}
	/**
	 * \brief Recordes Clock of Cancel button by user and terminates search action.
	 */
	void MaterialSearchDialog::Cancle_clicked()
	{
		Utility::Logger("MaterialSearchDialog -> CancelClicked() -> Start");
		m_signalOrigin = 0;
		this->close();
		Utility::Logger("MaterialSearchDialog -> CancelClicked() -> end");
	}
	/**
	 * \brief Reads PLM sent JSON for values
	 */
	void  MaterialSearchDialog::ReadPLMJson() 
	{
		Utility::Logger("MaterialSearchDialog -> ReadPLMJson() -> Start");
		
		ofstream materialDetailsFile;
		materialDetailsFile.open("C:\\MiddlewareFiles\\materialDetails.json");
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", DesignSuite::GetInstance()->GetBearerToken()));
		
		string parameter = "{\"roleId\":1,\"userId\":72,\"entity\":\"Material\",\"pageType\":\"details\",\"dataFilter\":{\"conditions\":[{\"fieldname\":\"MaterialId\",\"operator\":\"=\",\"value\":\"\"}]},\"pageInfo\":{},\"Schema\":\"FSH5\"}";
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/adobe/api/view/layout/data/get", &parameter, headerNameAndValueList, "HTTP Post");
		string errorResponse = Utility::CheckErrorDescription(response);
		
		string completeDocLibs;
		json docLibjson;
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			size_t found = response.find("200");
			
			if (found != string::npos && response.find("OK"))
			{
				int indexforFlowerBrace = response.find("{");
				completeDocLibs = response.substr(indexforFlowerBrace);
				std::replace(completeDocLibs.begin(), completeDocLibs.end(), '�', ' ');
				
				try
				{
					docLibjson = json::parse(completeDocLibs);
				}
				catch (json::exception & err)
				{
					// output exception information
					Utility::Logger( "message: " + QString(err.what()).toStdString() +
						+ "exception id: " + to_string(err.id) );
				}
			}
		
		}
		materialDetailsFile << docLibjson;
		materialDetailsFile.close();
		
		json completeStyleJson;
		m_attsDropdownListMap.clear();
		m_attributeMap.clear();
		ifstream file;
		file.open("C:\\MiddlewareFiles\\materialDetails.json");
	
		file >> completeStyleJson;
		file.close();
		
		ofstream materialSearchFile;
		materialSearchFile.open("C:\\MiddlewareFiles\\materialSearchFiltered.json");
		json finalJsontoSave;
		auto jsonFieldList = json::array();
		auto jsonUiTypeList = json::object();
		auto presetArray = json::array();
		auto presetList = json::object();
		
		auto jsonMandatoryFieldsList = json::array();
		int uiPresetCount = 0;
		string completeStyleJsonString, componentsString, compObjString;
		completeStyleJsonString = completeStyleJson.dump();
		json completeJson = json::parse(completeStyleJsonString);
		
		componentsString = completeJson["layout"]["components"].dump();
		json componentsJson = json::parse(componentsString);
		
		for (int i = 0; i < componentsJson.size(); i++) {
			compObjString = componentsJson[i].dump();
			json compObjJson = json::parse(compObjString);
			string propsString = compObjJson["props"].dump();
			json  propsJson = json::parse(propsString);
			string visible = propsJson["isVisibleAi"].dump();
			if (visible == "true")
			{
				string isRequired = propsJson["isRequired"].dump();
				
				string fieldType = compObjJson["fieldType"].dump();
				fieldType = fieldType.erase(0, 1);
				fieldType = fieldType.erase(fieldType.size() - 1);
				string lookupRef = compObjJson["lookupRef"].dump();
				lookupRef = lookupRef.erase(0, 1);
				lookupRef = lookupRef.erase(lookupRef.size() - 1);

				string dataField = compObjJson["dataField"].dump();
				dataField = dataField.erase(0, 1);
				dataField = dataField.erase(dataField.size() - 1);

				if (lookupRef == "ul")
				{
					m_attributeMap.insert(std::make_pair(dataField, dataField));
					jsonUiTypeList[dataField] = fieldType;
					
					jsonFieldList.push_back(dataField);
					if (isRequired == "true")
					{
						jsonMandatoryFieldsList.push_back(dataField);
					}
				}
				else
				{
					m_attributeMap.insert(std::make_pair(lookupRef, dataField));
					jsonUiTypeList[lookupRef] = fieldType;
					
					jsonFieldList.push_back(lookupRef);
					if (isRequired == "true")
					{
						jsonMandatoryFieldsList.push_back(lookupRef);
					}
				}
				if (fieldType == "dropdown")
				{
					string lookups = completeJson["lookups"].dump();
					json lookupsJSON = json::parse(lookups);
					map<string, string> tempAttribMap;
					GetDropDownMap(lookupsJSON, lookupRef, tempAttribMap);
					presetArray.clear();
					presetArray.push_back("");
					for (auto it = tempAttribMap.begin(); it != tempAttribMap.end(); it++)
					{
						presetArray.push_back(it->first);
					}
					presetList[lookupRef] = presetArray;
					m_attsDropdownListMap.insert(std::make_pair(lookupRef, tempAttribMap));
				}
			}
		}
		auto newJsonFieldList = json::array();
		newJsonFieldList.push_back("MaterialCode");
		newJsonFieldList.push_back("MaterialName");
		newJsonFieldList.push_back("Brand");
		newJsonFieldList.push_back("Division");
		newJsonFieldList.push_back("User");
		newJsonFieldList.push_back("Season");
		newJsonFieldList.push_back("Description");
		newJsonFieldList.push_back("Status");
		newJsonFieldList.push_back("MaterialMainCategory");
		newJsonFieldList.push_back("MaterialCategory");
		newJsonFieldList.push_back("MaterialCategoryGroup");
		newJsonFieldList.push_back("MaterialType");

		finalJsontoSave["fieldList"] = newJsonFieldList;
		finalJsontoSave["uiTypeList"] = jsonUiTypeList;
		finalJsontoSave["presetList"] = presetList;
		finalJsontoSave["mandatory_fieldList"] = jsonMandatoryFieldsList;
		
		materialSearchFile << finalJsontoSave;
		materialSearchFile.close();
		Utility::Logger("MaterialSearchDialog -> ReadPLMJson() -> end");
	}
	/**
	 * \brief Creates Drow down fields pre population map for displaying for user selection on search page
	 * \param lookUpsJson 
	 * \param attributeValue 
	 * \param attribMap 
	 */
	void MaterialSearchDialog::GetDropDownMap(json& lookUpsJson, string attributeValue, map<string, string>& attribMap/*, json& presetList*/)
	{
		Utility::Logger("MaterialSearchDialog -> GetDropDownMap() -> Start");
		
		map<string, string> tempMap;
		for (int i = 0; i < lookUpsJson.size(); i++) {
			string lookupNameAndId = lookUpsJson[i].dump();
			json lookupNameAndIdJson = json::parse(lookupNameAndId);
			string colName = lookupNameAndIdJson["name"].dump();
			colName = colName.erase(0, 1);
			colName = colName.erase(colName.size() - 1);

			if (attributeValue.compare(colName) == 0)
			{
				string id, name;
				string columnStg = lookupNameAndIdJson["column"].dump();
				json colNameAndIdJson = json::parse(columnStg);
				id = colNameAndIdJson["Id"].dump();

				name = colNameAndIdJson["Name"].dump();
				name = name.erase(0, 1);
				name = name.erase(name.size() - 1);
				tempMap.insert(std::make_pair(name, id));
			}
		}
		attribMap = tempMap;
		Utility::Logger("MaterialSearchDialog -> getDropDownMap() -> end");
	}
	/**
	 * \brief Downloads attachment using url from JSON
	 * \param materialId 
	 * \param materialCode 
	 */
	void MaterialSearchDialog::DownloadAtachment(string materialId, string materialCode)
	{
		Utility::Logger("MaterialSearchDialog -> DownloadAtachment() -> Start");
		
		json materialAttachSearchMap;
		json filterMapAtt;
		json ConditionsAtt = json::object();
		
		materialAttachSearchMap["roleId"] = 1;
		materialAttachSearchMap["userId"] = 71;
		materialAttachSearchMap["entity"] = "MaterialAttachments";
		materialAttachSearchMap["Schema"] = "FSH5";
		materialAttachSearchMap["personalizationId"] = 0;
		materialAttachSearchMap["pageType"] = "list";
		filterMapAtt["fieldname"] = "Code";
		filterMapAtt["operator"] = "=";
		filterMapAtt["value"] = "E0024";
		ConditionsAtt["Conditions"][0] = filterMapAtt;
		filterMapAtt.clear();
		filterMapAtt["fieldname"] = "IsDeleted";
		filterMapAtt["operator"] = "=";
		filterMapAtt["value"] = 0;
		ConditionsAtt["Conditions"][1] = filterMapAtt;
		filterMapAtt.clear();
		filterMapAtt["fieldname"] = "ReferenceId";
		filterMapAtt["operator"] = "=";
		filterMapAtt["value"] = materialId;
		ConditionsAtt["Conditions"][2] = filterMapAtt;
		filterMapAtt.clear();
		materialAttachSearchMap["dataFilter"] = ConditionsAtt;
		
		materialAttachSearchMap["pageInfo"] = nullptr;
		materialAttachSearchMap["sortInfo"] = nullptr;

		string parameters = to_string(materialAttachSearchMap);
		
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", m_bearerToken));
		
		string attResponse = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/view/api/view/layout/data/get", &parameters, headerNameAndValueList, "HTTP Post");
		
		json responseJson;
		string errorResponse = Utility::CheckErrorDescription(attResponse);
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			int indexForContentType = attResponse.find("Content-Type:");
			string ContentTypeString = attResponse.substr(indexForContentType);
			int indexForFlowerBrace = ContentTypeString.find("{");
			string strForJSON = ContentTypeString.substr(indexForFlowerBrace);
			responseJson = json::parse(strForJSON);
			
			GetMaterialAttachments(responseJson, materialCode);

		}
		else
		{
			UTILITY_API->DisplayMessageBox("ERROR::" + errorResponse);
		}
		Utility::Logger("MaterialSearchDialog -> DownloadAtachment() -> end");
	}
	/**
	 * \brief Gets all Material attachments from JSON
	 * \param response 
	 * \param materialCode 
	 */
	void MaterialSearchDialog::GetMaterialAttachments(json response, string materialCode)
	{
		Utility::Logger("MaterialSearchDialog -> GetMaterialAttachments() -> Start");
		string attColumn, attachmentURL;
		json completeEnityJson;
		string responseJsonStrStyle = response["entities"].dump();
		completeEnityJson = json::parse(responseJsonStrStyle);
		string responseJsonSize = to_string(completeEnityJson.size());
		string responseString = "";
		if (completeEnityJson.size() > 2)
		{
			
		}
		else if (completeEnityJson.size() != 0)
		{
			for (int i = 0; i < completeEnityJson.size(); i++)
			{
				string atachEntityJson = completeEnityJson[i].dump();
				json atachEntityJsonStr = json::parse(atachEntityJson);

				attColumn = atachEntityJsonStr["column"].dump();
				json columnsJson = json::parse(attColumn);

				string attachmentsFileName = columnsJson["OFilename"].dump();
				if (attachmentsFileName != "null")
				{
					string matAtachmentUrl = columnsJson["CFilename"].dump();
					matAtachmentUrl = matAtachmentUrl.erase(0, 1);
					matAtachmentUrl = matAtachmentUrl.erase(matAtachmentUrl.size() - 1);
					string atachedFilenameToSave = materialCode + ".zfab";
					Utility::DownloadFilesFromURL(matAtachmentUrl, MATERIALS_ASSETS_DIRECTORY + atachedFilenameToSave);

					matZfabAtt = true;
				}
			}
		}
		Utility::Logger("MaterialSearchDialog -> GetMaterialAttachments() -> end");
	}
	/**
	 * \brief Get all dependencies for passed attributes
	 * \param brand 
	 * \param division 
	 * \return 
	 */
	string MaterialSearchDialog::GetDependencies(int brand, int division) //, int category)
	{
		json dependencyMap, fabricInfoMap;

		fabricInfoMap["BrandId"] = brand;
		fabricInfoMap["DivisionId"] = division;
		fabricInfoMap["SeasonId"] = 0;
		fabricInfoMap["CollectionId"] = 0;
		fabricInfoMap["MainCategoryId"] = 0;
		fabricInfoMap["CategoryId"] = 0;
		fabricInfoMap["CategoryGroupId"] = 0;
		fabricInfoMap["Designer"] = 0;
		fabricInfoMap["Status"] = 1;

		dependencyMap["userId"] = 71;
		dependencyMap["schema"] = "FSH5";
		dependencyMap["material"] = fabricInfoMap;

		string parameter = to_string(dependencyMap);

		//UTILITY_API->DisplayMessageBox("parameter::" + parameter);
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", DesignSuite::GetInstance()->GetBearerToken()));
		string response = REST_API->CallRESTPost("https://uat.fplm.awsdev.infor.com/api/view/layout/data/get", &parameter, headerNameAndValueList, "HTTP Post");
		//UTILITY_API->DisplayMessageBox("RES in GET Dependency::" + response);
		
		return response;
	}
	/**
	 * \brief Responsible for setting up all dependencies 
	 * \param dependencies 
	 */
	void MaterialSearchDialog::SetDependenciesToWidgets(string dependencies)
	{
		string errorResponse = Utility::CheckErrorDescription(dependencies);

		string completeDependencies;
		json dependencyJson;
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			size_t found = dependencies.find("200");
			if (found != string::npos)
			{
				int indexforcontent = dependencies.find("{");
				completeDependencies = dependencies.substr(indexforcontent);
				std::replace(completeDependencies.begin(), completeDependencies.end(), '�', ' ');

				try
				{
					dependencyJson = json::parse(completeDependencies);
					SetPresetValues(dependencyJson);
				}
				catch (json::exception & err)
				{
					// output exception information
					Utility::Logger("message: " + QString(err.what()).toStdString() + '\n'
						+ "exception id: " + to_string(err.id));
				}
			}
			//UTILITY_API->DisplayMessageBox("setDependenciesToWidgets ::" + to_string(dependencyJson));
		}
		else
		{
			UTILITY_API->DisplayMessageBox(errorResponse);
		}
	}
	/**
	 * \brief Reads for if there is change in Brand Value by user in UI page
	 * \param item 
	 */
	void MaterialSearchDialog::brandValueChanged(const QString& item)
	{
		if (item != "")
		{
			m_signalOrigin = 1;
			map<string, string> attNameIdMap;
			attNameIdMap.clear();
			attNameIdMap.insert(m_attsDropdownListMap["Brand"].begin(), m_attsDropdownListMap["Brand"].end());
			
			for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
			{
				if (it->first == item.toStdString())
				{
					m_currentBrandIndex = stoi(it->second);
					//UTILITY_API->DisplayMessageBox("brand Id ::" + it->second);
					break;
				}
			}
			string dependencies = GetDependencies(m_currentBrandIndex, 0);// , 0);
			//UTILITY_API->DisplayMessageBox("Res in Brand Value changed::" + dependencies);
			SetDependenciesToWidgets(dependencies);
		}
	}
	/**
	 * \brief Sets present values for drop down widgets
	 * \param dependencyJson 
	 */
	void MaterialSearchDialog::SetPresetValues(json dependencyJson)
	{
		for (int i = 0; i < MaterialSearchTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = MaterialSearchTree->topLevelItem(i);
			QWidget* qWidgetColumn0 = MaterialSearchTree->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = MaterialSearchTree->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string label = qlabel->text().toStdString();

			ComboBoxItem* qComboBox = qobject_cast<ComboBoxItem*>(qWidgetColumn1);
			if (qComboBox)
			{
				switch (m_signalOrigin)
				{
				case 0:
				{
					if ((label == "Division") )
					{
						//UTILITY_API->DisplayMessageBox("Case 0");
						qComboBox->clear();
					}
				}
				break;
				case 1:
				{
					if ((label == "Division"))
					{
						string indexString = label + "List";
						string temp = dependencyJson[indexString].dump();
						json tempjson = json::parse(temp);
						if (tempjson.size() > 0)
						{
							qComboBox->clear();
							for (int i = 0; i < tempjson.size(); i++)
							{
								string item = tempjson[i]["Name"].dump();
								//UTILITY_API->DisplayMessageBox("Case 1::  " + item);
								item = item.erase(0, 1);
								item = item.erase(item.size() - 1);
								qComboBox->addItem(QString::fromStdString(item));
							}

						}
					}
				}
				break;
				}

			}
		}
	}
	/**
	 * \brief Reads for if there is change in Division Value by user in UI page
	 * \param item
	 */
	void MaterialSearchDialog::divisionValueChanged(const QString& item)
	{
		if (item != "")
		{
			m_signalOrigin = 2;
			map<string, string> attNameIdMap;
			attNameIdMap.clear();
			attNameIdMap.insert(m_attsDropdownListMap["Division"].begin(), m_attsDropdownListMap["Division"].end());
			for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
			{
				if (it->first == item.toStdString())
				{
					m_currentDivisionIndex = stoi(it->second);
					break;
				}
			}
			string dependencies = GetDependencies(m_currentBrandIndex, m_currentDivisionIndex);//, 0);
			//UTILITY_API->DisplayMessageBox("Res divisionValueChanged::" + dependencies);
			SetDependenciesToWidgets(dependencies);
		}
	}
}