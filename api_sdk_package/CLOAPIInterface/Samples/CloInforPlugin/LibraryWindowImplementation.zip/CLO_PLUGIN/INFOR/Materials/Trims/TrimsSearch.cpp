#pragma once
#include "TrimsSearch.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QLabel>
#include <QMessageBox>
#include <QCheckBox>
#include <any>
#include <optional>
#include "qlistview.h"
#include "classes/APIDefine.h"
#include "CLO_PLUGIN/INFOR/Libraries/json.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
#include "CLO_PLUGIN/INFOR/DesignSuite/DesignSuite.h"
#include "TrimsResultTable.h"
#pragma comment(lib, "libcurl.lib")
#pragma comment(lib, "wldap32.lib")
#pragma comment(lib, "ws2_32.lib")
#include "CLO_PLUGIN/INFOR/Libraries/curl/include/curl/curl.h"
#include <iostream>
#include <direct.h>
/**
 *  making use of json and mapjson from nlohmann json
 */
using json = nlohmann::json;
using namespace std;
using mapjson = nlohmann::json;
bool trimImageAtt = false; 
bool trimzfabAtt = false;
/**
 *  CLOPlugin namespace is used to keep all the functions in this class to be under CLOPlugin namespace.
 */
namespace CLOPlugin
{
	TrimsSearch* TrimsSearch::_instance = NULL;
	string TrimsSearch::m_bearerToken = " ";
/**
	 * \brief Method sets the BearerToken
	 * \param inputString 
	 * \return void 
*/
	void TrimsSearch::SetBearerToken(const string& bearerToken)
	{
		m_bearerToken = bearerToken;
	}
/**
	 * \brief Method gets the instance of this class
		if the instance is already existing, it returns the same instance
	 * \param void
	 * \return instance of the class TrimsSearch
*/
	TrimsSearch* TrimsSearch::GetInstance()
	{
		if (_instance == NULL)
		{
			_instance = new TrimsSearch();
		}
		return _instance;
	}
/**
	 * \brief Method deletes the instance of this class
	* \param void
	 * \return void
*/
	void TrimsSearch::Destroy()
	{
		if (_instance)
		{
			delete _instance;
			_instance = NULL;
		}
	}
/**
	 * \brief Method clears all the input fields in the trims search dialog. 
	* \param void
	 * \return void
*/
	void TrimsSearch::ClearAllFields()
	{
		for (int i = 0; i < TrimsSearchTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem* topItem = TrimsSearchTree->topLevelItem(i);
			QWidget* qWidgetColumn0 = TrimsSearchTree->itemWidget(topItem, 0);
			QWidget* qWidgetColumn1 = TrimsSearchTree->itemWidget(topItem, 1);
			QLabel* qlabel = qobject_cast<QLabel*>(qWidgetColumn0);
			string label = qlabel->text().toStdString();
			QLineEdit* qlineedit = qobject_cast<QLineEdit*>(qWidgetColumn1);

			if (qlineedit)
			{
				qlineedit->setText("");
			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidgetColumn1);
				if (qComboBox)
				{
					int indexOfEmptyString = qComboBox->findText("");
					qComboBox->setCurrentIndex(indexOfEmptyString);
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidgetColumn1);
					if (qtextEdit)
					{
						qtextEdit->setText("");
					}
				}
			}
		}
	}
	/**
	 * \brief Trims search constructor. It has Qt UI related settings to the trims search dialog 
		also it contains signals and slots connections
	 * \param inputs: QWidget and WindowFlags
	 **/
	TrimsSearch::TrimsSearch(QWidget* parent) : QDialog(parent)
	{
		setupUi(this);
		QTreeWidgetItem* dataItem = new QTreeWidgetItem;
		Qt::ItemFlags flags;
		flags = dataItem->flags();
		flags |= Qt::ItemIsSelectable | Qt::ItemIsEditable | Qt::ItemIsEnabled;
		dataItem->setFlags(flags);
		QFont fontStyle("Times new roman", 16, QFont::Bold);
		this->setWindowFlags(Qt::Dialog | Qt::FramelessWindowHint | Qt::CustomizeWindowHint);
		QSize size(425, 500);
		TrimsSearchTree->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		TrimsSearchTree->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
		TrimsSearchTree->setFocusPolicy(Qt::NoFocus);	////
		TrimsSearchTree->setStyleSheet("QTreeWidget::item { border-bottom: 1px solid #232323;""padding : 10px;""height: 25px;""}");
		TrimsSearchTree->setFixedSize(size);
		TrimsSearchTree->setColumnWidth(1, 210);
		TrimsSearchTree->setColumnWidth(0, 195);
		label_ps->setFont(fontStyle);
		layout()->setSizeConstraint(QLayout::SetFixedSize);
		this->adjustSize();

		back->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_back_over.svg"));
		back->setIconSize(QSize(iconHieght, iconWidth));

		search->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_search_over.svg"));
		search->setIconSize(QSize(iconHieght, iconWidth));

		QObject::connect(search, SIGNAL(clicked()), this, SLOT(Search_clicked()));
		QObject::connect(back, SIGNAL(clicked()), this, SLOT(back_clicked()));
		QObject::connect(closeWindow, SIGNAL(clicked()), this, SLOT(Cancle_clicked()));
		m_isUserInputEmpty = true;
		
		ReadPLMJson();
		ReadJsonAndDrawDialog();
	}
/**
	 * \brief : this method reads the JSON file and fills the trims field vector
	 * \param : void
	 * \return : void 
 **/
	void TrimsSearch::ReadJsonAndDrawDialog()
	{
		json jsonString;
		Utility::Fields tempField;
		ifstream trimSearchFile;
		trimSearchFile.open("C:\\MiddlewareFiles\\trimSearchFiltered.json");
		trimSearchFile >> jsonString;
		trimSearchFile.close();
		string completeJsonString, uiTypeJSONObject, presetListJSONObject, fieldValues;
		completeJsonString = jsonString.dump();
		json completeJson = json::parse(completeJsonString);
		uiTypeJSONObject = completeJson["uiTypeList"].dump();
		json componentsJson = json::parse(uiTypeJSONObject);
		presetListJSONObject = completeJson["presetList"].dump();
		json presetListJSON = json::parse(presetListJSONObject);
		fieldValues = completeJson["fieldList"].dump();
		json fieldValuesJson = json::parse(fieldValues);
		for (int i = 0; i < fieldValuesJson.size(); i++)
		{
			string fieldValuesString = fieldValuesJson[i].dump();
			fieldValuesString = fieldValuesString.erase(0, 1);
			fieldValuesString = fieldValuesString.erase(fieldValuesString.size() - 1);
			tempField.labelValue = QString::fromStdString(fieldValuesString);
			string uiTypes = componentsJson[fieldValuesString].dump();
			uiTypes = uiTypes.erase(0, 1);
			uiTypes = uiTypes.erase(uiTypes.size() - 1);
			tempField.fieldUItype = QString::fromStdString(uiTypes);
			if (tempField.fieldUItype == "dropdown")
			{
				string presetList = presetListJSON[fieldValuesString].dump();
				presetList = presetList.erase(0, 1);
				presetList = presetList.erase(presetList.size() - 1);
				presetList.erase(std::remove(presetList.begin(), presetList.end(), '\"'), presetList.end());
				QStringList listQt;
				listQt = QString::fromStdString(presetList).split(",");
				tempField.presetValues = listQt;
			}
			m_TrimsFieldsVector.push_back(tempField);
		}
		DrawWidget(m_TrimsFieldsVector);
	}
/**
	 * \brief : this method draws the widgets on the trims search dialog based on trims field vector
	 * \param : Vector of type Uility fields 
	 * \return : void 
 **/
	void TrimsSearch::DrawWidget(std::vector<Utility::Fields>& fieldsVector)
	{
		for each(auto field in fieldsVector)
		{
			if (field.fieldUItype == "text")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();  	// Adding Tree widget
				QLineEdit* LineEdit = new QLineEdit();					
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
							//UTILITY_API->DisplayMessageBox("lableValue::"+ temLable);
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				LineEdit->setStyleSheet(inputStyle);
				TrimsSearchTree->addTopLevelItem(topLevel);						// Adding ToplevelItem
				TrimsSearchTree->setItemWidget(topLevel, 0, label);				// Adding label at column 1
				TrimsSearchTree->setItemWidget(topLevel, 1, LineEdit);
			}
			if (field.fieldUItype == "dropdown")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QComboBox* ComboBox = new QComboBox(this);
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);								// Setting created font style to label
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				ComboBox->setStyleSheet(inputStyle);
				TrimsSearchTree->addTopLevelItem(topLevel);
				TrimsSearchTree->setItemWidget(topLevel, 0, label);
				TrimsSearchTree->setItemWidget(topLevel, 1, ComboBox);
				ComboBox->setStyleSheet("font: 75 8pt \"Times New Roman\"; combobox-popup:0");
				ComboBox->addItems(field.presetValues);
				int indexOfEmptyString = ComboBox->findText("");
				ComboBox->setCurrentIndex(indexOfEmptyString); //Setting the current index.
			}
			if (field.fieldUItype == "textarea")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();  // Creating new TreeWidgetItem
				QTextEdit* TextEdit = new QTextEdit();						// Creating new LineEdit Widget
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				label->setText(field.labelValue);
				TrimsSearchTree->addTopLevelItem(topLevel);						// Adding ToplevelItem
				TrimsSearchTree->setItemWidget(topLevel, 0, label);				// Adding label at column 1
				TrimsSearchTree->setItemWidget(topLevel, 1, TextEdit);
				TextEdit->setText(field.userInputValues);
				TextEdit->setStyleSheet("border: 1px solid black;""background-color: #222222;""font: 75 8pt \"Times New Roman\";");
				TextEdit->setMaximumSize(190, 80);
			}
			if (field.fieldUItype == "DateEdit")
			{
				QTreeWidgetItem* topLevel = new QTreeWidgetItem();
				QDateEdit* DateTimeEdit = new QDateEdit();
				bool enable = true;
				DateTimeEdit->setCalendarPopup(enable);			// Setting Popup Calendar for Date time picker.
				QString dataricovero("");
				QDate date = QDate::fromString(dataricovero, "");
				QLabel* label = new QLabel();
				label->setStyleSheet(inputFont);
				string tempLabel = field.labelValue.toStdString();
				int tempCapsCount = 0;
				for (int capsCount = 0; capsCount < tempLabel.length(); capsCount++)
				{
					if (isupper(tempLabel[capsCount]))
					{
						if (capsCount != tempCapsCount)
						{
							tempCapsCount = capsCount + 1;
							tempLabel = tempLabel.insert(capsCount, " ");
						}
					}
				}
				label->setText(QString::fromStdString(tempLabel));
				DateTimeEdit->setStyleSheet(inputStyle);
				TrimsSearchTree->addTopLevelItem(topLevel);
				TrimsSearchTree->setItemWidget(topLevel, 0, label);
				TrimsSearchTree->setItemWidget(topLevel, 1, DateTimeEdit);
			}
		}
	}
	/**
		 * \brief  destructortor of Trims search class
		 deletes the object of this class.
	 */
	TrimsSearch::~TrimsSearch()
	{
	}
	/**
	 * \brief : this method extracts all the values entered by the user before searching.
	* \Param  : void
	 * \return true or flase
	 */
	bool TrimsSearch::ExtractAllUIValues()
	{
		for (int i = 0; i < TrimsSearchTree->topLevelItemCount(); ++i)
		{
			QTreeWidgetItem *topItem = TrimsSearchTree->topLevelItem(i);
			QWidget *qWidget = TrimsSearchTree->itemWidget(topItem, 0);
			QWidget *qWidget1 = TrimsSearchTree->itemWidget(topItem, 1);
			QLabel *qlabel = qobject_cast<QLabel *>(qWidget);
			string label = qlabel->text().toStdString();
			QLineEdit *qlineedit = qobject_cast<QLineEdit *>(qWidget1);
			if (qlineedit)
			{
				m_TrimsFieldsVector[i].userInputValues = qlineedit->text();
				if (!qlineedit->text().isEmpty())
				{
					m_isUserInputEmpty = false;
				}
			}
			else
			{
				QComboBox* qComboBox = qobject_cast<QComboBox*>(qWidget1);
				if (qComboBox)
				{
					m_TrimsFieldsVector[i].userInputValues = qComboBox->currentText();
					if (!qComboBox->currentText().isEmpty())
					{
						m_isUserInputEmpty = false;
					}
				}
				else
				{
					QTextEdit* qtextEdit = qobject_cast<QTextEdit*>(qWidget1);
					if (qtextEdit)
					{
						m_TrimsFieldsVector[i].userInputValues = qtextEdit->toPlainText();
						if (!qtextEdit->toPlainText().isEmpty())
						{
							m_isUserInputEmpty = false;
						}
					}
				}
			}
		}
		if (m_isUserInputEmpty)
		{
			UTILITY_API->DisplayMessageBox("Please enter atleast one field to search Trims.");
			return false;
		}
		return true;
	}
/**
	 * \brief : this method creates a MAP based on user search criteria. Collects all the conditions given by the user and store it in the map. This map is used for searching.
	 For reference we are writing all the given conditions into a file.
	* \Param  : void
	 * \return : void
	 */
	void TrimsSearch::CreateSearchMap()
	{
		ofstream trimsFile;
		trimsFile.open("C:\\MiddlewareFiles\\trims.json");
		json emptyJsonObject;
		json mapArray;
		json pagInfoMap;
		json filterMap;
		json conditions = json::object();
		pagInfoMap["Page"] = 1;
		pagInfoMap["PageSize"] = 40;
		pagInfoMap["pageCount"] = 1;
		pagInfoMap["totalCount"] = 8;
		m_TrimSearchMap["roleId"] = 1;
		m_TrimSearchMap["userId"] = 71;
		m_TrimSearchMap["entity"] = "Trim";
		m_TrimSearchMap["Schema"] = "FSH5";
		m_TrimSearchMap["fromAi"] = true;
		m_TrimSearchMap["pageType"] = "list";
		m_TrimSearchMap["sortInfo"] = emptyJsonObject;
		m_TrimSearchMap["PageInfo"] = pagInfoMap;
		int count = 0;
		for (auto array_element : m_TrimsFieldsVector)
		{
			string attLabel = array_element.labelValue.toStdString();
			string userSelected = array_element.userInputValues.toStdString();
			if (userSelected != "")
			{
				if (array_element.fieldUItype == "dropdown")
				{
					for (auto it = m_attributeMap.begin(); it != m_attributeMap.end(); it++)
					{
						if (it->first == attLabel)
						{
							mapArray["fieldName"] = it->second;
							map<string, string> attNameIdMap;
							attNameIdMap.clear();
							attNameIdMap.insert(m_attsDropdownListMap[attLabel].begin(), m_attsDropdownListMap[attLabel].end());
							for (auto it = attNameIdMap.begin(); it != attNameIdMap.end(); it++)
							{
								if (it->first == userSelected)
								{
									mapArray["operator"] = "=";
									mapArray["value"] = stoi(it->second);
									break;
								}
							}
							break;
						}
					}
					conditions["Conditions"][count++] = mapArray;
				}
				else if (attLabel == "Code")  // checking based on code
				{
					filterMap.clear();
					filterMap["fieldName"] = attLabel;
					filterMap["operator"] = "like";
					filterMap["value"] = userSelected;
					conditions["Conditions"][count++] = filterMap;
				}
				else if (attLabel == "Name") // checking based on name
				{
					filterMap.clear();
					filterMap["fieldName"] = attLabel;
					filterMap["operator"] = "like";
					filterMap["value"] = userSelected;
					conditions["Conditions"][count++] = filterMap;
				}
				else		// checking based on other fields			
				{
					filterMap.clear();
					filterMap["fieldName"] = attLabel;
					filterMap["operator"] = "=";
					filterMap["value"] = userSelected;
					conditions["Conditions"][count++] = filterMap;
				}
			}
		}
		conditions["Search"] = nullptr;
		m_TrimSearchMap["dataFilter"] = conditions;
		trimsFile << m_TrimSearchMap;
		trimsFile.close();
	}
	/**
	 * \brief : this method makes a rest call to read the data from the PLM. Based on search map from the createSearchMap method it reads the PLM.
	 Response given by REST call will be used to create the result table.
	* \Param  : void
	 * \return : void
	 */
	void TrimsSearch::PLMSearch()
	{
		string parameter = to_string(m_TrimSearchMap);
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("content-Type", "application/json"));
		headerNameAndValueList.push_back(make_pair("authorization", m_bearerToken));
		string response = REST_API->CallRESTPost("https://qac-ionapi.qac.awsdev.infor.com/FPLMUAT_TST/FASHIONPLM/adobe/api/view/layout/data/get", &parameter, headerNameAndValueList, "HTTP Post");
		json responseJson;
		string errorResponse = Utility::CheckErrorDescription(response);
		if (errorResponse.empty() && (errorResponse.length() == 0))
		{
			int indexForContentType = response.find("Content-Type:");
			string ContentTypeString = response.substr(indexForContentType);
			int indexForFlowerBrace = ContentTypeString.find("{");
			string strForJSON = ContentTypeString.substr(indexForFlowerBrace);
			std::replace(strForJSON.begin(), strForJSON.end(), '�', ' ');
			try
			{
				responseJson = json::parse(strForJSON);
			}
			catch (json::exception & err)
			{
			}
			CreateResultTable(responseJson);
		}
		else
		{
			UTILITY_API->DisplayMessageBox(errorResponse);
		}
	}
	/**
	 * \brief :On click of search button this method extract all the search criteria  entered by the user then creates the search  map and based on search map it searches the values from the PLM.
	 From this PLM search it will create the result table.
	* \Param  : void
	 * \return : void
	 */
	void TrimsSearch::Search_clicked()
	{
		bool isExtracted = ExtractAllUIValues();

		if (isExtracted == true)
		{
			this->hide();
			CreateSearchMap();
			PLMSearch();
			m_isUserInputEmpty = true;
		}
	}
/**
	 * \brief :This method creates the result table for selected trims.
	* \Param  : json file
	 * \return : void
	 */
	void TrimsSearch::CreateResultTable(json& responseJson)
	{
		const char* newDirPath = TRIMS_TEMP_DIRECTORY.c_str();
		mkdir(newDirPath);
		string entities = responseJson["entities"].dump();
		json completeEntitiesJson = json::parse(entities);
		TrimsResultTable objTrimsResultTable;
		objTrimsResultTable.SetBearerToken(m_bearerToken);
		bool isImage = false;
		if (completeEntitiesJson.size() != 0)
		{
			int rowCount = 0;
			Utility::TrimResults tempTrimResults;
			for (int i = 0; i < completeEntitiesJson.size(); i++)
			{
				string entityJson = completeEntitiesJson[i].dump();
				json material = json::parse(entityJson);
				string name = material["name"].dump();
				name = name.erase(0, 1);
				name = name.erase(name.size() - 1);
				string column, trimId, trimName, trimCode, thumbnail, TrimDescription, brandValue, brandId, statusValue;
				string statusId, materialtype, materialtypeLookup, divisionValue, divisionId, trimCategoryId, trimCategoryValue, categoryValue, categoryId, genderId, genderValue, userValue, userId, seasonValue, seasonId;
				if (name == "Trim")
				{
					rowCount = rowCount + 1;
					column = material["column"].dump();
					json columns = json::parse(column);
					trimId = columns["Id"].dump();
					trimName = columns["Name"].dump();
					if (trimName != "null")
					{
						trimName = trimName.erase(0, 1);
						trimName = trimName.erase(trimName.size() - 1);
					}
					else
					{
						trimName = "";
					}
					trimCode = columns["Code"].dump();
					trimCode = trimCode.erase(0, 1);
					trimCode = trimCode.erase(trimCode.size() - 1);
					brandValue = columns["BrandId"].dump();
					if (brandValue != "null")
					{
						brandId = columns["BrandId_Lookup"]["Name"].dump();
						brandId = brandId.erase(0, 1);
						brandId = brandId.erase(brandId.size() - 1);
					}
					statusValue = columns["Status"].dump();
					if (statusValue != "null")
					{
						statusId = columns["Status_Lookup"]["Name"].dump();
						statusId = statusId.erase(0, 1);
						statusId = statusId.erase(statusId.size() - 1);
					}
					divisionValue = columns["DivisionId"].dump();
					if (divisionValue != "null")
					{
						divisionId = columns["DivisionId_Lookup"]["Name"].dump();
						divisionId = divisionId.erase(0, 1);
						divisionId = divisionId.erase(divisionId.size() - 1);
					}
					trimCategoryValue = columns["TrimCategory"].dump();
					if (trimCategoryValue != "null")
					{
						trimCategoryId = columns["TrimCategory_Lookup"]["Name"].dump();
						trimCategoryId = trimCategoryId.erase(0, 1);
						trimCategoryId = trimCategoryId.erase(trimCategoryId.size() - 1);
					}
					seasonValue = columns["SeasonId"].dump();
					if (seasonValue != "null")
					{
						seasonId = columns["SeasonId_Lookup"]["Name"].dump();
						seasonId = seasonId.erase(0, 1);
						seasonId = seasonId.erase(seasonId.size() - 1);
					}
					userId = columns["ModifyId"].dump();
					if (userId != "null")
					{
						userValue = columns["ModifyId_Lookup"]["Name"].dump();
						userValue = userValue.erase(0, 1);
						userValue = userValue.erase(userValue.size() - 1);
					}
					materialtype = columns["MaterialType"].dump();
					if (materialtype != "null")
					{
						materialtypeLookup = columns["MaterialType_Lookup"]["Name"].dump();
						materialtypeLookup = materialtypeLookup.erase(0, 1);
						materialtypeLookup = materialtypeLookup.erase(materialtypeLookup.size() - 1);
					}
					categoryValue = columns["MainCategoryId"].dump();
					if (categoryValue != "null")
					{
						categoryId = columns["MainCategoryId_Lookup"]["Name"].dump();
						categoryId = categoryId.erase(0, 1);
						categoryId = categoryId.erase(categoryId.size() - 1);
					}
					TrimDescription = columns["Description"].dump();
					TrimDescription = TrimDescription.erase(0, 1);
					TrimDescription = TrimDescription.erase(TrimDescription.size() - 1);
					QPixmap pixmap;
					trimImageAtt = false;
					thumbnail = columns["Image"].dump();
					if (thumbnail != "null")
					{
						thumbnail = thumbnail.erase(0, 1);
						thumbnail = thumbnail.erase(thumbnail.size() - 1);
						string filenameToSave = trimCode + ".png";
						Utility::DownloadImageFromURL(thumbnail, TRIMS_TEMP_DIRECTORY + filenameToSave);
						trimImageAtt = true;
						QImage img;
						QImage styleIcon;
						styleIcon.load(QString::fromStdString(TRIMS_TEMP_DIRECTORY + filenameToSave));
						pixmap = QPixmap::fromImage(styleIcon);
					}
					Utility::TrimResults tempTrimResults;
					tempTrimResults.trimCode = QString::fromStdString(trimCode);
					tempTrimResults.trimName = QString::fromStdString(trimName);
					tempTrimResults.trimId = QString::fromStdString(trimId);
					tempTrimResults.trimType = QString::fromStdString(materialtypeLookup);
					tempTrimResults.trimBrand = QString::fromStdString(brandId);
					tempTrimResults.trimDivision = QString::fromStdString(divisionId);
					tempTrimResults.trimStatus = QString::fromStdString(statusId);
					tempTrimResults.trimSeason = QString::fromStdString(seasonId);
					tempTrimResults.trimMainCategory = QString::fromStdString(categoryId);
					tempTrimResults.trimCategory = QString::fromStdString(trimCategoryId); 
					tempTrimResults.trimDescription = QString::fromStdString(TrimDescription);
					tempTrimResults.trimImage = trimImageAtt;
					if (trimImageAtt)
					{
						isImage = trimImageAtt;
						objTrimsResultTable.AddRowData(tempTrimResults, pixmap);
						trimImageAtt = false;
					}
				}
			}
			if ((isImage))
			{
				objTrimsResultTable.setModal(true);
				objTrimsResultTable.exec();
			}
			else if (rowCount > 0)
			{
				UTILITY_API->DisplayMessageBox("This record does not have an image");
				this->show();
			}
		}
		else
		{
			UTILITY_API->DisplayMessageBox("No Result Found");
			this->show();
		}
}
	/**
	 * \brief On click of BACK button in the trims search dialog, it will navigate to the design suite dialog
	 * \input param:  void
	 * \return void
	 */	
	void TrimsSearch::back_clicked()
	{
		this->hide();
		DesignSuite::GetInstance()->setModal(true);
		DesignSuite::GetInstance()->show();
	}
	/**
	 * \brief On click of Cancle button in the  trims search dialog , it will close the trims search dialog.
	 * \input param:  void
	 * \return void
	 */
	void TrimsSearch::Cancle_clicked()
	{
		this->close();
	}
/**
	 * \brief This method reads the trimJSONDetails file and and based on some fields it filtered the large file into trimSearchFiltered json file.
	 Also decides the ordering of labels in the search dilalog.
	 * \input param:  void
	 * \return void
	 */
	void  TrimsSearch::ReadPLMJson()
	{
		json completeStyleJson;
		m_attsDropdownListMap.clear();
		m_attributeMap.clear();
		ifstream filename(MIDDLEWARE_DIRECTORY + "trimJSONDetails.json");
		filename >> completeStyleJson;
		filename.close();
		ofstream newfile(MIDDLEWARE_DIRECTORY + "trimSearchFiltered.json");
		json finalJsontoSave;
		auto jsonFieldList = json::array();
		auto jsonUiTypeList = json::object();
		auto presetArray = json::array();
		auto presetList = json::object();
		auto jsonDataFieldList = json::object();
		auto jsonMandatoryFieldsList = json::array();
		int uiPresetCount = 0;
		string completeJsonString, componentsString, compObjString;
		completeJsonString = completeStyleJson.dump();
		json completeJson = json::parse(completeJsonString);
		componentsString = completeJson["layout"]["components"].dump();
		json componentsJson = json::parse(componentsString);
		for (int i = 0; i < componentsJson.size(); i++) 
		{
			compObjString = componentsJson[i].dump();
			json compObjJson = json::parse(compObjString);
			string propsString = compObjJson["props"].dump();
			json  propsJson = json::parse(propsString);
			string visible = propsJson["isVisibleAi"].dump();
			if (visible == "true")
			{
				string isRequired = propsJson["isRequired"].dump();
				string fieldType = compObjJson["fieldType"].dump();
				fieldType = fieldType.erase(0, 1);
				fieldType = fieldType.erase(fieldType.size() - 1);
				string lookupRef = compObjJson["lookupRef"].dump();
				lookupRef = lookupRef.erase(0, 1);
				lookupRef = lookupRef.erase(lookupRef.size() - 1);
				string dataField = compObjJson["dataField"].dump();
				dataField = dataField.erase(0, 1);
				dataField = dataField.erase(dataField.size() - 1);
				if (lookupRef == "ul")
				{
					m_attributeMap.insert(std::make_pair(dataField, dataField));
					jsonUiTypeList[dataField] = fieldType;
					jsonDataFieldList[dataField] = dataField;
					jsonFieldList.push_back(dataField);
					if (isRequired == "true")
					{
						jsonMandatoryFieldsList.push_back(dataField);
					}
				}
				else
				{
					m_attributeMap.insert(std::make_pair(lookupRef, dataField));
					jsonUiTypeList[lookupRef] = fieldType;
					jsonDataFieldList[lookupRef] = dataField;
					jsonFieldList.push_back(lookupRef);
					if (isRequired == "true")
					{
						jsonMandatoryFieldsList.push_back(lookupRef);
					}
				}
				if (fieldType == "dropdown")
				{
					string lookups = completeJson["lookups"].dump();
					json lookupsJSON = json::parse(lookups);
					map<string, string> tempAttribMap;
					GetDropDownMap(lookupsJSON, lookupRef, tempAttribMap/*, presetArray*/);
					presetArray.clear();
					presetArray.push_back("");
					for (auto it = tempAttribMap.begin(); it != tempAttribMap.end(); it++)
					{
						presetArray.push_back(it->first);
					}
					presetList[lookupRef] = presetArray;
					m_attsDropdownListMap.insert(std::make_pair(lookupRef, tempAttribMap));
				}
			}
		}
		auto newjsonFieldList = json::array();
		newjsonFieldList.push_back("Code");
		newjsonFieldList.push_back("Name");
		newjsonFieldList.push_back("Brand");
		newjsonFieldList.push_back("Division");
		newjsonFieldList.push_back("Season");
		newjsonFieldList.push_back("Status");
		newjsonFieldList.push_back("User");
		newjsonFieldList.push_back("MaterialType");
		newjsonFieldList.push_back("Description");
		finalJsontoSave["fieldList"] = newjsonFieldList; 
		finalJsontoSave["uiTypeList"] = jsonUiTypeList;
		finalJsontoSave["presetList"] = presetList;
		finalJsontoSave["mandatory_fieldList"] = jsonMandatoryFieldsList;
		finalJsontoSave["dataFieldList"] = jsonDataFieldList;
		newfile << finalJsontoSave;
		newfile.close();
	}
/**
	 * \brief This method creates the drop down map
	 * \input param:  json , string, map
	 * \return void
	 */
	void TrimsSearch::GetDropDownMap(json& lookUpsJson, string attributeValue, map<string, string>& attribMap)
	{
		map<string, string> tempMap;
		for (int i = 0; i < lookUpsJson.size(); i++) {
			string lookupNameAndID = lookUpsJson[i].dump();
			json lookupNameAndIDJSON = json::parse(lookupNameAndID);
			string colName = lookupNameAndIDJSON["name"].dump();
			colName = colName.erase(0, 1);
			colName = colName.erase(colName.size() - 1);
			if (attributeValue.compare(colName) == 0)
			{
				string id, name;
				string columnStg = lookupNameAndIDJSON["column"].dump();
				json colNameAndIDJSON = json::parse(columnStg);
				id = colNameAndIDJSON["Id"].dump();
				name = colNameAndIDJSON["Name"].dump();
				name = name.erase(0, 1);
				name = name.erase(name.size() - 1);
				tempMap.insert(std::make_pair(name, id));
			}
		}
		attribMap = tempMap;
	}
}