#pragma once

#include <QDialog>
#include <string>
#include <iostream>
#include <QMainWindow>
#include <QLineEdit>
#include <QTextEdit>
#include <QDateTimeEdit>
#include <QComboBox>
#include <QLabel>
#include <QTreeWidgetItem>
#include <QTableWidgetItem>
#include <vector>
#include <map>
#include "GeneratedFiles/ui_FabricsSearchDialog.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
#include "CLO_PLUGIN/INFOR/Libraries/json.h"
using json = nlohmann::json;

namespace CLOPlugin
{
	class  MaterialSearchDialog : public QDialog, public Ui_MaterialSearchDialog
	{
		Q_OBJECT
		std::vector<Utility::Fields> m_materialsFieldsVector;
		static MaterialSearchDialog* _instance;
		static string m_bearerToken;
		std::map<string, string> m_attributeMap;
		map<string, map<string, string>> m_attsDropdownListMap;
		json m_materialSearchMap;
		bool m_isUserInputEmpty;
		int m_currentBrandIndex;
		int m_currentDivisionIndex;
		int m_signalOrigin;
		void GetDropDownMap(json& lookUpsJson, string attributeValue, map<string, string>& attribMap);
		
	public:
		MaterialSearchDialog(QWidget* parent = 0);
		static MaterialSearchDialog*	GetInstance();
		static void	Destroy();
		~MaterialSearchDialog();
		void ReadPLMJson();
		void ReadJsonAndDrawDialog();
		void DrawWidget(std::vector<Utility::Fields>& fieldsVector);
		bool ExtractAllUIValues();
		void CreateResultTable(json& responseJson);
		void SetBearerToken(const string& bearerToken);
		void CreateSearchMap();
		void PLMSearch();
		void ClearAllFields();
		void DownloadAtachment(string materialId, string materialCode);
		void GetMaterialAttachments(json response, string code);
		string GetDependencies(int brand, int division);
		void SetDependenciesToWidgets(string dependencies);
		void SetPresetValues(json dependencyJson);

	private slots:

		void Search_clicked();
		void Cancle_clicked();
		void back_clicked();

		void brandValueChanged(const QString& item);
		void divisionValueChanged(const QString& item);
		
	};
}
