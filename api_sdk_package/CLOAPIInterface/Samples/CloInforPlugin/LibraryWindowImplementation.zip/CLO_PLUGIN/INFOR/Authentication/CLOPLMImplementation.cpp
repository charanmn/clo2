#include "CLOPLMImplementation.h"

#include "CLOAPIInterface/CLOAPIInterface.h"
#include "LibraryWindowImplPlugin.h"
#include "CLOPLMSignIn.h"
#include "CLO_PLUGIN/INFOR/DesignSuite/DesignSuite.h"
/**
 * \Setting Search mode for PLM 
 */
namespace CLOPlugin
{
	CLOPLMImplementation::CLOPLMImplementation(QWidget* parent, Qt::WindowFlags flags, SEARCH_ITEM_MODE searchMode) : QDialog(parent, flags)
	{
		m_searchMode = searchMode;
	}
	CLOPLMImplementation::~CLOPLMImplementation()
	{

	}
	/**
	 * \brief Method to Set Search Mode
	 * \param response 
	 */
	void CLOPLMImplementation::SetSearchMode(SEARCH_ITEM_MODE searchMode)
	{
	    const string plmUserId, plmPassword;
		string token;
		m_searchMode = searchMode;
		if (m_searchMode == PLM_SEARCH)
		{
			bool isAccepted = SigninPLM();
			if (isAccepted)
			{
				DesignSuite::GetInstance()->setModal(true);
				DesignSuite::GetInstance()->SetBearerToken(CLOPLMSignIn::GetInstance()->GetBearerToken());
				DesignSuite::GetInstance()->exec();
			}
		}
	}
	/**
	 * \brief Sign in to PLM
	 * \param response 
	 */
	bool CLOPLMImplementation::SigninPLM()
	{
		if (PLMSignin::GetInstance()->GetSignInPLM())
			return true;
		CLOPLMSignIn::GetInstance()->exec(); // make this a single ton and get instance
		if (CLOPLMSignIn::GetInstance()->result() == QDialog::Accepted)
		{
			QString getId = CLOPLMSignIn::GetInstance()->GetUserID();
			QString getPassword = CLOPLMSignIn::GetInstance()->GetPassword();
			PLMSignin::GetInstance()->SetSignInPLM(true);
		}
		else
		{
			PLMSignin::GetInstance()->SetSignInPLM(false);
		}
		return PLMSignin::GetInstance()->GetSignInPLM();
	}
	bool CLOPLMImplementation::SigninPLM(const string userId, const string password, string bearerToken)
	{
		return false;
	}
}