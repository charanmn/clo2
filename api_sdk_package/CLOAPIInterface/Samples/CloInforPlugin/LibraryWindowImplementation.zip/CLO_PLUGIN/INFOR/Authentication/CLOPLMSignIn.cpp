#pragma once
#include "CLOPLMSignIn.h"
#include <QDebug>
#include "CLOAPIInterface.h"
#include "CLO_PLUGIN/INFOR/Utilities/Utility.h"
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
#include <Qt/qtextstream.h>
#include <Qt/qfileinfo.h>
#include <Qt/qimagereader.h>
#include <Qt/qhttpmultipart.h>

/*
*OnAccept() method is doing the authontication of the user.
*readJsonFile() method is provideing the url to login the user.
*/
namespace CLOPlugin {
	/**
	 * \brief constructor to singleton instance
	 */
	PLMSignin* PLMSignin::_instance = NULL;
	PLMSignin* PLMSignin::GetInstance()
	{
		if (_instance == NULL) {
			_instance = new PLMSignin();
		}
		return _instance;
	}
	/**
	 * \brief destructor to destroy singleton instance
	 */
	void PLMSignin::Destroy()
	{
		if (_instance) {
			delete _instance;
			_instance = NULL;
		}
	}
	/**
	 * \brief constructor to Set SignInPLM
	 */
	void PLMSignin::SetSignInPLM(bool b)
	{
		m_isSignInPLMEnabled = b;
	}
	/**
	 * \brief constructor to Get SignInPLM
	 */
	bool PLMSignin::GetSignInPLM()
	{
		return m_isSignInPLMEnabled;
	}
	CLOPLMSignIn* CLOPLMSignIn::_instance = NULL;
	CLOPLMSignIn* CLOPLMSignIn::GetInstance()
	{
		if (_instance == NULL) {
			_instance = new CLOPLMSignIn();
		}
		return _instance;
	}
	/**
	 * \brief destructor to destroy CLOPLMSignIn
	 */
	void CLOPLMSignIn::Destroy()
	{
		if (_instance) {
			delete _instance;
			_instance = NULL;
		}
	}
	CLOPLMSignIn::CLOPLMSignIn(QWidget* parent, Qt::WindowFlags flags)
		: QDialog(parent, flags)
	{
		setupUi(this);
		//PLMInputId->setText("puneethkumar.vn@govisetech.com"); //@To-Do
		//PLMInputPwd->setText("67*Password"); //@To-Do
		PLMInputPwd->setEchoMode(QLineEdit::Password);
		cancelButton->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_cancel_over.svg"));
		cancelButton->setIconSize(QSize(iconHieght, iconWidth));
		okButton->setIcon(QIcon(":/CLO_PLUGIN/INFOR/images/icon_ok_over.svg"));
		okButton->setIconSize(QSize(iconHieght, iconWidth));
				
		QObject::connect(cancelButton, SIGNAL(clicked()), this, SLOT(cancel_Clicked()));
		QObject::connect(okButton, SIGNAL(clicked()), this, SLOT(ValidateLoginCredentials())); 
	}
	CLOPLMSignIn::~CLOPLMSignIn()
	{

	}
	/**
	 * \brief  Setting DefaultUserName 
	 */
	void CLOPLMSignIn::SetDefaultID(QString userId)
	{
		PLMInputId->setText(m_plmLoginId);
	}
	/**
	 * \brief Setting DefaultPassword 
	 */
	void CLOPLMSignIn::SetDefaultPassword(QString password)
	{
		PLMInputPwd->setText(m_plmLoginPassword);
	}
	/**
	 * \brief  Get CLOPLMSignIn ID
	 */
	const QString& CLOPLMSignIn::GetUserID()
	{
		return m_plmLoginId;
	}
	/**
	 * \brief  Get GetBearerToken 
	 */
	string & CLOPLMSignIn::GetBearerToken()
	{
		return m_bearerTokenResponse;
	}
	/**
	 * \brief  Get Password
	 */
	const QString& CLOPLMSignIn::GetPassword()
	{
		return m_plmLoginPassword;
	}
	/**
	 * \brief Get BearerToken from PLM
	 * \param finalBearerToken 
	 * \return string
	 */
	string SimplifyBearerTokenResponse(string bearerTokenResponse) 
	{
		string finalBearerToken = "";
		if (bearerTokenResponse.find("access_token")) //@To-Do
		{
			int indexForAccessToken = bearerTokenResponse.find("access_token"); //@To-Do
			int indexForRefreshToken = bearerTokenResponse.find("refresh_token"); //@To-Do
			int bearerTokenIndex = indexForRefreshToken - indexForAccessToken - 3;
			string str3 = bearerTokenResponse.substr(indexForAccessToken, bearerTokenIndex);
			int indexForColon = str3.find("\":\"");
			finalBearerToken = str3.substr(indexForColon + 3);
		}
		return finalBearerToken;
	}
	static std::string GetToken() 
	{
		string id = "FPLMUAT_TST~rV7KvvDSREKcpgcSaskLcKKvl1khw4nT8asj-C_N31A"; // set the clo id @To-Do
		string pw = "qjptE3aR3JjUEhkzeD6KTR5i_QZTo12MlCNRjy5qzF9IRwlvgsOFbP_BMt_vyyYo-RwEmy5HoS__Pv10sevyfQ"; // set the clo pw @To-Do
		string basicAuthorizationString = "Basic " +Utility::ConvertToBase64(id + ":" + pw); ////Converting Id and Password to Base64 @To-Do
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("Authorization", basicAuthorizationString));
		headerNameAndValueList.push_back(make_pair("Content-Type", "application/x-www-form-urlencoded"));
		string parameter = "grant_type=password";
		parameter += "&username=FPLMUAT_TST#MSvn2Uf7nTeFtXYdRh5J7Ea41pmIQ-0aLzkrLRFEucBnwwddN4VIknRZAaiC2UrgVmDgGD2NgjH_R9Pm_N2MZw";
		parameter += "&password=2G01AsO2wMnG3cxnj-_-2E6lTV_2SM5DFvLp4PdSYIM9LXCelWihsP9Sa3TR6IVJhGluWJeQFXAdYwp9wBUNRw";
		string response = REST_API->CallRESTPost("https://qac-sso.qac.awsdev.infor.com:443/FPLMUAT_TST/as/token.oauth2", &parameter, headerNameAndValueList, "HTTP Post");
		string token = response.substr(response.find("access_token") + 15, 928);
		
		return token;
	}	
	/**
	 * \brief Method checks for Validate Login Credentials
	 * \param response 
	 */
	void CLOPLMSignIn::ValidateLoginCredentials()
	{	   
		m_plmLoginId = PLMInputId->text();
		m_plmLoginPassword = PLMInputPwd->text();
		string userName = m_plmLoginId.toStdString();
		string password = m_plmLoginPassword.toStdString();
		if (!REST_API)
			return;
		vector<pair<string, string>> headerNameAndValueList;
		headerNameAndValueList.push_back(make_pair("Content-Type", "text/html"));
		headerNameAndValueList.push_back(make_pair("x-infor-tenant", "FPLMUAT_TST"));
		string response = REST_API->CallRESTGet("https://qac-sso.qac.awsdev.infor.com:443/FPLMUAT_TST/as/authorization.oauth2?client_id=FPLMUAT_TST~Wzl4E9EMBPAKXCpbFseHCEk-C9IEsmuOlz5X4IxOGKI&response_type=code&redirect_uri=https://qac-ionapiapplication.qac.awsdev.infor.com/api/ionapi/authCode&response_mode=query", headerNameAndValueList, "HTTP Get");
		string samlRequest = response.substr(response.find("SAMLRequest") + 20, 444);
		string relayState = response.substr(response.find("RelayState") + 19, 30);
		vector<pair<string, string>> samlRequestHeader;
		samlRequestHeader.push_back(make_pair("x-infor-tenant", "FPLMUAT_TST"));
		samlRequestHeader.push_back(make_pair("Content-Type", "application/x-www-form-urlencoded"));
		string samlRequestParam = "SAMLRequest=" + QUrl::toPercentEncoding(QString::fromStdString(samlRequest));
		samlRequestParam += "&RelayState=" + relayState;
		unsigned char* postField = new unsigned char[samlRequestParam.length() + 1];
		std::strcpy((char*)postField, samlRequestParam.c_str());
		unsigned int size = (unsigned int)(samlRequestParam.length()) + 1;
		string samlBeforeResponse = REST_API->CallRESTPost2("https://qac-cloudidentities.qac.awsdev.infor.com/idp/SSO.saml2", postField, size, samlRequestHeader, "HTTP Post");
		string actionKeywordSearch = "resumeSAML20";
		string cookie = "Set-Cookie: PF";
		size_t actionKeyworkIndex = samlBeforeResponse.find(actionKeywordSearch);
		size_t cookieIndex = samlBeforeResponse.find(cookie);
		string urlSubString = samlBeforeResponse.substr(actionKeyworkIndex - 11, 36);
		string cookieStr = samlBeforeResponse.substr(cookieIndex + 12, 47);
		string cookieHeader = "tenant_cookie_qac=FPLMUAT_TST; " + cookieStr;
		vector<pair<string, string>> authCodeHeader;
		authCodeHeader.push_back(make_pair("x-infor-tenant", "FPLMUAT_TST"));
		authCodeHeader.push_back(make_pair("Content-Type", "application/x-www-form-urlencoded"));
		authCodeHeader.push_back(make_pair("Cookie", cookieHeader));
		string loginRequestParam = "pf.username=" + userName;
		loginRequestParam += "&pf.pass=" + password;
		const std::string finalUrl = "https://qac-cloudidentities.qac.awsdev.infor.com" + urlSubString;
		string loginResponse = REST_API->CallRESTPost(finalUrl, &loginRequestParam, authCodeHeader, "Http Post");
		if (loginResponse.find("We did not recognize the user name or password that you entered") == string::npos) 
		{
			string requestToken = "Bearer " + GetToken();
			m_bearerTokenResponse = requestToken;
			m_isAuthenticated = true;
			accept();
		}
		else 
		{
			UTILITY_API->DisplayMessageBox("Entered credentials are not correct!");
		}			
	}
	/**
	 * \brief Method checks for Login cancel 
	 * \param response 
	 */
	void CLOPLMSignIn::cancel_Clicked() 
	{
		PLMInputId->clear();
		PLMInputPwd->clear();;
		this->close();
	}
}
	