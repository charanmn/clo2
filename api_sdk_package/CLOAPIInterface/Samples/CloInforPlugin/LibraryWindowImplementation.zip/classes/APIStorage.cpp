﻿
#include "APICLODataBase.h"
#include "APIStorage.h"
#include "APIUtility.h"
#include "CLO_PLUGIN/INFOR/Utilities/Definitions.h"
#include "CLOAPIInterface.h"

namespace CLOAPISample
{
	APIStorage* APIStorage::_instance = NULL;

	APIStorage* APIStorage::getInstance()
	{
		if (_instance == NULL) {
			_instance = new APIStorage();
		}

		return _instance;
	}

	void APIStorage::destroy() {
		if (_instance) {
			delete _instance;
			_instance = NULL;
		}
	}

	APIStorage::APIStorage()
	{

	}

	APIStorage::~APIStorage()
	{
		remove(m_FileName.c_str());
		
	}
	void APIStorage::SendFileName(string FileName)
	{
		m_FileName = FileName;
	}
	void APIStorage::initialize()
	{
		m_LibraryAPIItemList.clear();
	}

	void APIStorage::clear()
	{
		for (size_t i = 0; i < m_LibraryAPIItemList.size(); ++i)
		{
			 delete m_LibraryAPIItemList[i];
			 m_LibraryAPIItemList[i] = NULL;
		}

		m_LibraryAPIItemList.clear();
	}

	void APIStorage::setFileSizeForAllItems()
	{
		for (size_t i = 0; i < m_LibraryAPIItemList.size(); ++i)
		{
			QString filePath;
			GetFilePathWithID(m_LibraryAPIItemList[i]->itemID, filePath);
			m_LibraryAPIItemList[i]->filesize = getFileSize(filePath);
		}			
	}	
	
	unsigned int APIStorage::getFileSize(const QString& filePath)
	{
		unsigned int size;

		FILE* pFile = NULL;
#if defined( __APPLE__ )
		pFile = FileOpen(&filePath, "r");
#else
		pFile = FileOpen(&filePath, "rb");
#endif
		if (!pFile) 
			return 0;

		fseek(pFile, 0, SEEK_END);
		size = ftell(pFile);
		fclose(pFile);

		return size;
	}

	void APIStorage::GenerateAPIItemListForSample()
	{
		// pattern items 
		LibraryAPIItem* item1 = new LibraryAPIItem();
		item1->itemID = "CLO_MENS_1101";
		item1->itemName = "CLO_MENS_1101.dxf";		
		item1->dateTime = "2019-08-20T16:21:41";		
		item1->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("PATTERN");
		item1->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_CLO;
		item1->metaData[META_DATA_KEY_2_BRAND] = BR_CLO_MENS;
		item1->metaData[META_DATA_KEY_3_PRODUCT_TYPE] = PT_FULL_SLEEVE_SHIRTS;
		item1->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_SPRING_SUMMER_20;
		item1->sampleItemData.itemPath = "CLO_MENS_1101.dxf";
		item1->sampleItemData.iconThumbnailPath = "CLO_MENS_1101_thumb.png";
		item1->sampleItemData.previewThumbnailPath = "CLO_MENS_1101_thumb.png";

		m_LibraryAPIItemList.push_back(item1);
	
		// item2
		LibraryAPIItem* item2 = new LibraryAPIItem();
		item2->itemID = "CLO_WOMENS_1102";
		item2->itemName = "CLO_WOMENS_1102.dxf";		
		item2->dateTime = "2019-08-20T12:00:41";
		item2->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("PATTERN");
		item2->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_NXT;
		item2->metaData[META_DATA_KEY_2_BRAND] = BR_CLOSET_WEB;
		item2->metaData[META_DATA_KEY_3_PRODUCT_TYPE] = PT_JACKETS;
		item2->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_AUTUMN_WINTER_19;
		item2->sampleItemData.itemPath = "CLO_WOMENS_1102.dxf";
		item2->sampleItemData.iconThumbnailPath = "CLO_WOMENS_1102_thumb.png";
		item2->sampleItemData.previewThumbnailPath = "CLO_WOMENS_1102_thumb.png";

		m_LibraryAPIItemList.push_back(item2);

		// item3
		LibraryAPIItem* item3 = new LibraryAPIItem();
		item3->itemID = "Pattern #3";
		item3->itemName = "Pattern #3.dxf";
		item3->dateTime = "2019-08-20T12:00:41";
		item3->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("PATTERN");
		item3->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_OVERSEAS;
		item3->metaData[META_DATA_KEY_2_BRAND] = BR_OVERSEAS_CASUALS;
		item3->metaData[META_DATA_KEY_3_PRODUCT_TYPE] = PT_CARGO;
		item3->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_AUTUMN_WINTER_20;
		item3->sampleItemData.itemPath = "Pattern #3.dxf";
		item3->sampleItemData.iconThumbnailPath = "Pattern #3_thumb.png";
		item3->sampleItemData.previewThumbnailPath = "Pattern #3_thumb.png"; 
		
		m_LibraryAPIItemList.push_back(item3);

		// item4
		LibraryAPIItem* item4 = new LibraryAPIItem();
		item4->itemID = "Pattern #4";
		item4->itemName = "Pattern #4.dxf";
		item4->dateTime = "2019-08-25T12:00:41";
		item4->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("PATTERN");
		item4->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_FITTING;
		item4->metaData[META_DATA_KEY_2_BRAND] = BR_C_MIRROR;
		item4->metaData[META_DATA_KEY_3_PRODUCT_TYPE] = PT_DENIMS;
		item4->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_AUTUMN_WINTER_20;
		item4->sampleItemData.itemPath = "Pattern #4.dxf";
		item4->sampleItemData.iconThumbnailPath = "Pattern #4_thumb.png";
		item4->sampleItemData.previewThumbnailPath = "Pattern #4_thumb.png";

		m_LibraryAPIItemList.push_back(item4);

		// trims
		// item5
		LibraryAPIItem* item5 = new LibraryAPIItem();
		item5->itemID = "TRIM_1";
		item5->itemName = "Trim1.obj";
		item5->dateTime = "2019-08-20T16:21:41";
		item5->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("TRIM");
		item5->metaData["size"] = QString("M");
		item5->metaData["use"] = QString("obj");
		item5->sampleItemData.itemPath = "Trim1.obj";
		item5->sampleItemData.iconThumbnailPath = "Trim1_thumb.png";
		item5->sampleItemData.previewThumbnailPath = "Trim1_thumb.png";

		//m_LibraryAPIItemList.push_back(item5);

		// item6
		LibraryAPIItem* item6 = new LibraryAPIItem();		
		item6->itemID = "TRIM_2";
		item6->itemName = "Trim2.obj";
		item6->dateTime = "2019-08-20T16:21:41";		
		item6->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("TRIM");
		item6->metaData["size"] = QString("M");
		item6->metaData["use"] = QString("obj");
		item6->sampleItemData.itemPath = "Trim2.obj";
		item6->sampleItemData.iconThumbnailPath = "Trim2_thumb.png";
		item6->sampleItemData.previewThumbnailPath = "Trim2_thumb.png";

		//m_LibraryAPIItemList.push_back(item6);

		// fabric
		// item7
		LibraryAPIItem* item7 = new LibraryAPIItem();
		item7->itemID = "FABRIC_1";
		item7->itemName = "fabric1.jpg";
		item7->dateTime = "2019-08-20T16:21:41";
		item7->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("FABRIC");
		item7->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_MD;
		item7->metaData[META_DATA_KEY_2_BRAND] = BR_MD_MOVIEW;
		item7->metaData[META_DATA_KEY_3_PRODUCT_TYPE] = PT_FABRIC_SILK_SATIN;
		item7->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_SPRING_SUMMER_20;
		item7->sampleItemData.itemPath = "fabric1.jpg";
		item7->sampleItemData.iconThumbnailPath = "fabric1.jpg";
		item7->sampleItemData.previewThumbnailPath = "fabric1.jpg";

		m_LibraryAPIItemList.push_back(item7);

		// item8
		LibraryAPIItem* item8 = new LibraryAPIItem();
		item8->itemID = "FABRIC_2";
		item8->itemName = "fabric2.jpg";
		item8->dateTime = "2019-08-10T16:21:41";	
		item8->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("FABRIC");
		item8->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_FITTING;
		item8->metaData[META_DATA_KEY_2_BRAND] = BR_ONLINE;
		item8->metaData[META_DATA_KEY_3_PRODUCT_TYPE] = PT_FABRIC_SILK_SATIN;
		item8->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_REGULAR_SEASON_CORE;
		item8->sampleItemData.itemPath = "fabric2.jpg";
		item8->sampleItemData.iconThumbnailPath = "fabric2.jpg";
		item8->sampleItemData.previewThumbnailPath = "fabric2.jpg";

		m_LibraryAPIItemList.push_back(item8);

		// item9
		LibraryAPIItem* item9 = new LibraryAPIItem();
		item9->itemID = "FABRIC_3";
		item9->itemName = "fabric3.png";
		item9->dateTime = "2019-08-20T16:21:41";
		item9->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("FABRIC");
		item9->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_MD;
		item9->metaData[META_DATA_KEY_2_BRAND] = BR_MD_GAME;
		item9->metaData[META_DATA_KEY_3_PRODUCT_TYPE] = PT_FABRIC_MATTE;
		item9->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_AUTUMN_WINTER_19;
		item9->sampleItemData.itemPath = "fabric3.png";
		item9->sampleItemData.iconThumbnailPath = "fabric3.png";
		item9->sampleItemData.previewThumbnailPath = "fabric3.png";
		m_LibraryAPIItemList.push_back(item9);

		// item10
		LibraryAPIItem* item10 = new LibraryAPIItem();
		item10->itemID = "Cotton_14_Wale_Corduroy";
		item10->itemName = "Cotton_14_Wale_Corduroy.zfab";
		item10->dateTime = "2019-08-20T16:21:41";
		item10->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("FABRIC");
		item10->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_CLO;
		item10->metaData[META_DATA_KEY_2_BRAND] = BR_CLO_LUXURY;
		item10->metaData[META_DATA_KEY_3_PRODUCT_TYPE] = PT_FABRIC_MATTE;
		item10->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_SPRING_SUMMER_20;
		item10->sampleItemData.itemPath = "Cotton_14_Wale_Corduroy.zfab";
		item10->sampleItemData.iconThumbnailPath = "Cotton_14_Wale_Corduroy.zfab";    // thumbnail inside zfab
		item10->sampleItemData.previewThumbnailPath = "Cotton_14_Wale_Corduroy.zfab"; // thumbnail inside zfab
		m_LibraryAPIItemList.push_back(item10);

		// project file
		// item11
		LibraryAPIItem* item11 = new LibraryAPIItem();
		item11->itemID = "sample_zprj";
		item11->itemName = "sample_zprj.zprj";
		item11->dateTime = "2019-10-20T16:17:11";
		item11->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("PROJECT");
		item11->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_CLO;
		item11->metaData[META_DATA_KEY_2_BRAND] = BR_CLO_LUXURY;
		item11->metaData[META_DATA_KEY_3_PRODUCT_TYPE] = PT_DRESSES;
		item11->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_SPRING_SUMMER_20;
		item11->sampleItemData.itemPath = "sample_zprj.zprj";
		item11->sampleItemData.iconThumbnailPath = "sample_zprj.png";
		item11->sampleItemData.previewThumbnailPath = "sample_zprj.zprj"; // thumbnail inside zprj
		m_LibraryAPIItemList.push_back(item11);

		// avatars
		// item12
		LibraryAPIItem* item12 = new LibraryAPIItem();
		item12->itemID = "FV1_Kelly";
		item12->itemName = "FV1_Kelly.avt";
		item12->dateTime = "2019-11-12T15:20:08";
		item12->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("AVATAR");
		item12->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_CLO;
		item12->metaData[META_DATA_KEY_2_BRAND] = BR_CLO_LUXURY;
		item12->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_SPRING_SUMMER_20;
		item12->sampleItemData.itemPath = "FV1_Kelly.avt";
		item12->sampleItemData.iconThumbnailPath = "FV1_Kelly.jpg";
		item12->sampleItemData.previewThumbnailPath = "FV1_Kelly.jpg"; 
		m_LibraryAPIItemList.push_back(item12);

		// item13
		LibraryAPIItem* item13 = new LibraryAPIItem();
		item13->itemID = "FV1_Emma";
		item13->itemName = "FV1_Emma.avt";
		item13->dateTime = "2019-11-12T15:20:08";
		item13->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("AVATAR");
		item13->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_CLO;
		item13->metaData[META_DATA_KEY_2_BRAND] = BR_CLO_LUXURY;		
		item13->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_SPRING_SUMMER_20;
		item13->sampleItemData.itemPath = "FV1_Emma.avt";
		item13->sampleItemData.iconThumbnailPath = "FV1_Emma.jpg";
		item13->sampleItemData.previewThumbnailPath = "FV1_Emma.jpg";
		m_LibraryAPIItemList.push_back(item13);

		// garment
		// item14
		LibraryAPIItem* item14 = new LibraryAPIItem();
		item14->itemID = "sample_garment";
		item14->itemName = "sample_garment.zpac";
		item14->dateTime = "2019-11-08T13:10:48";
		item14->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("GARMENT");
		item14->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_MD;
		item14->metaData[META_DATA_KEY_2_BRAND] = BR_MD_MOVIEW;
		item14->metaData[META_DATA_KEY_3_PRODUCT_TYPE] = PT_DRESSES;
		item14->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_SPRING_SUMMER_20;
		item14->sampleItemData.itemPath = "sample_garment.zpac";
		item14->sampleItemData.iconThumbnailPath = "sample_garment.png";
		item14->sampleItemData.previewThumbnailPath = "sample_garment.zpac"; // thumbnail inside zpac
		m_LibraryAPIItemList.push_back(item14);

		// topstitch
		// item15
		LibraryAPIItem* item15 = new LibraryAPIItem();
		item15->itemID = "ISO_101_Single_Thread_Chainstitch";
		item15->itemName = "ISO_101_Single_Thread_Chainstitch.sst";
		item15->dateTime = "2019-11-08T13:10:48";
		item15->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("TOPSTITCH");
		item15->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_MD;
		item15->metaData[META_DATA_KEY_2_BRAND] = BR_MD_MOVIEW;
		item15->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_SPRING_SUMMER_20;
		item15->sampleItemData.itemPath = "ISO_101_Single_Thread_Chainstitch.sst";
		item15->sampleItemData.iconThumbnailPath = "ISO_101_Single_Thread_Chainstitch.sst";
		item15->sampleItemData.previewThumbnailPath = "ISO_101_Single_Thread_Chainstitch.sst";
		m_LibraryAPIItemList.push_back(item15);

		LibraryAPIItem* item16 = new LibraryAPIItem();
		item16->itemID = "ISO_103_Single_Thread_Bindstitch";
		item16->itemName = "ISO_103_Single_Thread_Bindstitch.sst";
		item16->dateTime = "2019-11-08T13:10:48";
		item16->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("TOPSTITCH");
		item16->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_MD;
		item16->metaData[META_DATA_KEY_2_BRAND] = BR_MD_MOVIEW;
		item16->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_SPRING_SUMMER_20;
		item16->sampleItemData.itemPath = "ISO_103_Single_Thread_Bindstitch.sst";
		item16->sampleItemData.iconThumbnailPath = "ISO_103_Single_Thread_Bindstitch.sst";
		item16->sampleItemData.previewThumbnailPath = "ISO_103_Single_Thread_Bindstitch.sst";
		m_LibraryAPIItemList.push_back(item16);

		// button head
		LibraryAPIItem* item17 = new LibraryAPIItem();
		item17->itemID = "1_Sew-through_Button_03_Parallel";
		item17->itemName = "1_Sew-through_Button_03_Parallel.btn";
		item17->dateTime = "2019-11-08T13:10:48";
		item17->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("BUTTONHEAD");
		item17->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_CLO;
		item17->metaData[META_DATA_KEY_2_BRAND] = BR_CLO_BASIC;
		item17->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_SPRING_SUMMER_20;
		item17->sampleItemData.itemPath = "1_Sew-through_Button_03_Parallel.btn";
		item17->sampleItemData.iconThumbnailPath = "1_Sew-through_Button_03_Parallel.png";
		item17->sampleItemData.previewThumbnailPath = "1_Sew-through_Button_03_Parallel.png";
		m_LibraryAPIItemList.push_back(item17);


		// button hole
		LibraryAPIItem* item18 = new LibraryAPIItem();
		item18->itemID = "Buttonhole_1_Eyelet_Taper_Bartacking";
		item18->itemName = "Buttonhole_1_Eyelet_Taper_Bartacking.bth";
		item18->dateTime = "2019-11-08T13:10:48";
		item18->metaData[META_DATA_KEY_0_DATA_TYPE] = QString("BUTTONHOLE");
		item18->metaData[META_DATA_KEY_1_SERVICE_DIVISION] = SD_CLO;
		item18->metaData[META_DATA_KEY_2_BRAND] = BR_CLO_BASIC;
		item18->metaData[META_DATA_KEY_4_SEASON_CREATED] = SEASON_SPRING_SUMMER_20;
		item18->sampleItemData.itemPath = "Buttonhole_1_Eyelet_Taper_Bartacking.bth";
		item18->sampleItemData.iconThumbnailPath = "Buttonhole_1_Eyelet_Taper_Bartacking.png";
		item18->sampleItemData.previewThumbnailPath = "Buttonhole_1_Eyelet_Taper_Bartacking.png";
		m_LibraryAPIItemList.push_back(item18);

		// generate file size for m_LibraryAPIItemList
		setFileSizeForAllItems();
	}

	vector<LibraryAPIItem> APIStorage::GetSearchList(const QString& searchText, const QVariantMap& searchKeyValues)
	{
		vector<LibraryAPIItem> searchResult;

		for (size_t i = 0; i < m_LibraryAPIItemList.size(); ++i)
		{
			if (m_LibraryAPIItemList[i]->itemName.contains(searchText, Qt::CaseInsensitive))
			{
				bool bMatched = true;
				for (QVariantMap::const_iterator iter = searchKeyValues.constBegin(); iter != searchKeyValues.constEnd(); ++iter)
				{
					if (iter.value().toString().compare("All", Qt::CaseInsensitive) != 0 &&
						!m_LibraryAPIItemList[i]->metaData[iter.key()].toString().contains(iter.value().toString()))
					{
						bMatched = false;
						break;
					}
				}

				if (bMatched)
					searchResult.push_back(*m_LibraryAPIItemList[i]);
			}
		}

		return searchResult;
	}

	bool APIStorage::GetItemWithID(const QString& itemId, LibraryAPIItem& result)
	{
		for (size_t i = 0; i < m_LibraryAPIItemList.size(); ++i)
		{
			if (m_LibraryAPIItemList[i]->itemID.compare(itemId, Qt::CaseInsensitive) == 0)
			{
				result = *m_LibraryAPIItemList[i];
				return true;
			}
		}

		return false;
	}

	bool APIStorage::GetFilePathWithID(const QString& itemId, QString& resultFilePath)
	{
		LibraryAPIItem curItem;
		
		if (GetItemWithID(itemId, curItem))
		{
			resultFilePath = SAMPLES_STORAGE_DIRECTORY + curItem.metaData[META_DATA_KEY_0_DATA_TYPE].toString().toLower() + "/" + curItem.sampleItemData.itemPath;
			return true;
		}

		return false;
	}

	bool APIStorage::GetIconThumbnailPathWithID(const QString& itemId, QString& resultFilePath)
	{
		LibraryAPIItem curItem;

		if (GetItemWithID(itemId, curItem))
		{
			resultFilePath = SAMPLES_STORAGE_DIRECTORY + curItem.metaData[META_DATA_KEY_0_DATA_TYPE].toString().toLower() + "/" + curItem.sampleItemData.iconThumbnailPath;
			return true;
		}

		return false;
	}

	bool APIStorage::GetPreviewThumbnailPathWithID(const QString& itemId, QString& resultFilePath)
	{
		LibraryAPIItem curItem;

		if (GetItemWithID(itemId, curItem))
		{
			resultFilePath = SAMPLES_STORAGE_DIRECTORY + curItem.metaData[META_DATA_KEY_0_DATA_TYPE].toString().toLower() + "/" + curItem.sampleItemData.previewThumbnailPath;
			return true;
		}

		return false;
	}
}