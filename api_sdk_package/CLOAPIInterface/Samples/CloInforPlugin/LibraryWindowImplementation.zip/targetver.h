#pragma once

#ifndef __APPLE__
#include <SDKDDKVer.h>
#endif
