/****************************************************************************
** Meta object code from reading C++ file 'APISearchDialogSample.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../classes/APISearchDialogSample.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'APISearchDialogSample.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_CLOAPISample__APISearchDialogSample[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      37,   36,   36,   36, 0x09,
      48,   36,   36,   36, 0x09,
      66,   59,   36,   36, 0x09,

       0        // eod
};

static const char qt_meta_stringdata_CLOAPISample__APISearchDialogSample[] = {
    "CLOAPISample::APISearchDialogSample\0"
    "\0OnAccept()\0OnReject()\0_index\0"
    "OnServiceDivisionComboBox(int)\0"
};

void CLOAPISample::APISearchDialogSample::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        APISearchDialogSample *_t = static_cast<APISearchDialogSample *>(_o);
        switch (_id) {
        case 0: _t->OnAccept(); break;
        case 1: _t->OnReject(); break;
        case 2: _t->OnServiceDivisionComboBox((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData CLOAPISample::APISearchDialogSample::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject CLOAPISample::APISearchDialogSample::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_CLOAPISample__APISearchDialogSample,
      qt_meta_data_CLOAPISample__APISearchDialogSample, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &CLOAPISample::APISearchDialogSample::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *CLOAPISample::APISearchDialogSample::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *CLOAPISample::APISearchDialogSample::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_CLOAPISample__APISearchDialogSample))
        return static_cast<void*>(const_cast< APISearchDialogSample*>(this));
    if (!strcmp(_clname, "Ui::DialogSearch"))
        return static_cast< Ui::DialogSearch*>(const_cast< APISearchDialogSample*>(this));
    return QDialog::qt_metacast(_clname);
}

int CLOAPISample::APISearchDialogSample::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
