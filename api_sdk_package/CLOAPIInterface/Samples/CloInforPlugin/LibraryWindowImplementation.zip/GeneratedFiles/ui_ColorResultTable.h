/********************************************************************************
** Form generated from reading UI file 'ColorResultTable.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_COLORRESULTTABLE_H
#define UI_COLORRESULTTABLE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTableWidget>
#include <QtGui/QToolButton>

QT_BEGIN_NAMESPACE

class Ui_ColorResultTable
{
public:
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QLabel *label;
    QToolButton *cancel;
    QTableWidget *ColorTable;
    QSpacerItem *horizontalSpacer;
    QPushButton *back;
    QPushButton *download;

    void setupUi(QDialog *ColorResultTable)
    {
        if (ColorResultTable->objectName().isEmpty())
            ColorResultTable->setObjectName(QString::fromUtf8("ColorResultTable"));
        ColorResultTable->resize(1000, 500);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ColorResultTable->sizePolicy().hasHeightForWidth());
        ColorResultTable->setSizePolicy(sizePolicy);
        ColorResultTable->setMinimumSize(QSize(1000, 500));
        ColorResultTable->setMaximumSize(QSize(1068, 600));
        ColorResultTable->setStyleSheet(QString::fromUtf8(""));
        gridLayout_2 = new QGridLayout(ColorResultTable);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(ColorResultTable);
        label->setObjectName(QString::fromUtf8("label"));
        label->setStyleSheet(QString::fromUtf8("font: 75 10pt \"Tahoma\";\n"
"font-weight: bold;"));
        label->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label, 0, 0, 1, 1);

        cancel = new QToolButton(ColorResultTable);
        cancel->setObjectName(QString::fromUtf8("cancel"));
        cancel->setStyleSheet(QString::fromUtf8("#cancel {\n"
"    qproperty-icon: none;\n"
"    image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_none.svg);\n"
"}\n"
"#cancel:hover {\n"
"	image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_over.svg);\n"
"}"));

        gridLayout->addWidget(cancel, 0, 1, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 3);

        ColorTable = new QTableWidget(ColorResultTable);
        ColorTable->setObjectName(QString::fromUtf8("ColorTable"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(80);
        sizePolicy1.setVerticalStretch(80);
        sizePolicy1.setHeightForWidth(ColorTable->sizePolicy().hasHeightForWidth());
        ColorTable->setSizePolicy(sizePolicy1);
        ColorTable->setMinimumSize(QSize(974, 394));
        ColorTable->setMaximumSize(QSize(1000, 500));
        ColorTable->setSizeIncrement(QSize(100, 100));
        ColorTable->setStyleSheet(QString::fromUtf8("font: 75 12pt \"Tahoma\";\n"
"\n"
""));
        ColorTable->setLineWidth(50);
        ColorTable->setMidLineWidth(40);
        ColorTable->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        ColorTable->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        ColorTable->setAutoScrollMargin(50);
        ColorTable->setDragEnabled(false);
        ColorTable->horizontalHeader()->setCascadingSectionResizes(false);
        ColorTable->horizontalHeader()->setMinimumSectionSize(80);
        ColorTable->horizontalHeader()->setStretchLastSection(false);
        ColorTable->verticalHeader()->setDefaultSectionSize(45);
        ColorTable->verticalHeader()->setMinimumSectionSize(39);

        gridLayout_2->addWidget(ColorTable, 1, 0, 1, 3);

        horizontalSpacer = new QSpacerItem(800, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 2, 0, 1, 1);

        back = new QPushButton(ColorResultTable);
        back->setObjectName(QString::fromUtf8("back"));
        back->setMaximumSize(QSize(16777215, 30));
        QFont font;
        font.setFamily(QString::fromUtf8("Tahoma"));
        font.setPointSize(8);
        font.setBold(false);
        font.setWeight(50);
        back->setFont(font);

        gridLayout_2->addWidget(back, 2, 1, 1, 1);

        download = new QPushButton(ColorResultTable);
        download->setObjectName(QString::fromUtf8("download"));
        download->setMaximumSize(QSize(16777215, 30));
        download->setFont(font);

        gridLayout_2->addWidget(download, 2, 2, 1, 1);


        retranslateUi(ColorResultTable);

        QMetaObject::connectSlotsByName(ColorResultTable);
    } // setupUi

    void retranslateUi(QDialog *ColorResultTable)
    {
        ColorResultTable->setWindowTitle(QApplication::translate("ColorResultTable", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("ColorResultTable", "Infor PLM Color Search Results", 0, QApplication::UnicodeUTF8));
        cancel->setText(QString());
        back->setText(QApplication::translate("ColorResultTable", "Back", 0, QApplication::UnicodeUTF8));
        download->setText(QApplication::translate("ColorResultTable", "Download", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ColorResultTable: public Ui_ColorResultTable {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_COLORRESULTTABLE_H
