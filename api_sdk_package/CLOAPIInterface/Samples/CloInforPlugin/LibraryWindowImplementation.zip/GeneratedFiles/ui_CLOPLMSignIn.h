/********************************************************************************
** Form generated from reading UI file 'CLOPLMSignIn.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLOPLMSIGNIN_H
#define UI_CLOPLMSIGNIN_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>

QT_BEGIN_NAMESPACE

class Ui_CLOPLMSignIn
{
public:
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QLineEdit *PLMInputId;
    QLabel *label;
    QLineEdit *PLMInputPwd;
    QLabel *label_2;
    QSpacerItem *horizontalSpacerForButton;
    QPushButton *cancelButton;
    QLabel *label_3;
    QPushButton *okButton;

    void setupUi(QDialog *CLOPLMSignIn)
    {
        if (CLOPLMSignIn->objectName().isEmpty())
            CLOPLMSignIn->setObjectName(QString::fromUtf8("CLOPLMSignIn"));
        CLOPLMSignIn->resize(500, 200);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(CLOPLMSignIn->sizePolicy().hasHeightForWidth());
        CLOPLMSignIn->setSizePolicy(sizePolicy);
        CLOPLMSignIn->setStyleSheet(QString::fromUtf8("/*margin-left: 5px;\n"
"margin-right: 5px;\n"
"margin-top: 5px;\n"
"margin-bottom: 5px;*/\n"
"#CLOPLMSignIn {\n"
"	margin-left: 8px;\n"
"	margin-right: 8px;\n"
"	margin-top: 8px;\n"
"	margin-bottom: 8px;\n"
"	border : 1.5px solid #232323;\n"
"}"));
        gridLayout_2 = new QGridLayout(CLOPLMSignIn);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        PLMInputId = new QLineEdit(CLOPLMSignIn);
        PLMInputId->setObjectName(QString::fromUtf8("PLMInputId"));
        PLMInputId->setStyleSheet(QString::fromUtf8("font: 75 10pt \"Tahoma\";"));

        gridLayout->addWidget(PLMInputId, 0, 1, 1, 1);

        label = new QLabel(CLOPLMSignIn);
        label->setObjectName(QString::fromUtf8("label"));
        label->setStyleSheet(QString::fromUtf8("font: 75 10pt \"Tahoma\";\n"
"font-weight: bold;"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        PLMInputPwd = new QLineEdit(CLOPLMSignIn);
        PLMInputPwd->setObjectName(QString::fromUtf8("PLMInputPwd"));
        PLMInputPwd->setStyleSheet(QString::fromUtf8("font: 75 10pt \"Tahoma\";"));

        gridLayout->addWidget(PLMInputPwd, 1, 1, 1, 1);

        label_2 = new QLabel(CLOPLMSignIn);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setStyleSheet(QString::fromUtf8("font: 75 10pt \"Tahoma\";\n"
"font-weight: bold;"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);


        gridLayout_2->addLayout(gridLayout, 1, 0, 1, 3);

        horizontalSpacerForButton = new QSpacerItem(187, 26, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacerForButton, 2, 0, 1, 1);

        cancelButton = new QPushButton(CLOPLMSignIn);
        cancelButton->setObjectName(QString::fromUtf8("cancelButton"));
        sizePolicy.setHeightForWidth(cancelButton->sizePolicy().hasHeightForWidth());
        cancelButton->setSizePolicy(sizePolicy);
        cancelButton->setMinimumSize(QSize(0, 0));
        cancelButton->setMaximumSize(QSize(16777215, 30));
        cancelButton->setFocusPolicy(Qt::NoFocus);
        cancelButton->setStyleSheet(QString::fromUtf8("font: 75 8pt \"Tahoma\";\n"
"/*image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_over.svg);\n"
"#cancelButton {\n"
"background-color: transparent;\n"
"border-image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_none.svg);\n"
"background: none;\n"
"border: none;\n"
"background-repeat: none;\n"
"}\n"
"\n"
"#cancelButton:hover\n"
"{\n"
"   border-image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_over.svg);\n"
"}*/\n"
"/*\n"
"#cancelButton {\n"
"	font: 75 8pt \"Tahoma\";\n"
"	font-weight: bold;\n"
"    /*qproperty-icon: none;\n"
"    /*image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_none.svg); \n"
"	qproperty-icon: url(\":/CLO_PLUGIN/INFOR/images/icon_cancel_none.svg\"); \n"
"    qproperty-iconSize: 18px 18px; \n"
"}\n"
"\n"
"#cancelButton:hover {\n"
"	font: 75 8pt \"Tahoma\";\n"
"	font-weight: bold;\n"
"    /*background-image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_over.svg);   \n"
"	qproperty-icon: url(\":/CLO_PLUGIN/INFORimages//icon_cancel_over.svg\"); \n"
"    qproperty-iconSize: 18px 18px; \n"
"}\n"
"*/"));
        cancelButton->setIconSize(QSize(18, 18));

        gridLayout_2->addWidget(cancelButton, 2, 1, 1, 1);

        label_3 = new QLabel(CLOPLMSignIn);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setMaximumSize(QSize(16777215, 40));
        QFont font;
        font.setFamily(QString::fromUtf8("Tahoma"));
        font.setPointSize(12);
        font.setBold(true);
        font.setItalic(false);
        font.setWeight(75);
        label_3->setFont(font);
        label_3->setStyleSheet(QString::fromUtf8("/*font: 75 12pt \"Times New Roman\";*/\n"
"font: 75 12pt \"Tahoma\";\n"
"font-weight: bold;"));
        label_3->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_3, 0, 0, 1, 3);

        okButton = new QPushButton(CLOPLMSignIn);
        okButton->setObjectName(QString::fromUtf8("okButton"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(8);
        sizePolicy1.setHeightForWidth(okButton->sizePolicy().hasHeightForWidth());
        okButton->setSizePolicy(sizePolicy1);
        okButton->setMinimumSize(QSize(80, 30));
        okButton->setMaximumSize(QSize(90, 30));
        okButton->setStyleSheet(QString::fromUtf8("font: 75 8pt \"Tahoma\";\n"
"/*font: 75 8pt \"Tahoma\";\n"
"image: url(:/CLO_PLUGIN/INFOR/icon_ok_over.svg);\n"
"font-weight: bold;*/\n"
"/*\n"
"#okButton {\n"
"	font: 75 8pt \"Tahoma\";\n"
"	font-weight: bold;\n"
"    /*qproperty-icon: none;\n"
"    image: url(:/CLO_PLUGIN/INFOR/icon_cancel_none.svg); \n"
"	qproperty-icon: url(\" \"); /* empty image \n"
"    qproperty-iconSize: 24px 24px; /* space for the background image \n"
"    background-image: url(:/CLO_PLUGIN/INFOR/icon_cancel_none.svg);\n"
"    background-repeat: no-repeat;\n"
"	background-attachment: fixed;\n"
"  	background-position: left;\n"
"	\n"
"}\n"
"\n"
"#okButton:hover {\n"
"	font: 75 8pt \"Tahoma\";\n"
"	font-weight: bold;\n"
"   /* image: url(:/CLO_PLUGIN/INFOR/icon_cancel_over.svg);  \n"
"	qproperty-icon: url(\" \"); /* empty image \n"
"    qproperty-iconSize: 18px 18px; /* space for the background image \n"
"    background-image: url(:/CLO_PLUGIN/INFOR/icon_cancel_over.svg);\n"
"    background-repeat: no-repeat;\n"
"	background-attachment:"
                        " fixed;	\n"
"  	background-position: left;\n"
"}\n"
"*/"));
        okButton->setIconSize(QSize(24, 24));

        gridLayout_2->addWidget(okButton, 2, 2, 1, 1);


        retranslateUi(CLOPLMSignIn);

        QMetaObject::connectSlotsByName(CLOPLMSignIn);
    } // setupUi

    void retranslateUi(QDialog *CLOPLMSignIn)
    {
        CLOPLMSignIn->setWindowTitle(QApplication::translate("CLOPLMSignIn", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("CLOPLMSignIn", "UserName", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("CLOPLMSignIn", "Password", 0, QApplication::UnicodeUTF8));
        cancelButton->setText(QApplication::translate("CLOPLMSignIn", "Cancel", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("CLOPLMSignIn", "Infor PLM Login", 0, QApplication::UnicodeUTF8));
        okButton->setText(QApplication::translate("CLOPLMSignIn", "Login", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class CLOPLMSignIn: public Ui_CLOPLMSignIn {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLOPLMSIGNIN_H
