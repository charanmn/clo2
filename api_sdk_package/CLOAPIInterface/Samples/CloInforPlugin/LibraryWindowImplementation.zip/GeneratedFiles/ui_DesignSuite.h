/********************************************************************************
** Form generated from reading UI file 'DesignSuite.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DESIGNSUITE_H
#define UI_DESIGNSUITE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QToolButton>

QT_BEGIN_NAMESPACE

class Ui_DesignSuite
{
public:
    QGridLayout *gridLayout_3;
    QLabel *label;
    QGridLayout *gridLayout_2;
    QToolButton *Cancel;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *verticalSpacer;
    QGridLayout *gridLayout;
    QLabel *label_11;
    QPushButton *trimsSearch;
    QPushButton *ShMaterial;
    QPushButton *ShColor;
    QPushButton *CreateProduct;
    QPushButton *searchProducts;
    QPushButton *UpdateProduct;

    void setupUi(QDialog *DesignSuite)
    {
        if (DesignSuite->objectName().isEmpty())
            DesignSuite->setObjectName(QString::fromUtf8("DesignSuite"));
        DesignSuite->resize(750, 600);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(DesignSuite->sizePolicy().hasHeightForWidth());
        DesignSuite->setSizePolicy(sizePolicy);
        DesignSuite->setMinimumSize(QSize(665, 590));
        DesignSuite->setMaximumSize(QSize(16777215, 16777215));
        DesignSuite->setAutoFillBackground(false);
        DesignSuite->setStyleSheet(QString::fromUtf8("#DesignSuite {\n"
"	margin-left: 5px;\n"
"	margin-right: 5px;\n"
"	margin-top: 5px;\n"
"	margin-bottom: 5px;\n"
"	/*border : 1.5px solid #232323;\n"
"}"));
        gridLayout_3 = new QGridLayout(DesignSuite);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        label = new QLabel(DesignSuite);
        label->setObjectName(QString::fromUtf8("label"));
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setMinimumSize(QSize(360, 565));
        label->setMaximumSize(QSize(600, 565));
        label->setStyleSheet(QString::fromUtf8("image: url(:/CLO_PLUGIN/INFOR/images/CLO.png);"));
        label->setAlignment(Qt::AlignCenter);
        label->setWordWrap(true);
        label->setMargin(0);
        label->setIndent(-1);

        gridLayout_3->addWidget(label, 0, 0, 1, 1);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        Cancel = new QToolButton(DesignSuite);
        Cancel->setObjectName(QString::fromUtf8("Cancel"));
        Cancel->setStyleSheet(QString::fromUtf8("#Cancel {\n"
"    qproperty-icon: none;\n"
"    image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_none.svg);\n"
"}\n"
"#Cancel:hover {\n"
"	image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_over.svg);\n"
"}"));

        gridLayout_2->addWidget(Cancel, 0, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(227, 17, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 0, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer, 1, 1, 1, 1);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setVerticalSpacing(30);
        label_11 = new QLabel(DesignSuite);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        sizePolicy.setHeightForWidth(label_11->sizePolicy().hasHeightForWidth());
        label_11->setSizePolicy(sizePolicy);
        label_11->setMinimumSize(QSize(0, 40));
        label_11->setMaximumSize(QSize(16777215, 40));
        QFont font;
        font.setFamily(QString::fromUtf8("Tahoma"));
        font.setPointSize(12);
        font.setBold(true);
        font.setItalic(false);
        font.setWeight(75);
        label_11->setFont(font);
        label_11->setStyleSheet(QString::fromUtf8("/*font: 75 16pt \"Times New Roman\";*/\n"
"font: 75 12pt \"Tahoma\";\n"
"font-weight: bold;"));
        label_11->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_11, 0, 0, 1, 1);

        trimsSearch = new QPushButton(DesignSuite);
        trimsSearch->setObjectName(QString::fromUtf8("trimsSearch"));
        trimsSearch->setStyleSheet(QString::fromUtf8("font: 75 10pt \"Tahoma\";"));

        gridLayout->addWidget(trimsSearch, 2, 0, 1, 1);

        ShMaterial = new QPushButton(DesignSuite);
        ShMaterial->setObjectName(QString::fromUtf8("ShMaterial"));
        ShMaterial->setStyleSheet(QString::fromUtf8("/*font: 75 12pt \"Times New Roman\";*/\n"
"font: 75 10pt \"Tahoma\";\n"
""));

        gridLayout->addWidget(ShMaterial, 1, 0, 1, 1);

        ShColor = new QPushButton(DesignSuite);
        ShColor->setObjectName(QString::fromUtf8("ShColor"));
        ShColor->setStyleSheet(QString::fromUtf8("font: 75 10pt \"Tahoma\";"));

        gridLayout->addWidget(ShColor, 3, 0, 1, 1);

        CreateProduct = new QPushButton(DesignSuite);
        CreateProduct->setObjectName(QString::fromUtf8("CreateProduct"));
        CreateProduct->setStyleSheet(QString::fromUtf8("font: 75 10pt \"Tahoma\";"));

        gridLayout->addWidget(CreateProduct, 4, 0, 1, 1);

        searchProducts = new QPushButton(DesignSuite);
        searchProducts->setObjectName(QString::fromUtf8("searchProducts"));
        searchProducts->setStyleSheet(QString::fromUtf8("font: 75 10pt \"Tahoma\";"));

        gridLayout->addWidget(searchProducts, 5, 0, 1, 1);

        UpdateProduct = new QPushButton(DesignSuite);
        UpdateProduct->setObjectName(QString::fromUtf8("UpdateProduct"));
        UpdateProduct->setStyleSheet(QString::fromUtf8("font: 75 10pt \"Tahoma\";"));

        gridLayout->addWidget(UpdateProduct, 6, 0, 1, 1);


        gridLayout_2->addLayout(gridLayout, 2, 0, 1, 2);


        gridLayout_3->addLayout(gridLayout_2, 0, 1, 1, 1);


        retranslateUi(DesignSuite);

        QMetaObject::connectSlotsByName(DesignSuite);
    } // setupUi

    void retranslateUi(QDialog *DesignSuite)
    {
        DesignSuite->setWindowTitle(QApplication::translate("DesignSuite", "PLMPsnel", 0, QApplication::UnicodeUTF8));
        label->setText(QString());
        Cancel->setText(QString());
        label_11->setText(QApplication::translate("DesignSuite", "InforPLM Design Suite", 0, QApplication::UnicodeUTF8));
        trimsSearch->setText(QApplication::translate("DesignSuite", "Search Material-Trims", 0, QApplication::UnicodeUTF8));
        ShMaterial->setText(QApplication::translate("DesignSuite", "Search Material-Fabrics", 0, QApplication::UnicodeUTF8));
        ShColor->setText(QApplication::translate("DesignSuite", "Search Color", 0, QApplication::UnicodeUTF8));
        CreateProduct->setText(QApplication::translate("DesignSuite", "Create Product", 0, QApplication::UnicodeUTF8));
        searchProducts->setText(QApplication::translate("DesignSuite", "Search Product", 0, QApplication::UnicodeUTF8));
        UpdateProduct->setText(QApplication::translate("DesignSuite", "Update Product", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class DesignSuite: public Ui_DesignSuite {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DESIGNSUITE_H
