/********************************************************************************
** Form generated from reading UI file 'FabricsResultTable.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FABRICSRESULTTABLE_H
#define UI_FABRICSRESULTTABLE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTableWidget>
#include <QtGui/QToolButton>

QT_BEGIN_NAMESPACE

class Ui_ResultTable
{
public:
    QGridLayout *gridLayout_2;
    QTableWidget *tableWidget;
    QGridLayout *gridLayout;
    QLabel *hearderName;
    QToolButton *closeWindow1;
    QPushButton *OK;
    QPushButton *Back;
    QSpacerItem *horizontalSpacer;

    void setupUi(QDialog *ResultTable)
    {
        if (ResultTable->objectName().isEmpty())
            ResultTable->setObjectName(QString::fromUtf8("ResultTable"));
        ResultTable->resize(1000, 500);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ResultTable->sizePolicy().hasHeightForWidth());
        ResultTable->setSizePolicy(sizePolicy);
        ResultTable->setMinimumSize(QSize(1000, 500));
        ResultTable->setMaximumSize(QSize(1000, 500));
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        ResultTable->setFont(font);
        ResultTable->setStyleSheet(QString::fromUtf8("/*margin-left: 5px;\n"
"margin-right: 5px;\n"
"margin-top: 5px;\n"
"margin-bottom: 5px;\n"
"border-top : 1px solid #232323;\n"
"border-bottom : 1px solid #232323;\n"
"border-top : 1px solid #232323;\n"
"border-top : 1px solid #232323;*/\n"
"#ResultTable \n"
"{\n"
"	margin-left: 8px;\n"
"	margin-right: 8px;\n"
"	margin-top: 8px;\n"
"	margin-bottom: 8px;\n"
"	border : 1.5px solid #232323;\n"
"}"));
        gridLayout_2 = new QGridLayout(ResultTable);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        tableWidget = new QTableWidget(ResultTable);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setMinimumSize(QSize(600, 350));
        tableWidget->setMaximumSize(QSize(1000, 800));
        tableWidget->setStyleSheet(QString::fromUtf8("/*font: 75 8pt \"Times New Roman\";\n"
"border-color: rgb(0, 0, 225);\n"
"gridline-color: rgb(225, 0, 0);\n"
"font: 75 8pt \"MS Shell Dlg 2\";*/\n"
"\n"
"font: 75 10pt \"Tahoma\";\n"
"item\n"
"{\n"
"font: 75 10pt \"Tahoma\";\n"
"border-bottom: 1px solid #232323;\n"
"/*selection-background-color: transparent;*/\n"
"show-decoration-selected: 0;\n"
"margin-left: 5px;\n"
"margin-right: 5px;\n"
"margin-top: 5px;\n"
"margin-bottom: 5px;\n"
"}"));
        tableWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        tableWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        tableWidget->horizontalHeader()->setDefaultSectionSize(60);
        tableWidget->horizontalHeader()->setMinimumSectionSize(40);
        tableWidget->verticalHeader()->setDefaultSectionSize(30);
        tableWidget->verticalHeader()->setMinimumSectionSize(30);

        gridLayout_2->addWidget(tableWidget, 1, 0, 1, 4);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        hearderName = new QLabel(ResultTable);
        hearderName->setObjectName(QString::fromUtf8("hearderName"));
        hearderName->setStyleSheet(QString::fromUtf8("font: 75 10pt \"Tahoma\";\n"
"font-weight: bold;"));
        hearderName->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(hearderName, 0, 0, 1, 1);

        closeWindow1 = new QToolButton(ResultTable);
        closeWindow1->setObjectName(QString::fromUtf8("closeWindow1"));
        closeWindow1->setStyleSheet(QString::fromUtf8("#closeWindow1 {\n"
"    qproperty-icon: none;\n"
"    image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_none.svg);\n"
"}\n"
"#closeWindow1:hover {\n"
"	image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_over.svg);\n"
"}"));

        gridLayout->addWidget(closeWindow1, 0, 1, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 4);

        OK = new QPushButton(ResultTable);
        OK->setObjectName(QString::fromUtf8("OK"));
        OK->setMaximumSize(QSize(16777215, 30));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Tahoma"));
        font1.setPointSize(8);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(9);
        OK->setFont(font1);
        OK->setStyleSheet(QString::fromUtf8("font: 75 8pt \"Tahoma\";\n"
""));

        gridLayout_2->addWidget(OK, 2, 3, 1, 1);

        Back = new QPushButton(ResultTable);
        Back->setObjectName(QString::fromUtf8("Back"));
        sizePolicy.setHeightForWidth(Back->sizePolicy().hasHeightForWidth());
        Back->setSizePolicy(sizePolicy);
        Back->setMaximumSize(QSize(16777215, 30));
        Back->setFont(font1);
        Back->setFocusPolicy(Qt::NoFocus);
        Back->setStyleSheet(QString::fromUtf8("font: 75 8pt \"Tahoma\";\n"
""));

        gridLayout_2->addWidget(Back, 2, 2, 1, 1);

        horizontalSpacer = new QSpacerItem(800, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 2, 0, 1, 2);


        retranslateUi(ResultTable);

        QMetaObject::connectSlotsByName(ResultTable);
    } // setupUi

    void retranslateUi(QDialog *ResultTable)
    {
        ResultTable->setWindowTitle(QApplication::translate("ResultTable", "Dialog", 0, QApplication::UnicodeUTF8));
        hearderName->setText(QApplication::translate("ResultTable", "Infor PLM Material Search Results", 0, QApplication::UnicodeUTF8));
        closeWindow1->setText(QString());
        OK->setText(QApplication::translate("ResultTable", "Download", 0, QApplication::UnicodeUTF8));
        Back->setText(QApplication::translate("ResultTable", "Back", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ResultTable: public Ui_ResultTable {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FABRICSRESULTTABLE_H
