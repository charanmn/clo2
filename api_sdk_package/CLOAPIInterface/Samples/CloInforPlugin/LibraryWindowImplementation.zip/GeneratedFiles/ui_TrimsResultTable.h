/********************************************************************************
** Form generated from reading UI file 'TrimsResultTable.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRIMSRESULTTABLE_H
#define UI_TRIMSRESULTTABLE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTableWidget>
#include <QtGui/QToolButton>

QT_BEGIN_NAMESPACE

class Ui_TrimsResultTable
{
public:
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QLabel *label;
    QToolButton *toolButton;
    QTableWidget *TrimtableWidget;
    QSpacerItem *horizontalSpacer;
    QPushButton *Back;
    QPushButton *OK;

    void setupUi(QDialog *TrimsResultTable)
    {
        if (TrimsResultTable->objectName().isEmpty())
            TrimsResultTable->setObjectName(QString::fromUtf8("TrimsResultTable"));
        TrimsResultTable->resize(1000, 500);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(TrimsResultTable->sizePolicy().hasHeightForWidth());
        TrimsResultTable->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QString::fromUtf8("Arial"));
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        TrimsResultTable->setFont(font);
        gridLayout_2 = new QGridLayout(TrimsResultTable);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(TrimsResultTable);
        label->setObjectName(QString::fromUtf8("label"));
        label->setStyleSheet(QString::fromUtf8("font: 75 10pt \"Tahoma\";\n"
"font-weight: bold;"));
        label->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label, 0, 0, 1, 1);

        toolButton = new QToolButton(TrimsResultTable);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));
        toolButton->setStyleSheet(QString::fromUtf8("#toolButtton {\n"
"    qproperty-icon: none;\n"
"    image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_none.svg);\n"
"}\n"
"#toolButtton:hover {\n"
"	image: url(:/CLO_PLUGIN/INFOR/images/icon_cancel_over.svg);\n"
"}"));

        gridLayout->addWidget(toolButton, 0, 1, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 3);

        TrimtableWidget = new QTableWidget(TrimsResultTable);
        TrimtableWidget->setObjectName(QString::fromUtf8("TrimtableWidget"));
        sizePolicy.setHeightForWidth(TrimtableWidget->sizePolicy().hasHeightForWidth());
        TrimtableWidget->setSizePolicy(sizePolicy);
        TrimtableWidget->setMinimumSize(QSize(974, 394));
        TrimtableWidget->setMaximumSize(QSize(974, 394));
        TrimtableWidget->setStyleSheet(QString::fromUtf8("font: 75 8pt \"Times New Roman\";\n"
"border-color: rgb(0, 0, 225);\n"
"gridline-color: rgb(225, 0, 0);\n"
"font: 75 8pt \"MS Shell Dlg 2\";"));
        TrimtableWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        TrimtableWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        TrimtableWidget->horizontalHeader()->setDefaultSectionSize(60);
        TrimtableWidget->horizontalHeader()->setMinimumSectionSize(50);
        TrimtableWidget->verticalHeader()->setDefaultSectionSize(35);
        TrimtableWidget->verticalHeader()->setMinimumSectionSize(25);

        gridLayout_2->addWidget(TrimtableWidget, 1, 0, 1, 3);

        horizontalSpacer = new QSpacerItem(700, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 2, 0, 1, 1);

        Back = new QPushButton(TrimsResultTable);
        Back->setObjectName(QString::fromUtf8("Back"));
        Back->setMaximumSize(QSize(16777215, 30));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Tahoma"));
        font1.setPointSize(8);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(9);
        Back->setFont(font1);
        Back->setStyleSheet(QString::fromUtf8("font: 75 8pt \"Tahoma\";"));

        gridLayout_2->addWidget(Back, 2, 1, 1, 1);

        OK = new QPushButton(TrimsResultTable);
        OK->setObjectName(QString::fromUtf8("OK"));
        OK->setMaximumSize(QSize(16777215, 30));
        OK->setFont(font1);
        OK->setStyleSheet(QString::fromUtf8("font: 75 8pt \"Tahoma\";"));

        gridLayout_2->addWidget(OK, 2, 2, 1, 1);


        retranslateUi(TrimsResultTable);

        QMetaObject::connectSlotsByName(TrimsResultTable);
    } // setupUi

    void retranslateUi(QDialog *TrimsResultTable)
    {
        TrimsResultTable->setWindowTitle(QApplication::translate("TrimsResultTable", "Dialog", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("TrimsResultTable", "Infor PLM Trims Search Results", 0, QApplication::UnicodeUTF8));
        toolButton->setText(QString());
        Back->setText(QApplication::translate("TrimsResultTable", "Back", 0, QApplication::UnicodeUTF8));
        OK->setText(QApplication::translate("TrimsResultTable", "Download", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class TrimsResultTable: public Ui_TrimsResultTable {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRIMSRESULTTABLE_H
